# Arquitetura do KNAZH (estado atual)

```
KNAZH_SITE/
├── wsgi.py                    ponto de entrada (create_app)
├── knazh/
│   ├── __init__.py            fábrica create_app: config, CSRF, blueprints, cabeçalhos de segurança, erros
│   ├── config.py              configuração por ambiente (tudo sensível vem do .env / ambiente)
│   ├── models.py              modelos (produtos, categorias, clientes, pedidos, itens, histórico, avisos, limitador)
│   ├── migrations.py          migrações explícitas e idempotentes (flask migrate-db)
│   ├── cli.py                 comandos: provisionar admin, seed-demo, backup-db, reenviar avisos...
│   ├── auth.py                sessão, login_required, admin_required (sempre no servidor)
│   ├── blueprints/            ROTAS: main, catalog, cart, checkout, account, admin
│   ├── services/              REGRAS DE NEGÓCIO: orders, admin_orders, admin_catalog, channels, notifications,
│   │                          whatsapp (API Meta), security (limitador), clock (ano/fuso), uploads, mailer...
│   ├── templates/             Jinja: base, components/, pages/, account/, admin/
│   └── static/                css/ (tokens, base, components, pages, admin), js/, img/, fonts/
├── tests/                     pytest (unidade, integração e segurança em um só pacote)
├── docs/                      esta pasta
├── tools/                     scripts auxiliares
├── instance/                  banco SQLite, backups e chave de desenvolvimento (fora do ZIP e do Git)
└── .env.example               modelo de configuração (sem segredos)
```

Responsabilidades: **rotas** só tratam HTTP, autenticação/autorização e chamam serviços; **serviços** concentram as regras
(validação, transições de estado, notificações); **modelos** descrevem as tabelas; templates não contêm regra de negócio.

## Decisão sobre a reorganização de pastas (Parte 3)
**Não movi arquivos.** A estrutura acima já separa rotas, serviços, modelos, templates, estáticos, testes e documentação, não há
imports circulares conhecidos (o único import tardio, em `admin_orders.set_status`, evita um ciclo real com `notifications`) e
renomear pacotes (`knazh/` → `app/`, `blueprints/x/routes.py`) mudaria todos os imports, templates e testes sem ganho funcional,
com risco de regressão em pedidos/autenticação. Se quiser, o próximo passo seguro é dividir `models.py` e `blueprints/admin.py`
(os maiores arquivos) por assunto, com a suíte de testes como rede de segurança.

## Pontos de atenção conhecidos
- SQLite atende bem uma loja pequena em um servidor; para várias instâncias use PostgreSQL (mudar `DATABASE_URL` e revisar `migrations.py`).
- Não há MFA para administradores nem aviso de cancelamento por e-mail nesta versão.
