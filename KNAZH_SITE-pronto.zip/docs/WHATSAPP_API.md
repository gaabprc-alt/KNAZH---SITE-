# Avisos automáticos por WhatsApp (API oficial) — guia de configuração

O site KNAZH já registra o pedido e mostra o estado real dos avisos em **`/admin/pedidos`**. Este guia explica como **ligar** o envio automático
pela **WhatsApp Business Platform (Cloud API oficial da Meta)**. Enquanto isso não for configurado, **nada é enviado** e o painel mostra
“Envio automático por WhatsApp pendente de configuração”.

## O que é (e o que não é)
- **É:** uma chamada HTTPS autenticada à API oficial, feita pelo servidor **depois** de o pedido estar salvo. Dois avisos independentes:
  1. **Equipe** — detalhes do novo pedido (número, cliente, telefone, itens, total, observações) para o número de atendimento.
  2. **Cliente** — “recebemos seu pedido”, **somente se o cliente marcou a caixa de consentimento** no checkout.
- **Não é:** link `wa.me`, automação de navegador ou envio “simulado”. Os botões “Pedir pelo WhatsApp” continuam sendo **só links** que o cliente toca para escrever.
- O aviso ao cliente **não confirma** o pedido: diz apenas que foi recebido e que a equipe vai conferir.
- **“Enviado” = a API aceitou a mensagem** e devolveu um identificador (`wamid…`). A entrega e a leitura no celular **não** são acompanhadas (exigiriam *webhooks*, não implementados).

## Pré-requisitos (fora do código)
1. Conta **Meta Business** (verificada, conforme exigência atual da Meta) e uma **WhatsApp Business Account**.
2. Um **número** cadastrado na plataforma (o número *remetente*). Esse número passa a ser usado pela API.
3. O **ID do número** (`WHATSAPP_PHONE_NUMBER_ID`, que **não** é o telefone) e um **token de acesso** (`WHATSAPP_ACCESS_TOKEN`). Prefira um token de longa duração de um *usuário do sistema*.
4. **Modelos (templates) aprovados** — a empresa só pode iniciar conversa com modelos aprovados (textos abaixo).
5. **Atenção ao número da equipe:** o remetente da API **não envia mensagem para si mesmo**. Se o número comercial `5541996206276` for o remetente, informe outro
   destino em `WHATSAPP_TEAM_NUMBER` (por exemplo, o celular de quem atende). Sem `WHATSAPP_TEAM_NUMBER`, o site usa `WHATSAPP_NUMBER`.

## Modelos de mensagem a criar (idioma `pt_BR`)
Sugestão de categoria: *Utility* (a Meta decide a categoria final). Regras da plataforma já tratadas pelo código: valores das variáveis nunca vazios
(vira `-`), sem quebra de linha, tabulação ou mais de 4 espaços seguidos; o texto não começa nem termina com variável.

**`knazh_pedido_recebido`** (cliente) — 2 variáveis
```
Olá, {{1}}! Recebemos seu pedido #{{2}} na KNAZH. Nossa equipe vai conferir os detalhes e confirmar a aceitação em breve. Obrigado por escolher a KNAZH!
```
`{{1}}` = nome do cliente · `{{2}}` = número do pedido (ex.: `KNZ-000123`).

**`knazh_novo_pedido_equipe`** (equipe) — 6 variáveis
```
Novo pedido #{{1}} na KNAZH. Cliente: {{2}}, telefone {{3}}. Itens: {{4}}. Total: {{5}}. Observações: {{6}}. Confira os detalhes no painel.
```
`{{1}}` pedido · `{{2}}` cliente · `{{3}}` telefone informado · `{{4}}` itens (ex.: `2x Brownie; 1x Cookie`) · `{{5}}` total (ex.: `R$ 40,00`) · `{{6}}` observações (ou `-`).

Se você usar **outros nomes** de modelo, ajuste `WHATSAPP_TEMPLATE_CLIENT` / `WHATSAPP_TEMPLATE_TEAM`. Se mudar o **número ou a ordem das variáveis**, ajuste
`client_params` / `team_params` em `knazh/services/notifications.py`.

## Consentimento do cliente
- No checkout há uma caixa **opcional e desmarcada**: “Quero receber por WhatsApp o aviso de que o pedido foi recebido”, com explicação de uso.
- Sem marcar, o pedido é registrado do mesmo jeito e o aviso ao cliente fica **“Não enviado (cliente não autorizou)”**; o painel não permite forçar esse envio.
- O telefone vem do checkout (com DDD); o código normaliza para o formato internacional (`55` + DDD + número).
- Para quem pedir para **deixar de receber**, a equipe deve atender o pedido manualmente (não há cancelamento automático de consentimento).
- Revise o texto de consentimento com quem cuida do jurídico/LGPD da KNAZH.

## Como o envio funciona
1. O checkout grava `Order` + itens **e** duas linhas em `order_notifications` (equipe e cliente) **na mesma transação**.
2. Depois do *commit*, o servidor tenta enviar (equipe primeiro). **Qualquer falha — rede, token, modelo, erro inesperado — nunca desfaz o pedido.**
3. Cada tentativa “reserva” o aviso com um `UPDATE` condicional (estado + número de tentativas): dois cliques, dois processos ou um recarregamento **não enviam a mesma mensagem duas vezes**.
   Aviso já `enviado` nunca é reenviado.
4. Estados: `pendente` · `enviando` · `enviado` (aceito pela API) · `falhou` (com motivo curto, sem token nem telefone) · `nao_configurado` · `dispensado`.
5. Tentativas são limitadas (`WHATSAPP_MAX_ATTEMPTS`, padrão 5 por aviso) e **controladas**: botão “Tentar enviar de novo” no detalhe do pedido ou
   `python -m flask --app wsgi send-pending-notifications` (pode ir no agendador do servidor). Nenhuma retentativa cria outro pedido.
6. **Tempo esgotado é ambíguo:** se a API não responder a tempo, a mensagem **pode** ter sido aceita. O painel avisa isso; confira com o cliente antes de repetir.
7. O envio acontece dentro do pedido do cliente, com tempo limite curto (`WHATSAPP_API_TIMEOUT`, padrão 5 s por chamada; pior caso ≈ 10 s com os dois avisos). Se isso incomodar,
   mantenha o comando acima num agendador e reduza o tempo limite.

## Como ligar (passo a passo)
1. Crie e aguarde a aprovação dos dois modelos acima.
2. No `.env` do servidor (nunca no Git): `WHATSAPP_API_ENABLED=true`, `WHATSAPP_PHONE_NUMBER_ID=…`, `WHATSAPP_ACCESS_TOKEN=…` e `WHATSAPP_TEAM_NUMBER=…` (se necessário).
3. Reinicie o site. Abra `/admin/pedidos`: o aviso amarelo some quando tudo está configurado.
4. **Teste primeiro com o número de teste/ambiente de testes da plataforma** e destinatários cadastrados nela, **antes** de usar o número real da loja.
5. Faça um pedido de teste (marcando a caixa) e confira o estado no painel. Se falhar, o motivo aparece no detalhe; depois de corrigir, use “Tentar enviar de novo”.

## Segurança
- Token só em variável de ambiente; nunca vai a HTML, JavaScript, logs ou banco. Um teste automatizado confirma que templates/arquivos estáticos não o contêm.
- Erros guardados passam por sanitização (token e sequências longas de dígitos são removidos).
- Logs trazem apenas número do pedido, destinatário (`cliente`/`equipe`) e estado.
- As rotas de pedidos/avisos exigem administrador (checado no servidor), CSRF e só aceitam estados conhecidos.

## Fonte técnica consultada
Documentação oficial da Meta para desenvolvedores (WhatsApp Business Platform / Cloud API): envio de **mensagens de modelo** por
`POST https://graph.facebook.com/<versão>/<PHONE_NUMBER_ID>/messages` com `Authorization: Bearer <token>` e corpo `type: "template"`; a resposta traz o identificador da mensagem.
A versão padrão (`v25.0`) é configurável em `WHATSAPP_API_VERSION`. Regras e preços da plataforma mudam: **confirme** na documentação da Meta antes de ligar em produção.


## Aviso de cancelamento ao cliente (modelo `knazh_pedido_cancelado`)

Quando a equipe cancela um pedido no painel (o motivo é obrigatório), o site cria o aviso `cancel` na mesma transação do
cancelamento e tenta enviá-lo **depois** de gravar. Regras:

- **Consentimento:** só é enviado automaticamente se o cliente marcou a autorização de WhatsApp no checkout. Sem ela o aviso
  fica "Não enviado (cliente não autorizou)" e o painel mostra o botão **Avisar o cliente pelo WhatsApp** (abre `wa.me` com o
  texto pronto; a equipe decide enviar).
- **Falha não desfaz o cancelamento.** O estado do aviso (pendente, enviado, falhou, não configurado) aparece no detalhe do
  pedido e pode ser tentado de novo ali ou por `flask --app wsgi send-pending-notifications`. Um aviso `enviado` nunca é reenviado.
- **Modelo (cadastre e aprove na Meta; categoria "Utilidade", idioma pt_BR), 4 variáveis:**
  `Olá, {{1}}! O pedido {{2}} da KNAZH foi cancelado. Motivo: {{3}}. Atualizado em {{4}}. Se precisar de ajuda, responda esta mensagem.`
  `{{1}}` nome, `{{2}}` número do pedido, `{{3}}` motivo informado, `{{4}}` data e hora (Brasília). O nome do modelo vem de
  `WHATSAPP_TEMPLATE_CANCEL` (padrão `knazh_pedido_cancelado`).
- **Limite do motivo:** 3 a 300 caracteres, em uma linha só (a Meta recusa quebras de linha em variáveis).
- E-mail (SMTP) **não** é usado para este aviso nesta versão.
