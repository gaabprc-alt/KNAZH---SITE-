# Alterações: categoria no produto, pedidos no painel, WhatsApp oficial e iFood

Resumo do que foi feito nesta rodada e **como reverter**. O site existente foi preservado: nenhuma rota, tabela ou coluna existente foi removida ou alterada.

## O que mudou (e o que foi mantido)
| Área | Mudança | Preservado |
|---|---|---|
| Categorias | Formulário de produto escolhe categoria existente **ou** cria nova (botão “Criar categoria” com JS; sem JS, cria ao salvar). Validação: obrigatório, 2–60 caracteres, duplicata ignorando maiúsculas/acentos/espaços. | Todas as categorias, produtos antigos, edição, listagem e o modelo de produto. Sem migração. |
| Carrinho/checkout | Caixa **opcional e desmarcada** de consentimento de WhatsApp; texto do botão do iFood no carrinho: “Abrir loja no iFood” (+ aviso). | “Adicionar ao carrinho” na página do produto, “Finalizar pedido” no carrinho, quantidades, remoção, totais recalculados no servidor, token anti-duplicidade, carrinho só limpo após gravar o pedido. |
| Pedido | Duas linhas em `order_notifications` nascem na mesma transação do pedido; o envio ocorre **depois** do commit. | Número `KNZ-000123`, estado “Aguardando confirmação”, snapshot de itens/preços. |
| Painel | Novo menu **Pedidos**: `/admin/pedidos` (lista, busca, filtro) e `/admin/pedidos/<id>` (itens, totais, cliente, avisos, estado, nova tentativa). | Proteção de acesso (visitante → login, cliente → 403), CSRF, demais telas. |
| WhatsApp | Cliente HTTP da API oficial + orquestração idempotente + estados reais + comando `send-pending-notifications`. **Desligado** sem credenciais. | Botões `wa.me` continuam sendo só links. |
| iFood | Botão abre a loja com o link exato do `.env.example`; texto honesto (não transfere o carrinho). | Carrinho KNAZH intacto ao abrir o iFood. |
| Confirmação | Mostra o estado real do aviso por WhatsApp (só se o cliente autorizou) sem afirmar aceite, pagamento ou entrega. | Hero “Pedido registrado!”, número e estado. |

**Mudança consciente em teste existente:** `tests/test_admin.py` afirmava que o menu **não** tinha “Pedidos” (na época era uma tela falsa). Agora “Pedidos” é real, então
o teste passou a exigir o link real e continua proibindo “Clientes”/“Configurações”. Também foram incluídas as rotas novas na lista de rotas protegidas.

## Arquivos
**Novos:** `knazh/services/whatsapp.py`, `knazh/services/notifications.py`, `knazh/services/admin_orders.py`, `knazh/templates/admin/orders.html`,
`knazh/templates/admin/order_detail.html`, `knazh/templates/admin/_order_macros.html`, `tests/test_categories.py`, `tests/test_notifications.py`,
`tests/test_orders_admin.py`, `tools/verificar_whatsapp_offline.py`, `docs/WHATSAPP_API.md`, este arquivo.

**Modificados:** `knazh/models.py` (+`OrderNotification`, +relação em `Order`), `knazh/forms.py` (campo `new_category`, `whatsapp_optin`), `knazh/services/admin_catalog.py`
(criação de categoria), `knazh/services/text.py` (+`clean_label`), `knazh/services/orders.py` (cria as linhas de aviso), `knazh/blueprints/admin.py`
(categoria nova, endpoint JSON, rotas de pedidos), `knazh/blueprints/checkout.py` (dispara avisos após salvar), `knazh/config.py` (variáveis `WHATSAPP_*`),
`knazh/__init__.py` (filtro `brasilia`), `knazh/cli.py` (+`send-pending-notifications`), templates `admin/layout.html`, `admin/product_form.html`,
`pages/checkout.html`, `pages/cart.html`, `pages/order_confirmation.html`, `static/js/admin.js`, `static/css/admin.css`, `static/css/pages.css`,
`tests/conftest.py`, `tests/test_admin.py`, `README.md`, `.env.example`, `docs/LIMITACOES_E_PENDENCIAS.md`.

## Banco de dados e comandos
- **Nada de ALTER em tabelas existentes.** Só existe uma tabela **nova**, `order_notifications`, criada automaticamente na inicialização (`db.create_all()` é não destrutivo) ou por
  `python -m flask --app wsgi migrate-db` / `init-db`. **Faça backup do banco antes**, como já recomendado no README.
- Pedidos antigos continuam íntegros; eles simplesmente não têm linhas de aviso (o detalhe mostra a tabela vazia) e não recebem mensagens retroativas.

## Variáveis de ambiente novas (sem valores secretos)
`WHATSAPP_API_ENABLED`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN` (**segredo**), `WHATSAPP_TEAM_NUMBER`, `WHATSAPP_TEMPLATE_CLIENT`, `WHATSAPP_TEMPLATE_TEAM`,
`WHATSAPP_TEMPLATE_LANGUAGE`, `WHATSAPP_API_VERSION`, `WHATSAPP_API_TIMEOUT`, `WHATSAPP_MAX_ATTEMPTS`. O `.env.example` já traz `WHATSAPP_NUMBER=5541996206276` e o link exato do iFood.

## Ainda depende de você / de aprovação externa
- Conta Meta verificada, número habilitado, **ID do número**, **token**, e **aprovação dos dois modelos** (`docs/WHATSAPP_API.md`).
- Decidir o **número de destino da equipe** (não pode ser o remetente da API).
- Revisar o texto de consentimento com o jurídico/LGPD.
- Homologar o envio real (nenhuma mensagem real foi enviada durante o desenvolvimento).

## Limitações reais
- **iFood:** não há integração oficial documentada para transferir carrinho; o botão só abre a loja. Abrir o iFood não conclui nem altera o pedido KNAZH.
- **WhatsApp:** “enviado” = aceito pela API; sem *webhooks*, entrega/leitura não são acompanhadas. Tempo esgotado é ambíguo (a mensagem pode ter saído).
- Uma categoria criada pelo botão fica ativa e aparece vazia no menu público até receber um produto.
- Taxa de entrega **não** foi criada: continua “A combinar” (a imagem de referência mostrava R$ 5,00, mas não há regra definida).

## Como reverter
1. **Código:** restaure o ZIP/branch anterior (os arquivos novos podem ser apagados sem efeito colateral). Sem o código novo, a tabela `order_notifications` fica **ignorada**.
2. **Banco:** nenhuma coluna existente foi tocada. Se quiser, remova a tabela nova depois de backup: `DROP TABLE order_notifications;` (opcional).
3. **Configuração:** remova as variáveis `WHATSAPP_*` do `.env` (ou mantenha `WHATSAPP_API_ENABLED=false`) e **revogue o token** na plataforma da Meta se ele tiver sido criado.

## Verificações feitas e NÃO feitas (leia)
**Feitas neste ambiente (sem rede e sem Flask-SQLAlchemy/Flask-WTF/pytest instalados):** compilação de todo o código e dos testes; análise de sintaxe de todos os templates;
render dos templates novos/alterados com objetos falsos e `StrictUndefined` (inclui escape de HTML); importação dos módulos com bibliotecas simuladas; verificação de sintaxe do JavaScript;
e testes do cliente HTTP do WhatsApp contra um servidor local falso (sucesso, resposta sem identificador, 401, 502, tempo esgotado, conexão recusada, vazamento de token/telefone) — reproduzíveis com `python tools/verificar_whatsapp_offline.py` na raiz do projeto.

**NÃO executadas:** a suíte **pytest** (nem antes nem depois — o ambiente não conseguia instalar as dependências); portanto os testes novos (`test_categories.py`, `test_notifications.py`,
`test_orders_admin.py`) e os ajustes em `test_admin.py` **foram escritos mas não rodados**. Também **não** houve verificação visual em navegador/celular, migração em cópia de banco real,
nem envio real de WhatsApp. Rode `pip install -r requirements-dev.txt && python -m pytest -q` e me envie a saída para corrigirmos qualquer falha.
