# Deploy e operação

> Nada aqui foi executado em servidor real. É o roteiro para você (ou quem cuida da infraestrutura) seguir e verificar.

## 1. Variáveis de ambiente (arquivo `.env` na raiz; veja `.env.example`)
Obrigatórias em produção: `KNAZH_ENV=production`, `SECRET_KEY` (forte e **persistente**: `python -c "import secrets; print(secrets.token_hex(32))"`).
Canais: `WHATSAPP_NUMBER`, `IFOOD_STORE_URL`, `INSTAGRAM_URL`, `FACEBOOK_URL`. Atrás de proxy: `TRUSTED_PROXY_COUNT=1`, `TRUSTED_HOSTS=seu-dominio,www.seu-dominio`.
`SITE_URL=https://seu-dominio` (canonical/sitemap e URL pública dos links de confirmação). Com `EMAIL_VERIFICATION_REQUIRED=true` (padrão), configure SMTP: `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM`, `SMTP_USE_TLS` e credenciais `SMTP_USERNAME`/`SMTP_PASSWORD` quando exigidas pelo provedor. Para Gmail, use `smtp.gmail.com:587`, TLS e senha de app. Sem SMTP, o cadastro fica temporariamente indisponível; credenciais de SMTP nunca devem ir para o Git. O link padrão expira em 24 horas (`EMAIL_VERIFICATION_MAX_AGE=86400`) e o reenvio é limitado a cinco pedidos por endereço a cada hora. Opcionais: API oficial do WhatsApp (`WHATSAPP_*`). **Nunca** versionar o `.env`.

## 2. Primeira instalação
```
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python -m flask --app wsgi migrate-db          # cria/atualiza tabelas (não apaga dados)
python -m flask --app wsgi provision-initial-admin
```

## 3. Executar
`gunicorn wsgi:app --workers 2 --threads 4 --timeout 30 --bind 127.0.0.1:8000` (o limitador de tentativas é compartilhado via banco).
Reinicie com `systemctl restart` (exemplo de serviço: `Restart=on-failure`, usuário sem privilégios, `EnvironmentFile=/caminho/.env`).

## 4. Nginx + HTTPS (esboço)
```
server { listen 80; server_name seu-dominio www.seu-dominio; return 301 https://$host$request_uri; }
server {
  listen 443 ssl http2; server_name seu-dominio www.seu-dominio;
  ssl_certificate     /etc/letsencrypt/live/seu-dominio/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/seu-dominio/privkey.pem;
  ssl_protocols TLSv1.2 TLSv1.3;
  client_max_body_size 6m;                      # fotos de produto (limite do app: 5 MiB + folga)
  gzip on; gzip_types text/css application/javascript image/svg+xml;
  location /static/ { alias /caminho/KNAZH_SITE/knazh/static/; expires 7d; }
  location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host; proxy_set_header X-Forwarded-For $remote_addr; proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 30s;
  }
}
```
Certificado: `certbot --nginx -d seu-dominio -d www.seu-dominio` e confirme a renovação automática (`certbot renew --dry-run`).
O site só envia HSTS com `KNAZH_ENV=production`; ative HTTPS antes. O app já envia CSP, X-Content-Type-Options, Referrer-Policy, Permissions-Policy e X-Frame-Options.

## 5. Dados persistentes e backup
Persistir **`instance/knazh.db`** e **`knazh/static/uploads/products/`** entre deploys. Agende (cron diário):
`python -m flask --app wsgi backup-db --dir /var/backups/knazh --keep 14` e envie as cópias para fora do servidor **cifradas** (`age`/`gpg`).
Teste a restauração em uma cópia (README, seção "Produção").

## 6. Checklist de liberação (marque cada item com evidência)
- [ ] `check-email-config` sem avisos e `test-email SEU@EMAIL` entregue (confirmação de cadastro depende do SMTP; veja `docs/EMAIL_VERIFICACAO.md`)
- [ ] `pytest -q` sem falhas · [ ] `pip-audit -r requirements.txt` sem vulnerabilidades · [ ] `/saude` retorna 200 pelo domínio
- [ ] HTTPS válido, HTTP redireciona, sem conteúdo misto · [ ] `KNAZH_ENV=production`, sem debug · [ ] `.env` fora do Git/ZIP
- [ ] Backup executado **e restaurado em teste** · [ ] WhatsApp e iFood abrem a conversa/loja corretas no celular
- [ ] Layout conferido em 320/360/375/390/414/480/768/1024/1280/1440/1920 px (celular real e navegador)
- [ ] Textos de privacidade/termos revisados pela KNAZH e por profissional jurídico

## 7. Rollback
Antes de atualizar: `backup-db` + guardar a pasta/ZIP anterior. As migrações só adicionam tabelas/colunas; o código anterior as ignora.
Para voltar: parar o serviço, restaurar o código anterior (e o banco do backup, se algo foi corrompido), `migrate-db`, iniciar e conferir `/saude`.
