# Limitações e pendências (registradas com honestidade)

## Não implementado de propósito (dependem de dados/serviços ainda não fornecidos)
- Pagamento online, cálculo de frete, opções de entrega/retirada, horários — não definidos pela KNAZH.
- **Integração de pedidos com o iFood:** não existe. O portal oficial de desenvolvedores do iFood documenta APIs para a LOJA receber e gerenciar pedidos (pedidos, cardápio,
  loja); não encontramos recurso oficial para um site externo montar o carrinho de um cliente no iFood. Por isso o botão só ABRE a loja (link fornecido) e o cliente
  confere os itens lá. Só vale desenvolver transferência de carrinho se o iFood documentar e autorizar um recurso oficial (e for testável).
- **Envio automático de WhatsApp:** implementado com a API oficial, mas **desligado até haver credenciais**. Depende de conta Meta verificada, número habilitado,
  modelos aprovados e do consentimento do cliente (caixa no checkout). Entrega/leitura no celular não são acompanhadas (exigiriam webhooks). Veja `docs/WHATSAPP_API.md`.
- Recuperação de senha por e-mail (exigiria serviço de e-mail; não foi simulada).
- Painel administrativo (será o GabHub). Endereços/notificações da "Minha conta" não existem e por isso não aparecem.
- Opções de produto da referência (escolha de sabor/adicionais) — exigiriam dados reais de catálogo.
- Domínio, e-mail e redes oficiais: configuráveis por `.env`; nada foi inventado.

## Conteúdo provisório (revisar)
- Textos de "Sobre", privacidade e termos são provisórios e marcados na tela. Respostas de FAQ sem dado real aparecem como "Informação pendente".
- Preços, popularidade e imagens dos produtos são de demonstração.
- Fontes de marca originais não foram fornecidas; usadas Fredoka/DM Sans/Caveat (OFL) como aproximação.

## Testes
- Automatizados (pytest): rodam sem rede nem serviços externos. SMTP é testado com simulação; **não** foi testado com servidor real.
- WhatsApp/iFood: testada a geração dos links; **não** foi verificada a abertura nos apps/lojas reais.
- Avisos automáticos de WhatsApp: testados só com uma API **simulada** (e a camada HTTP também contra um servidor local falso). **Nenhuma mensagem real foi enviada**; o envio real
  só pode ser homologado com credenciais, número e modelos aprovados da KNAZH.
- Verificação visual feita em Chromium (Playwright) em 1366 px e 384 px (referência Galaxy A15); **não** foi testado em aparelho físico
  nem com teclado virtual real. Desempenho (Lighthouse etc.) **não** foi medido.
- Limitador de login é em memória, por processo.

## Painel administrativo (primeira versão)
- Catálogo de produtos e pedidos: sem Clientes, Configurações nem tela própria de gerenciamento de categorias (a categoria nova nasce no cadastro do produto; renomear, reordenar,
  desativar ou excluir categorias continua fora do painel).
- Pedidos: o painel lista, detalha, atualiza o estado e reenvia avisos. Mudar o estado não notifica o cliente. Não há pagamento, rastreio de entrega nem registro de auditoria.
- Uma foto principal por produto (sem galeria). Fotos em `knazh/static/uploads/products/` exigem armazenamento persistente e backup.
- A migração (`migrate-db`) cobre `customers.is_admin` e `customers.can_manage_admins`; mudanças futuras de esquema devem entrar em `knazh/migrations.py`.
- Gerenciar administradores: só dois níveis (administrador do catálogo e gestor de administradores). Não há e-mail de aviso ao conceder/remover acesso,
  nem registro de auditoria (quem alterou o quê), nem verificação de e-mail no cadastro. A proteção contra remover o último gestor foi testada em SQLite;
  em outros bancos ela depende do isolamento da transação (uma instrução condicional única, mas sem teste de concorrência real aqui).
- Produto "indisponível" continua visível no cardápio público (com selo e sem compra); não existe estado "rascunho/não publicado" separado.
- O limitador de login continua por processo (veja README).
