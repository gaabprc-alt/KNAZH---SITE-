# Confirmação de e-mail no cadastro

**Fluxo:** cadastro → conta criada **não verificada** (sem login) → e-mail enviado ao endereço digitado → cliente clica em
**Confirmar meu e-mail** → o servidor valida o token → conta marcada como verificada → só então o login funciona.
O site **não** tenta descobrir se a caixa postal existe: quem não recebe o link não consegue confirmar nem entrar.

## Como funciona (resumo técnico)
- Token: `secrets.token_urlsafe(32)` (256 bits). No banco fica **só o SHA-256**; o token puro existe apenas no link do e-mail.
- Um único token ativo por conta: gerar outro (reenvio ou novo cadastro) invalida o anterior. Validade: `EMAIL_VERIFICATION_MAX_AGE` (padrão 86400 s = 24 h).
- **Uso único:** ao confirmar, `email_verified=True`, `email_verified_at` é preenchido e hash e validade são apagados na mesma operação (UPDATE condicional).
  Abrir o link de novo mostra "já foi usado, é inválido ou expirou"; se o e-mail já estava confirmado basta entrar.
- Login: senha certa + e-mail não confirmado = **sem sessão**, com atalho para reenviar. A regra é do servidor (e `load_customer` ignora sessões de contas não verificadas).
- Reenvio: resposta sempre genérica (não revela se a conta existe); limites de **5/hora por e-mail** e **15/hora por IP**, guardados no banco (valem para todos os workers).
- Quem refaz o cadastro com um e-mail **nunca confirmado** assume o registro pendente (senha nova, link antigo invalidado). Isso impede que alguém "reserve" o e-mail de outra pessoa. Contas confirmadas e administradores nunca são sobrescritos.
- Contas existentes antes da funcionalidade: a migração as marca como verificadas. Administrador criado por `provision-initial-admin` já nasce verificado.
- Se o SMTP falhar no cadastro: a conta fica pendente (nada é apagado nem autenticado) e o cliente pode pedir novo link em `/conta/verificar-email`.
- Se `EMAIL_VERIFICATION_REQUIRED=true` e o SMTP estiver incompleto, o **cadastro fica indisponível** (HTTP 503 com mensagem amigável) em vez de criar contas que ninguém consegue confirmar.

## Configuração (`.env`)
```
EMAIL_VERIFICATION_REQUIRED=true
EMAIL_VERIFICATION_MAX_AGE=86400
SITE_URL=https://SEU-DOMINIO.com.br        # sem barra final; em desenvolvimento: http://127.0.0.1:5000
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587                              # 465 também é aceito (SSL direto)
SMTP_USE_TLS=true                          # STARTTLS com validação do certificado
SMTP_USERNAME=SEU_EMAIL@gmail.com
SMTP_PASSWORD=SUA_SENHA_DE_APP
SMTP_FROM=SEU_EMAIL@gmail.com
```
`CONTACT_EMAIL_TO` serve **só** ao formulário de contato; a confirmação de cadastro não depende dele. O `.env` é lido automaticamente
(`knazh/__init__.py` chama `load_dotenv` na raiz do projeto) por `flask`, `gunicorn` e `wsgi.py`; ele **nunca** vai para o Git.
O `.env.example` traz o remetente comentado para que copiá-lo não ative credenciais falsas.

## Gmail com Senha de app
1. Conta Google → **Segurança** → ative a **Verificação em duas etapas**.
2. Na mesma área, abra **Senhas de app**, crie uma (nome sugerido: "KNAZH") e copie as 16 letras.
3. `SMTP_PASSWORD` = essa senha de app (nunca a senha normal). `SMTP_USERNAME` = o Gmail remetente. `SMTP_FROM` = o mesmo Gmail.
4. Se **Senhas de app** não aparecer, a conta (ou a organização Google Workspace) pode ter bloqueado o recurso: peça liberação ao administrador do Workspace
   ou use outro provedor SMTP.
5. Um domínio próprio melhora a entrega com **SPF, DKIM e DMARC** (DNS; não implementado aqui). Nenhum e-mail tem chegada garantida na Caixa de entrada: o provedor do destinatário decide.

## Comandos
```
python -m flask --app wsgi migrate-db                     # adiciona as colunas e o índice (idempotente; contas antigas ficam verificadas)
python -m flask --app wsgi check-email-config             # mostra o que está configurado (nunca exibe senhas) e avisos
python -m flask --app wsgi test-email SEU@EMAIL.com       # envia UM e-mail de teste (não cria usuário; nunca roda sozinho)
python -m pytest -q
```

## Teste manual completo
1. Preencha o `.env` (veja acima; em desenvolvimento `SITE_URL=http://127.0.0.1:5000`), rode `migrate-db` e `test-email` para o seu endereço.
2. `python -m flask --app wsgi run` e abra `/conta/cadastrar`.
3. Cadastre um e-mail seu. O site **não** loga você e mostra "Confirme seu e-mail".
4. Abra o e-mail "Confirme seu e-mail — KNAZH" (veja o Spam) e clique em **Confirmar meu e-mail**.
5. O site avisa "E-mail confirmado!"; agora o login em `/conta/entrar` funciona. Abrir o mesmo link outra vez não faz nada.
6. Cadastre um e-mail inventado: a conta fica não verificada e o login é recusado.

## Limitações conhecidas
- Alguns provedores/antivírus abrem links de e-mail automaticamente. Como o link é de uso único, o cliente pode ver "já foi usado" mesmo tendo a conta confirmada; nesse caso basta entrar.
- Se alguém cadastrar o e-mail de outra pessoa e ela clicar no link recebido sem ter pedido, a conta passa a existir com a senha de quem cadastrou. O e-mail avisa para ignorar quando não houve cadastro; proteção total exigiria definir a senha só após a confirmação.
- O tempo de resposta do reenvio pode diferir quando existe conta pendente (há envio SMTP), o que permite inferência por tempo. A mensagem é idêntica.
- Em produção com `SITE_URL` vazio, `http://` ou local, o servidor registra aviso/erro na inicialização (`check-email-config` mostra o problema).
