"""Verificação OFFLINE do cliente HTTP do WhatsApp (knazh/services/whatsapp.py) contra um servidor local falso.

Não usa a rede, credenciais reais nem o banco; só a biblioteca padrão. Rode na RAIZ do projeto:
    python tools/verificar_whatsapp_offline.py
Não é coletado pelo pytest (o nome não começa com test_).
"""
import importlib.util, io, json, threading, urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer

spec = importlib.util.spec_from_file_location("wa", "knazh/services/whatsapp.py")
import sys; wa = importlib.util.module_from_spec(spec); sys.modules["wa"] = wa; spec.loader.exec_module(wa)

S = wa.WhatsAppSettings(enabled=True, phone_number_id="123456789012345", access_token="SEGREDO-TOKEN-XYZ", api_version="v25.0", timeout=2)
seen = {}

class H(BaseHTTPRequestHandler):
    mode = "ok"
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); seen["body"] = json.loads(self.rfile.read(n)); seen["auth"] = self.headers.get("Authorization"); seen["path"] = self.path
        if H.mode == "ok":
            out, code = {"messaging_product": "whatsapp", "contacts": [{"input": "x", "wa_id": "x"}], "messages": [{"id": "wamid.HBgM123=="}]}, 200
        elif H.mode == "noid":
            out, code = {"messaging_product": "whatsapp"}, 200
        elif H.mode == "401":
            out, code = {"error": {"message": "Invalid OAuth access token SEGREDO-TOKEN-XYZ for 5541996206276", "type": "OAuthException", "code": 190}}, 401
        elif H.mode == "html":
            self.send_response(502); self.end_headers(); self.wfile.write(b"<html>bad gateway</html>"); return
        b = json.dumps(out).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass

srv = HTTPServer(("127.0.0.1", 0), H); port = srv.server_port
threading.Thread(target=srv.serve_forever, daemon=True).start()
wa.GRAPH_BASE = f"http://127.0.0.1:{port}"

# sucesso
r = wa.send_template(S, to="5541996206276", template="knazh_novo_pedido_equipe", params=["KNZ-000001", "Maria\nSilva", "  ", "2x Brownie;\t1x Cookie", "R$ 40,00", ""])
assert r.message_id == "wamid.HBgM123==", r
assert seen["path"] == "/v25.0/123456789012345/messages" and seen["auth"] == "Bearer SEGREDO-TOKEN-XYZ"
b = seen["body"]; assert b["messaging_product"] == "whatsapp" and b["type"] == "template" and b["to"] == "5541996206276"
assert b["template"]["name"] == "knazh_novo_pedido_equipe" and b["template"]["language"] == {"code": "pt_BR"}
texts = [p["text"] for p in b["template"]["components"][0]["parameters"]]
assert texts == ["KNZ-000001", "Maria Silva", "-", "2x Brownie; 1x Cookie", "R$ 40,00", "-"], texts
print("sucesso OK", texts)

# sem identificador = NÃO é sucesso
H.mode = "noid"
try: wa.send_template(S, to="5541996206276", template="t", params=[]); raise SystemExit("deveria falhar")
except wa.WhatsAppError as e: assert "sem confirmar" in e.safe_message; print("sem id OK:", e.safe_message)

# 401: token e telefone nunca vazam
H.mode = "401"
try: wa.send_template(S, to="5541996206276", template="t", params=["a"]); raise SystemExit("deveria falhar")
except wa.WhatsAppError as e:
    m = e.safe_message; assert "SEGREDO" not in m and "5541996206276" not in m and "HTTP 401" in m and "190" in m, m; print("401 OK:", m)

H.mode = "html"
try: wa.send_template(S, to="5541996206276", template="t", params=[]); raise SystemExit("deveria falhar")
except wa.WhatsAppError as e: assert "HTTP 502" in e.safe_message; print("502 OK:", e.safe_message)

# timeout (servidor que não responde)
import socket
s2 = socket.socket(); s2.bind(("127.0.0.1", 0)); s2.listen(1); wa.GRAPH_BASE = f"http://127.0.0.1:{s2.getsockname()[1]}"
S_fast = wa.WhatsAppSettings(enabled=True, phone_number_id="123456789012345", access_token="t", timeout=0.5)
try: wa.send_template(S_fast, to="5541996206276", template="t", params=[]); raise SystemExit("deveria falhar")
except wa.WhatsAppError as e: assert "Tempo esgotado" in e.safe_message and "pode ter sido enviada" in e.safe_message; print("timeout OK")

# conexão recusada
wa.GRAPH_BASE = "http://127.0.0.1:1"
try: wa.send_template(S_fast, to="5541996206276", template="t", params=[]); raise SystemExit("deveria falhar")
except wa.WhatsAppError as e: print("conexão recusada OK:", e.safe_message)

# validações / configuração
assert not wa.WhatsAppSettings().configured and "WHATSAPP_API_ENABLED" in wa.WhatsAppSettings().missing()
assert wa.WhatsAppSettings(enabled=True, phone_number_id="abc", access_token="x").missing() == ["WHATSAPP_PHONE_NUMBER_ID"]
for bad in [dict(to="123"), dict(template="Nome Inválido"), dict(to="5541996206276; DROP")]:
    kw = dict(to="5541996206276", template="ok_tpl", params=[]); kw.update(bad)
    try: wa.send_template(S, **kw); raise SystemExit("deveria falhar " + str(bad))
    except wa.WhatsAppError: pass
try: wa.send_template(wa.WhatsAppSettings(), to="5541996206276", template="t", params=[]); raise SystemExit("x")
except wa.WhatsAppError as e: assert "não configurada" in e.safe_message
assert wa.clean_param("a" * 900).endswith("…") and len(wa.clean_param("a" * 900)) == 600 and wa.clean_param(None) == "-"

# mock de _urlopen com HTTPError e corpo JSON
wa.GRAPH_BASE = "https://graph.facebook.com"
def fake(req, timeout=None): raise urllib.error.HTTPError(req.full_url, 400, "Bad", {}, io.BytesIO(json.dumps({"error": {"code": 131030, "message": "Recipient phone number not in allowed list"}}).encode()))
wa._urlopen = fake
try: wa.send_template(S, to="5541996206276", template="t", params=[])
except wa.WhatsAppError as e: assert "131030" in e.safe_message and "allowed list" in e.safe_message; print("HTTPError mock OK:", e.safe_message)
print("TODOS OS TESTES OFFLINE DO whatsapp.py PASSARAM")
