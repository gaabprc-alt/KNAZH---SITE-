"""Limitador compartilhado, visão geral do painel, /saude, robots e textos de privacidade."""
import re

from knazh import create_app
from knazh.config import TestConfig
from knazh.extensions import db
from knazh.models import ContactMessage, Customer, RateLimitHit
from knazh.services.security import Throttle
from tests.test_admin import admin_client, token, user_client  # noqa: F401
from tests.test_orders_admin import admin_post, place_order


# ---------------------------------------------------------------- limitador
def test_throttle_counts_per_key_hashes_keys_and_resets(app):
    t = Throttle("t", limit=3, window_seconds=60)
    for _ in range(2):
        t.hit("203.0.113.9|ana@example.com")
    assert not t.blocked("203.0.113.9|ana@example.com")
    t.hit("203.0.113.9|ana@example.com")
    assert t.blocked("203.0.113.9|ana@example.com") and not t.blocked("outra-chave")
    stored = [h.key for h in db.session.scalars(db.select(RateLimitHit))]
    assert stored and all(re.fullmatch(r"[0-9a-f]{64}", k) for k in stored)
    assert not any("ana@example.com" in k or "203.0.113.9" in k for k in stored)  # nada em texto aberto
    t.reset("203.0.113.9|ana@example.com")
    assert not t.blocked("203.0.113.9|ana@example.com")


def test_throttle_is_shared_between_processes_using_the_same_database(tmp_path):
    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{tmp_path / 'shared.db'}"
    worker_a, worker_b = create_app(Cfg), create_app(Cfg)  # dois "workers" no mesmo banco
    t = Throttle("login-x", limit=2, window_seconds=60)
    with worker_a.app_context():
        t.hit("k"); t.hit("k")
    with worker_b.app_context():
        assert t.blocked("k")  # o outro worker enxerga as tentativas


def test_login_is_blocked_after_repeated_failures_even_with_correct_password(client, post):
    with client.application.app_context():
        c = Customer(name="Ana", email="ana@example.com", phone="41999990000")
        c.set_password("SenhaForte#2026")
        db.session.add(c)
        db.session.commit()
    for _ in range(5):
        r = post("/conta/entrar", {"email": "ana@example.com", "password": "errada", "next": ""}, token_from="/conta/entrar", follow=True)
        assert "E-mail ou senha incorretos" in r.get_data(as_text=True)
    r = post("/conta/entrar", {"email": "ana@example.com", "password": "SenhaForte#2026", "next": ""}, token_from="/conta/entrar", follow=True)
    assert "Muitas tentativas" in r.get_data(as_text=True)


def test_contact_form_is_rate_limited_per_ip(client, post):
    data = {"name": "Ana", "email": "ana@example.com", "subject": "Dúvida", "message": "Olá, uma dúvida sobre o cardápio."}
    codes = [post("/contato", data, token_from="/contato").status_code for _ in range(6)]
    assert codes[:5] == [302] * 5 and codes[5] == 429
    assert db.session.query(ContactMessage).count() == 5


# ---------------------------------------------------------------- visão geral
def test_dashboard_shows_real_numbers_and_empty_state(client, post, fill_cart, admin_client):
    html = admin_client.get("/admin/").get_data(as_text=True)
    assert "Visão geral" in html and "Ainda não há pedidos" in html and "Produtos cadastrados" in html
    order = place_order(client, post, fill_cart)
    place_order(client, post, fill_cart, items=(("cookie", 1),))
    admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {"status": "cancelado", "reason": "Sem estoque hoje", "confirmar": "1"})
    admin_client.get(f"/admin/pedidos/{order.id}")  # consome o aviso
    html = admin_client.get("/admin/").get_data(as_text=True)
    assert re.search(r"<strong>1</strong><span>Aguardando confirmação", html) and re.search(r"<strong>1</strong><span>Cancelados", html)
    assert "Ainda não há pedidos" not in html and order.number in html
    assert "99999-1234" not in html and "Maria Silva" not in html  # sem dados pessoais na visão geral
    total = db.session.scalar(db.text("select count(*) from products"))
    assert re.search(rf"<strong>{total}</strong><span>Produtos cadastrados", html)


# ---------------------------------------------------------------- saúde, robots, privacidade
def test_health_endpoint_reports_ok_without_internal_details(client):
    r = client.get("/saude")
    assert r.status_code == 200 and r.get_json() == {"status": "ok"} and r.headers["Cache-Control"] == "no-store"


def test_robots_blocks_private_areas_and_admin_pages_are_noindex(client, admin_client):
    body = client.get("/robots.txt").get_data(as_text=True)
    for path in ("/admin", "/conta", "/pedido/", "/finalizar", "/carrinho"):
        assert f"Disallow: {path}" in body
    assert "noindex" in admin_client.get("/admin/").get_data(as_text=True)
    assert "/admin" not in client.get("/sitemap.xml").get_data(as_text=True)


def test_privacy_text_matches_real_data_flows(client):
    html = client.get("/privacidade").get_data(as_text=True)
    assert "WhatsApp Business Platform" in html and "motivo" in html and "hash" in html
    assert "O site não envia seus dados a terceiros" not in html  # afirmação que deixou de ser verdadeira
    assert "pendente de revisão" in html  # continua marcado como rascunho
