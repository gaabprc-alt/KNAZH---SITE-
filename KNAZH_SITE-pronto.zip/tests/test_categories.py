"""Criação de categoria direto no cadastro de produto (painel administrativo)."""
import pytest
from sqlalchemy.exc import OperationalError

from knazh.extensions import db
from knazh.models import Category, Product
from tests.test_admin import (admin_client, create_product, png, product_data, submit, token,  # noqa: F401
                              uploaded_files)


def categories():
    return list(db.session.scalars(db.select(Category).order_by(Category.id)))


def by_slug(slug):
    return db.session.scalar(db.select(Category).where(Category.slug == slug))


def test_product_form_offers_existing_and_new_category(admin_client):
    html = admin_client.get("/admin/produtos/novo").get_data(as_text=True)
    assert 'id="category_id"' in html and "Brownies" in html  # categorias existentes continuam
    assert "Criar nova categoria" in html and 'id="new_category"' in html
    assert 'data-url="/admin/categorias/nova"' in html and "data-newcat-btn" in html


def test_new_category_is_created_with_the_product_and_selected(app, admin_client):
    before = categories()
    r = submit(admin_client, "/admin/produtos/novo",
               product_data(name="Copo Especial", new_category="  Copos   da Felicidade "), png())
    assert r.status_code == 302, r.get_data(as_text=True)[:400]
    created = by_slug("copos-da-felicidade")
    assert created is not None and created.name == "Copos da Felicidade" and created.is_active
    product = db.session.scalar(db.select(Product).where(Product.name == "Copo Especial"))
    assert product.category_id == created.id
    assert len(categories()) == len(before) + 1
    assert created.sort_order == max(c.sort_order for c in before) + 1
    # a categoria nova já aparece na lista de escolha dos próximos produtos
    assert f'value="{created.id}"' in admin_client.get("/admin/produtos/novo").get_data(as_text=True)


def test_new_category_alone_is_enough_even_without_choosing_an_existing_one(admin_client):
    r = submit(admin_client, "/admin/produtos/novo", product_data(name="Sem Existente", category_id="", new_category="Tortinhas"), png())
    assert r.status_code == 302
    assert db.session.scalar(db.select(Product).where(Product.name == "Sem Existente")).category.name == "Tortinhas"


def test_category_is_still_required_without_new_one(app, admin_client):
    before = db.session.query(Product).count()
    r = submit(admin_client, "/admin/produtos/novo", product_data(category_id="", new_category="   "), png())
    assert r.status_code == 200 and "Escolha uma categoria" in r.get_data(as_text=True)
    assert db.session.query(Product).count() == before and uploaded_files(app) == []


@pytest.mark.parametrize("typed", ["brownies", "  BROWNIES  ", "BrOwNiEs"])
def test_duplicate_names_are_rejected_ignoring_case_and_spaces(app, admin_client, typed):
    before, products = categories(), db.session.query(Product).count()
    r = submit(admin_client, "/admin/produtos/novo", product_data(name="Duplicada", new_category=typed), png())
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and "Já existe a categoria" in html and "Brownies" in html
    assert [c.id for c in categories()] == [c.id for c in before]
    assert db.session.query(Product).count() == products and uploaded_files(app) == []
    assert f'value="{typed.strip()}"' in html  # o texto digitado não se perde no formulário


def test_duplicate_is_detected_by_accents_and_slug(admin_client):
    first = submit(admin_client, "/admin/produtos/novo", product_data(name="Mel 1", new_category="Pão de Mel"), png())
    assert first.status_code == 302
    for typed in ("pao de mel", "PÃO DE MEL", "Pão-de-mel"):
        r = submit(admin_client, "/admin/produtos/novo", product_data(name="Mel x", new_category=typed), png())
        assert r.status_code == 200 and "Já existe a categoria" in r.get_data(as_text=True), typed
    assert db.session.query(Category).filter(Category.slug == "pao-de-mel").count() == 1


@pytest.mark.parametrize("typed", ["A", "x" * 61, "!!!", "..."])
def test_invalid_new_category_names_are_rejected(app, admin_client, typed):
    before, products = len(categories()), db.session.query(Product).count()
    r = submit(admin_client, "/admin/produtos/novo", product_data(name="Inválida", new_category=typed), png())
    assert r.status_code == 200 and 'field--error' in r.get_data(as_text=True)
    assert len(categories()) == before and db.session.query(Product).count() == products and uploaded_files(app) == []


def test_new_category_while_editing_a_product_moves_it_and_keeps_the_rest(admin_client):
    product = create_product(admin_client, name="Para Mover")
    old_category, slug = product.category_id, product.slug
    r = submit(admin_client, f"/admin/produtos/{product.id}/editar",
               product_data(name="Para Mover", new_category="Festas"), None)
    assert r.status_code == 302
    db.session.expire_all()
    product = db.session.get(Product, product.id)
    assert product.category.name == "Festas" and product.slug == slug and product.category_id != old_category
    assert db.session.get(Category, old_category) is not None  # a categoria anterior continua existindo


def test_duplicate_while_editing_changes_nothing(admin_client):
    product = create_product(admin_client, name="Edição Duplicada")
    r = submit(admin_client, f"/admin/produtos/{product.id}/editar",
               product_data(name="Outro Nome", new_category="brownies"), None)
    assert r.status_code == 200 and "Já existe a categoria" in r.get_data(as_text=True)
    db.session.expire_all()
    assert db.session.get(Product, product.id).name == "Edição Duplicada"


def test_failed_product_save_does_not_leave_the_new_category_behind(app, admin_client, monkeypatch):
    before = len(categories())
    real_commit = db.session.commit

    def boom():
        raise OperationalError("x", {}, Exception("falha simulada"))

    monkeypatch.setattr(db.session, "commit", boom)
    r = submit(admin_client, "/admin/produtos/novo", product_data(name="Falha", new_category="Categoria Fantasma"), png())
    monkeypatch.setattr(db.session, "commit", real_commit)
    assert r.status_code == 200 and "Traceback" not in r.get_data(as_text=True)
    db.session.rollback()
    assert len(categories()) == before and by_slug("categoria-fantasma") is None
    assert uploaded_files(app) == []


# ---------------------------------------------------------------- endpoint usado pelo botão "Criar categoria"
def post_category(client, name, **kw):
    return client.post("/admin/categorias/nova", data={"name": name}, headers={"X-CSRFToken": token(client)}, **kw)


def test_category_endpoint_creates_it_and_returns_json(admin_client):
    before = len(categories())
    r = post_category(admin_client, "Copos da Felicidade")
    data = r.get_json()
    assert r.status_code == 201 and data["ok"] is True and data["name"] == "Copos da Felicidade"
    assert len(categories()) == before + 1 and db.session.get(Category, data["id"]).slug == "copos-da-felicidade"
    html = admin_client.get("/admin/produtos/novo").get_data(as_text=True)
    assert f'<option value="{data["id"]}"' in html and "Copos da Felicidade" in html  # disponível para seleção na hora
    r = submit(admin_client, "/admin/produtos/novo", product_data(name="Com Nova", category_id=str(data["id"])), png())
    assert r.status_code == 302


def test_category_endpoint_never_duplicates_and_points_to_the_existing_one(admin_client):
    first = post_category(admin_client, "Sazonais").get_json()
    before = len(categories())
    r = post_category(admin_client, "  SAZONAIS ")
    data = r.get_json()
    assert r.status_code == 400 and data["ok"] is False and data["existing_id"] == first["id"]
    assert "Já existe" in data["message"] and len(categories()) == before


@pytest.mark.parametrize("name", ["", "   ", "A", "x" * 61, "!!!"])
def test_category_endpoint_validates_the_name(admin_client, name):
    before = len(categories())
    r = post_category(admin_client, name)
    assert r.status_code == 400 and r.get_json()["ok"] is False and len(categories()) == before


def test_category_endpoint_requires_csrf(admin_client):
    before = len(categories())
    r = admin_client.post("/admin/categorias/nova", data={"name": "Sem Token"})
    assert r.status_code == 400 and len(categories()) == before


def test_category_endpoint_rejects_get(admin_client):
    assert admin_client.get("/admin/categorias/nova").status_code == 405


def test_category_endpoint_failure_is_safe(admin_client, monkeypatch):
    real_commit = db.session.commit

    def boom():
        raise OperationalError("x", {}, Exception("falha simulada"))

    monkeypatch.setattr(db.session, "commit", boom)
    r = post_category(admin_client, "Vai Falhar")
    monkeypatch.setattr(db.session, "commit", real_commit)
    db.session.rollback()
    assert r.status_code == 500 and r.get_json()["ok"] is False and "Traceback" not in r.get_data(as_text=True)
    assert by_slug("vai-falhar") is None


def test_existing_categories_are_preserved(admin_client):
    snapshot = [(c.id, c.slug, c.name, c.icon, c.sort_order, c.is_active) for c in categories()]
    post_category(admin_client, "Nova Qualquer")
    after = [(c.id, c.slug, c.name, c.icon, c.sort_order, c.is_active) for c in categories()]
    assert after[:len(snapshot)] == snapshot and len(after) == len(snapshot) + 1
