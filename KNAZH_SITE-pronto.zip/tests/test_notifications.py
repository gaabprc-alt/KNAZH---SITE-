"""Avisos automáticos por WhatsApp (API oficial): sempre depois do pedido salvo, sem duplicar, sem fingir sucesso.

Nenhum teste fala com a rede: `whatsapp_api` (conftest) é uma API falsa e o resto fica bloqueado por `_no_real_whatsapp`.
"""
import re
from datetime import timedelta
from pathlib import Path

import pytest

from knazh.extensions import db
from knazh.models import Order, OrderNotification, utcnow
from knazh.services import notifications, whatsapp
from tests.conftest import VALID_ORDER
from tests.test_cart_checkout import cart_html, checkout_post

TOKEN = "token-falso-de-teste"


def the_order():
    return db.session.scalar(db.select(Order))


def notifs(order=None):
    order = order or the_order()
    db.session.refresh(order)
    return {n.recipient: n for n in order.notifications}


def place(client, post, fill_cart, optin=False, **over):
    fill_cart(("cookie", 1))
    data = {"whatsapp_optin": "y"} if optin else {}
    r = checkout_post(client, post, **data, **over)
    assert r.status_code == 302, r.get_data(as_text=True)[:300]
    return r


# ---------------------------------------------------------------- integração NÃO configurada (padrão e testes)
def test_without_credentials_order_is_saved_and_nothing_is_claimed_sent(app, client, post, fill_cart):
    r = place(client, post, fill_cart)
    order = the_order()
    assert order is not None and order.number.startswith("KNZ-")
    n = notifs(order)
    assert n["equipe"].status == "nao_configurado" and n["equipe"].attempts == 0 and n["equipe"].provider_message_id is None
    assert "WHATSAPP_ACCESS_TOKEN" in n["equipe"].last_error  # diz o que falta (só o NOME da variável)
    assert n["cliente"].status == "dispensado" and n["cliente"].consent_at is None
    html = client.get(r.headers["Location"]).get_data(as_text=True)
    assert "Enviamos um aviso" not in html and "wa.me" not in html


def test_consent_without_credentials_stays_pending_never_sent(client, post, fill_cart):
    r = place(client, post, fill_cart, optin=True)
    n = notifs()
    assert n["cliente"].status == "nao_configurado" and n["cliente"].consent_at is not None
    assert "Enviamos um aviso" not in client.get(r.headers["Location"]).get_data(as_text=True)


def test_checkout_form_asks_for_consent_unchecked_and_optional(client, fill_cart):
    fill_cart(("cookie", 1))
    html = client.get("/finalizar").get_data(as_text=True)
    box = re.search(r'<input[^>]*id="whatsapp_optin"[^>]*>', html).group(0)
    assert 'type="checkbox"' in box and "checked" not in box and "required" not in box
    assert "Opcional" in html and "você autoriza a KNAZH" in html


# ---------------------------------------------------------------- integração configurada (API falsa)
def test_team_and_client_are_notified_after_the_order_is_saved(whatsapp_api, client, post, fill_cart):
    r = place(client, post, fill_cart, optin=True)
    order = the_order()
    assert whatsapp_api.to_numbers() == ["5541900000000", "5541999991234"]  # equipe primeiro; cliente com o telefone do checkout
    team, customer = whatsapp_api.calls
    for call in whatsapp_api.calls:
        assert call["url"].endswith("/v25.0/123456789012345/messages") and call["auth"] == f"Bearer {TOKEN}"
        assert call["body"]["messaging_product"] == "whatsapp" and call["body"]["type"] == "template"
        assert call["body"]["template"]["language"] == {"code": "pt_BR"}
    assert team["body"]["template"]["name"] == "knazh_novo_pedido_equipe"
    assert customer["body"]["template"]["name"] == "knazh_pedido_recebido"
    values = lambda c: [p["text"] for p in c["body"]["template"]["components"][0]["parameters"]]
    assert values(customer) == ["Maria Silva", order.number]
    assert values(team) == [order.number, "Maria Silva", "(41) 99999-1234", "1x Cookie", "R$ 12,00", "Sem granulado"]
    n = notifs(order)
    for key in ("equipe", "cliente"):
        assert n[key].status == "enviado" and n[key].attempts == 1 and n[key].sent_at is not None
        assert n[key].provider_message_id.startswith("wamid.TEST") and n[key].last_error is None
    html = client.get(r.headers["Location"]).get_data(as_text=True)
    assert "Enviamos um aviso de recebimento" in html and "Aguardando confirmação" in html
    assert "não é uma confirmação" in html  # nunca afirma aceite, pagamento ou envio do pedido


def test_client_is_not_messaged_without_consent(whatsapp_api, client, post, fill_cart):
    place(client, post, fill_cart, optin=False)
    assert whatsapp_api.to_numbers() == ["5541900000000"]
    n = notifs()
    assert n["equipe"].status == "enviado" and n["cliente"].status == "dispensado"
    assert n["cliente"].attempts == 0 and n["cliente"].provider_message_id is None


@pytest.mark.parametrize("mode,expected", [("http401", "HTTP 401"), ("timeout", "Tempo esgotado"), ("noid", "sem confirmar")])
def test_api_failure_never_loses_the_order_and_never_claims_success(whatsapp_api, client, post, fill_cart, mode, expected):
    whatsapp_api.mode = mode
    r = place(client, post, fill_cart, optin=True)
    assert db.session.query(Order).count() == 1 and r.status_code == 302
    assert "Seu carrinho está vazio" in cart_html(client)  # pedido salvo: o carrinho foi limpo normalmente
    n = notifs()
    for key in ("equipe", "cliente"):
        assert n[key].status == "falhou" and n[key].attempts == 1 and n[key].sent_at is None
        assert n[key].provider_message_id is None and expected in n[key].last_error
        assert TOKEN not in n[key].last_error and "5541" not in n[key].last_error  # sem token nem telefone no erro guardado
    html = client.get(r.headers["Location"]).get_data(as_text=True)
    assert "Enviamos um aviso" not in html and "Não foi possível enviar o aviso por WhatsApp agora" in html
    assert "Seu pedido continua registrado" in html and the_order().number in html


def test_unexpected_error_in_sender_does_not_break_checkout(whatsapp_api, client, post, fill_cart, monkeypatch):
    def boom(*_a, **_k):
        raise RuntimeError("bug inesperado com " + TOKEN)

    monkeypatch.setattr(whatsapp, "send_template", boom)
    r = place(client, post, fill_cart, optin=True)
    assert r.status_code == 302 and db.session.query(Order).count() == 1
    n = notifs()
    assert n["equipe"].status == "falhou" and "Erro inesperado" in n["equipe"].last_error and TOKEN not in n["equipe"].last_error


def test_error_in_the_notification_step_still_keeps_the_order(whatsapp_api, client, post, fill_cart, monkeypatch):
    monkeypatch.setattr(notifications, "send_for_order", lambda order: (_ for _ in ()).throw(RuntimeError("falha geral")))
    r = place(client, post, fill_cart, optin=True)
    assert r.status_code == 302 and db.session.query(Order).count() == 1
    assert client.get(r.headers["Location"]).status_code == 200


# ---------------------------------------------------------------- idempotência e retentativas
def test_double_submit_sends_each_message_only_once(whatsapp_api, client, post, fill_cart):
    fill_cart(("cookie", 1))
    page = client.get("/finalizar").get_data(as_text=True)
    token = re.search(r'name="submission_token"[^>]*value="([^"]+)"', page).group(1)
    data = {**VALID_ORDER, "submission_token": token, "whatsapp_optin": "y"}
    r1 = post("/finalizar", data, token_from="/finalizar")
    r2 = post("/finalizar", data, token_from="/contato")
    assert r1.headers["Location"] == r2.headers["Location"]
    assert db.session.query(Order).count() == 1 and db.session.query(OrderNotification).count() == 2
    assert len(whatsapp_api.calls) == 2  # equipe + cliente, uma vez cada


def test_sent_notification_is_never_resent(whatsapp_api, client, post, fill_cart):
    place(client, post, fill_cart, optin=True)
    ids = [n.id for n in notifs().values()]
    for notification_id in ids:
        again = notifications.attempt(notification_id)
        assert again.status == "enviado" and again.attempts == 1
    assert len(whatsapp_api.calls) == 2


def test_failed_notification_can_be_retried_without_creating_another_order(whatsapp_api, client, post, fill_cart):
    whatsapp_api.mode = "http401"
    place(client, post, fill_cart)
    team = notifs()["equipe"]
    assert team.status == "falhou" and notifications.can_retry(team)
    whatsapp_api.mode = "ok"
    result = notifications.attempt(team.id)
    assert result.status == "enviado" and result.attempts == 2 and result.last_error is None
    assert db.session.query(Order).count() == 1 and db.session.query(OrderNotification).count() == 2


def test_retry_limit_is_enforced(app, whatsapp_api, client, post, fill_cart):
    app.config["WHATSAPP_MAX_ATTEMPTS"] = 2
    whatsapp_api.mode = "http401"
    place(client, post, fill_cart)  # tentativa 1
    team = notifs()["equipe"]
    assert notifications.attempt(team.id).attempts == 2  # tentativa 2
    team = notifs()["equipe"]
    assert not notifications.can_retry(team)
    assert notifications.attempt(team.id).attempts == 2 and len(whatsapp_api.calls) == 2  # nada além do limite


def test_notification_being_sent_is_not_taken_twice_but_stale_one_is_reclaimed(app, whatsapp_api, client, post, fill_cart):
    app.config["WHATSAPP_API_ENABLED"] = False
    place(client, post, fill_cart)
    app.config["WHATSAPP_API_ENABLED"] = True
    team = notifs()["equipe"]
    team.status, team.last_attempt_at, team.attempts = "enviando", utcnow(), 1
    db.session.commit()
    assert notifications.attempt(team.id).status == "enviando" and whatsapp_api.calls == []  # outra tentativa em andamento
    team = notifs()["equipe"]
    team.last_attempt_at = utcnow() - timedelta(minutes=11)
    db.session.commit()
    assert notifications.attempt(team.id).status == "enviado" and len(whatsapp_api.calls) == 1  # tentativa travada é retomada


def test_pending_command_sends_after_credentials_are_configured(app, client, post, fill_cart, monkeypatch):
    place(client, post, fill_cart, optin=True)  # sem credenciais: nada enviado
    assert {n.status for n in notifs().values()} == {"nao_configurado"}
    runner = app.test_cli_runner()
    out = runner.invoke(args=["send-pending-notifications"]).output
    assert "Nada enviado" in out and "integração não configurada" in out

    from tests.conftest import FakeWhatsAppAPI
    api = FakeWhatsAppAPI()
    monkeypatch.setattr(whatsapp, "_urlopen", api)
    app.config.update(WHATSAPP_API_ENABLED=True, WHATSAPP_PHONE_NUMBER_ID="123456789012345",
                      WHATSAPP_ACCESS_TOKEN=TOKEN, WHATSAPP_TEAM_NUMBER="5541900000000")
    out = runner.invoke(args=["send-pending-notifications"]).output
    assert "2 aviso(s) processado(s); 2 aceito(s)" in out and len(api.calls) == 2
    assert {n.status for n in notifs().values()} == {"enviado"}
    assert "0 aviso(s) processado(s)" in runner.invoke(args=["send-pending-notifications"]).output and len(api.calls) == 2


def test_team_number_falls_back_to_commercial_number(app, whatsapp_api, client, post, fill_cart):
    app.config.update(WHATSAPP_TEAM_NUMBER="", WHATSAPP_NUMBER="5541996206276")
    place(client, post, fill_cart)
    assert whatsapp_api.to_numbers() == ["5541996206276"]


def test_team_notification_pending_when_no_team_number(app, whatsapp_api, client, post, fill_cart):
    app.config.update(WHATSAPP_TEAM_NUMBER="", WHATSAPP_NUMBER="")
    place(client, post, fill_cart)
    assert whatsapp_api.calls == [] and "Número da equipe" in notifs()["equipe"].last_error
    assert notifs()["equipe"].status == "nao_configurado"


# ---------------------------------------------------------------- unidade: payload, limites e segredos
def test_template_parameters_follow_the_platform_rules():
    texts = [p["text"] for p in whatsapp.build_template_payload(
        "5541996206276", "knazh_novo_pedido_equipe", "pt_BR",
        ["linha 1\nlinha 2", "  ", "a\tb", "x" * 700, None])["template"]["components"][0]["parameters"]]
    assert texts[0] == "linha 1 linha 2" and texts[1] == "-" and texts[2] == "a b" and texts[4] == "-"
    assert len(texts[3]) == whatsapp.MAX_PARAM_CHARS and texts[3].endswith("…")
    assert all("\n" not in t and "\t" not in t and "     " not in t for t in texts)  # sem quebra, tab ou 5+ espaços


def test_misconfigured_settings_are_reported_by_variable_name_only():
    bad = whatsapp.WhatsAppSettings(enabled=True, phone_number_id="abc", access_token="", api_version="25")
    assert bad.missing() == ["WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_ACCESS_TOKEN", "WHATSAPP_API_VERSION"] and not bad.configured
    assert whatsapp.WhatsAppSettings(enabled=True, phone_number_id="123456789012345", access_token="x").configured


def test_error_text_hides_token_and_phone_numbers(monkeypatch):
    import io, json, urllib.error
    settings = whatsapp.WhatsAppSettings(enabled=True, phone_number_id="123456789012345", access_token="SEGREDO123")

    def fake(request, timeout=None):
        body = json.dumps({"error": {"code": 190, "message": "token SEGREDO123 inválido para 5541996206276"}}).encode()
        raise urllib.error.HTTPError(request.full_url, 401, "x", {}, io.BytesIO(body))

    monkeypatch.setattr(whatsapp, "_urlopen", fake)
    with pytest.raises(whatsapp.WhatsAppError) as exc:
        whatsapp.send_template(settings, to="5541996206276", template="t", params=["a"])
    text = exc.value.safe_message
    assert "SEGREDO123" not in text and "5541996206276" not in text and "HTTP 401" in text


def test_no_secret_or_api_endpoint_ships_to_the_browser():
    root = Path(__file__).resolve().parents[1] / "knazh"
    for path in list((root / "templates").rglob("*")) + list((root / "static").rglob("*")):
        if path.is_file() and path.suffix in {".html", ".js", ".css", ".json", ".svg", ".txt", ".webmanifest"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
            assert "WHATSAPP_ACCESS_TOKEN" not in text and "graph.facebook.com" not in text, path


def test_token_never_appears_in_any_page(app, whatsapp_api, client, post, fill_cart):
    whatsapp_api.mode = "http401"
    r = place(client, post, fill_cart, optin=True)
    for path in (r.headers["Location"], "/carrinho", "/finalizar", "/"):
        assert TOKEN not in client.get(path).get_data(as_text=True), path
