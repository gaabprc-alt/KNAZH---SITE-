"""Rodapé (redes e ano dinâmico), ícones, gestão de categorias, barra lateral/engrenagem e proxy reverso."""
import re
from datetime import datetime, timezone
from pathlib import Path

import pytest

from knazh import create_app
from knazh.config import TestConfig
from knazh.extensions import db
from knazh.models import Category, Product
from knazh.services import clock
from tests.test_admin import admin_client, token, user_client  # noqa: F401

INSTAGRAM = "https://www.instagram.com/knazh.delivery?mdxt=aDJ6Z3dzbGd3dDU1"
FACEBOOK = "https://www.facebook.com/knazh.delivery?mibextid=wwXIfr"
ROOT = Path(__file__).resolve().parent.parent


def footer(client):
    html = client.get("/").get_data(as_text=True)
    return html[html.index('<footer class="site-footer">'):html.index("</footer>")]


# ---------------------------------------------------------------- redes sociais
def test_footer_social_links_come_from_config_and_are_accessible(app, client):
    app.config.update(INSTAGRAM_URL=INSTAGRAM, FACEBOOK_URL=FACEBOOK)
    html = footer(client)
    assert "Acompanhe a KNAZH" in html and "Instagram da KNAZH" in html and "Facebook da KNAZH" in html
    assert f'href="{INSTAGRAM}"'.replace("&", "&amp;") in html and f'href="{FACEBOOK}"' in html
    assert html.count("mibextid") == 1  # sem parâmetro duplicado
    assert html.count('rel="noopener noreferrer"') >= 2 and 'target="_blank"' in html and "abre em nova aba" in html
    assert "#i-instagram" in html and "#i-facebook" in html


def test_footer_hides_social_section_when_not_configured_and_rejects_unsafe_urls(app, client):
    app.config.update(INSTAGRAM_URL="", FACEBOOK_URL="javascript:alert(1)")
    html = footer(client)
    assert "Acompanhe a KNAZH" not in html and "javascript:" not in html


def test_env_example_social_urls_are_https_and_match_official_ones():
    values = dict(line.split("=", 1) for line in (ROOT / ".env.example").read_text(encoding="utf-8").splitlines()
                  if "=" in line and not line.lstrip().startswith("#"))
    assert values["INSTAGRAM_URL"] == INSTAGRAM and values["FACEBOOK_URL"] == FACEBOOK
    assert values["FACEBOOK_URL"].count("mibextid") == 1


# ---------------------------------------------------------------- ano dinâmico
@pytest.mark.parametrize("utc, year", [
    (datetime(2026, 6, 1, 12, tzinfo=timezone.utc), 2026),
    (datetime(2027, 6, 1, 12, tzinfo=timezone.utc), 2027),
    (datetime(2028, 3, 1, 12, tzinfo=timezone.utc), 2028),
    (datetime(2027, 1, 1, 2, 0, tzinfo=timezone.utc), 2026),   # ainda 31/12 às 23h em Brasília
    (datetime(2027, 1, 1, 3, 0, tzinfo=timezone.utc), 2027),   # meia-noite em Brasília: virou o ano
])
def test_copyright_year_is_computed_on_the_server_in_sao_paulo_time(client, monkeypatch, utc, year):
    monkeypatch.setattr(clock, "_utc_now", lambda: utc)
    assert f"© {year} KNAZH. Todos os direitos reservados." in footer(client)
    assert f"© {year + 1} KNAZH" not in footer(client)


def test_copyright_year_is_not_hardcoded_anywhere():
    for path in list((ROOT / "knazh" / "templates").rglob("*.html")) + [ROOT / "knazh" / "__init__.py"]:
        text = path.read_text(encoding="utf-8")
        assert not re.search(r"©\s*20\d\d", text), path
    assert "current_year" in (ROOT / "knazh" / "templates" / "base.html").read_text(encoding="utf-8")


# ---------------------------------------------------------------- ícones
def test_catalog_all_uses_list_icon_and_others_uses_ellipsis(client):
    html = client.get("/cardapio").get_data(as_text=True)
    assert re.search(r'#i-list"/></svg><span>Todos</span>', html)
    assert re.search(r'#i-outros"/></svg><span>Outros</span>', html)
    symbol = re.search(r'<symbol id="i-outros"[^>]*>(.*?)</symbol>', html, re.S).group(1)
    assert symbol.count("h.01") == 3 and "circle" not in symbol  # três pontos
    assert 'id="i-list"' in html


# ---------------------------------------------------------------- categorias
def cat(slug):
    return db.session.scalar(db.select(Category).where(Category.slug == slug))


def post_cat(admin_client, path, **data):
    return admin_client.post(path, data={"csrf_token": token(admin_client), **data})


def test_categories_list_shows_counts_and_actions(admin_client):
    html = admin_client.get("/admin/categorias").get_data(as_text=True)
    assert "Brownies" in html and "Nova categoria" in html and "Editar" in html and "Desativada" not in html


def test_edit_existing_category_updates_catalog_without_changing_slug(client, admin_client):
    brownies = cat("brownies")
    r = post_cat(admin_client, f"/admin/categorias/{brownies.id}/editar", name="Brownies Premium",
                 description="Os mais chocolatudos", icon="star", sort_order="9", is_active="on")
    assert r.status_code == 302
    db.session.expire_all()
    c = cat("brownies")
    assert (c.name, c.description, c.icon, c.sort_order, c.is_active) == ("Brownies Premium", "Os mais chocolatudos", "star", 9, True)
    assert "Brownies Premium" in client.get("/cardapio").get_data(as_text=True)
    assert client.get("/cardapio/brownies").status_code == 200  # endereço antigo continua valendo


def test_deactivate_and_reactivate_category_reflects_on_public_site(client, admin_client):
    brownies = cat("brownies")
    post_cat(admin_client, f"/admin/categorias/{brownies.id}/editar", name="Brownies", icon="brownie", sort_order="1")  # sem is_active
    db.session.expire_all()
    assert cat("brownies").is_active is False
    assert 'href="/cardapio/brownies"' not in client.get("/cardapio").get_data(as_text=True)
    assert "Desativada" in admin_client.get("/admin/categorias").get_data(as_text=True)
    post_cat(admin_client, f"/admin/categorias/{brownies.id}/editar", name="Brownies", icon="brownie", sort_order="1", is_active="on")
    assert 'href="/cardapio/brownies"' in client.get("/cardapio").get_data(as_text=True)


@pytest.mark.parametrize("fields, message", [
    ({"name": "  "}, "Informe o nome"),
    ({"name": "bolos"}, "Já existe a categoria"),
    ({"name": "Doces", "icon": "<script>"}, "Escolha um ícone"),
    ({"name": "Doces", "sort_order": "abc"}, "número inteiro"),
    ({"name": "Doces", "sort_order": "-3"}, "entre 0 e 9999"),
    ({"name": "Doces", "description": "x" * 301}, "no máximo 300"),
])
def test_category_validation_is_enforced_on_the_server(admin_client, fields, message):
    brownies = cat("brownies")
    before = (brownies.name, brownies.icon)
    data = {"name": "Brownies", "icon": "brownie", "sort_order": "1", "is_active": "on", **fields}
    r = post_cat(admin_client, f"/admin/categorias/{brownies.id}/editar", **data)
    assert r.status_code == 400 and message in r.get_data(as_text=True)
    db.session.expire_all()
    assert (cat("brownies").name, cat("brownies").icon) == before


def test_create_category_then_delete_empty_one_but_never_one_in_use(client, admin_client):
    r = post_cat(admin_client, "/admin/categorias/novo", name="Salgados", description="Para a fome", icon="bag",
                 sort_order="20", is_active="on")
    assert r.status_code == 302 and cat("salgados").name == "Salgados"
    assert "Salgados" in client.get("/cardapio").get_data(as_text=True)

    products_before = db.session.query(Product).count()
    brownies = cat("brownies")
    assert "não pode ser excluída" in admin_client.get(f"/admin/categorias/{brownies.id}/excluir").get_data(as_text=True)
    post_cat(admin_client, f"/admin/categorias/{brownies.id}/excluir")
    assert cat("brownies") is not None and db.session.query(Product).count() == products_before  # nada apagado em cascata
    assert "tem" in admin_client.get("/admin/categorias").get_data(as_text=True)

    empty = cat("salgados")
    post_cat(admin_client, f"/admin/categorias/{empty.id}/excluir")
    assert cat("salgados") is None


def test_category_admin_requires_admin_and_csrf(app, client, admin_client, user_client):
    brownies = cat("brownies")
    assert client.get("/admin/categorias").status_code == 302
    assert user_client.get("/admin/categorias").status_code == 403
    assert user_client.post(f"/admin/categorias/{brownies.id}/excluir",
                            data={"csrf_token": token(user_client)}).status_code == 403
    assert admin_client.post(f"/admin/categorias/{brownies.id}/editar", data={"name": "X"}).status_code == 400
    assert admin_client.post(f"/admin/categorias/{brownies.id}/excluir").status_code == 400
    assert admin_client.get("/admin/categorias/99999/editar").status_code == 404


# ---------------------------------------------------------------- barra lateral e engrenagem
def test_admin_sidebar_and_gear_back_to_store(admin_client):
    html = admin_client.get("/admin/pedidos").get_data(as_text=True)
    assert "Ver a loja" not in html
    gear = re.search(r'<a class="admin-gear" href="([^"]+)" aria-label="Voltar para a loja"', html)
    assert gear and gear.group(1) == "/"  # link real: funciona sem JavaScript
    assert 'aria-controls="admin-sidebar"' in html and 'id="admin-sidebar"' in html and "Categorias" in html
    js = (ROOT / "knazh" / "static" / "js" / "admin.js").read_text(encoding="utf-8")
    assert "Escape" in js and "prefers-reduced-motion" in js and "admin-lock" in js
    css = (ROOT / "knazh" / "static" / "css" / "admin.css").read_text(encoding="utf-8")
    assert "prefers-reduced-motion: reduce" in css and "animation: none" in css


# ---------------------------------------------------------------- proxy reverso
def _ip_app(count):
    class Cfg(TestConfig):
        TRUSTED_PROXY_COUNT = count
    app = create_app(Cfg)

    @app.get("/_ip")
    def _ip():
        from flask import request
        return f"{request.remote_addr}|{request.scheme}"
    return app


def test_trusted_proxy_count_uses_forwarded_ip_only_when_enabled():
    headers = {"X-Forwarded-For": "203.0.113.7", "X-Forwarded-Proto": "https"}
    with _ip_app(1).test_client() as c:
        assert c.get("/_ip", headers=headers).get_data(as_text=True) == "203.0.113.7|https"
    with _ip_app(0).test_client() as c:  # sem proxy confiável: cabeçalhos forjados são ignorados
        assert c.get("/_ip", headers=headers).get_data(as_text=True).startswith("127.0.0.1|http")


# ---------------------------------------------------------------- backup do banco
def test_backup_db_command_creates_verified_copy_and_rotates(tmp_path):
    import sqlite3

    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{tmp_path / 'live.db'}"
    app = create_app(Cfg)
    with app.app_context():
        db.create_all()
        db.session.add(Category(slug="teste", name="Teste", icon="package"))
        db.session.commit()
    runner = app.test_cli_runner()
    out_dir = tmp_path / "bk"
    for _ in range(3):
        result = runner.invoke(args=["backup-db", "--dir", str(out_dir), "--keep", "2"])
        assert result.exit_code == 0 and "integrity_check ok" in result.output, result.output
        import time; time.sleep(1.05)  # nomes têm resolução de segundo
    files = sorted(out_dir.glob("knazh-*.db"))
    assert len(files) == 2  # rotação manteve só as 2 mais recentes
    con = sqlite3.connect(files[-1])
    assert con.execute("select name from categories where slug='teste'").fetchone() == ("Teste",)
    con.close()
    # restauração: o arquivo copiado abre como banco da aplicação e traz os mesmos dados
    restored = tmp_path / "restored.db"
    restored.write_bytes(files[-1].read_bytes())

    class Cfg2(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{restored}"
    with create_app(Cfg2).app_context():
        assert db.session.scalar(db.select(Category.name).where(Category.slug == "teste")) == "Teste"
