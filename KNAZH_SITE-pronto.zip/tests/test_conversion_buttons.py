"""Redesign dos botões de conversão (Ver cardápio / iFood / WhatsApp): só visual; destinos e regras iguais."""
import re
from pathlib import Path

from tests.test_admin import admin_client  # noqa: F401
from tests.test_cart_checkout import place_and_open

WA = "5541996206276"
IFOOD = ("https://www.ifood.com.br/delivery/almirante-tamandare-pr/knazh-jardim-graziela/"
         "db2ff914-8577-45d4-88cc-f57a05142ae9?utm_medium=share")
ROOT = Path(__file__).resolve().parent.parent


def ctas(html):
    """[(classes, href, texto)] de todos os botões .cta da página."""
    out = []
    for m in re.finditer(r'<a class="(cta [^"]*)" href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", m.group(3))).strip()
        out.append((m.group(1), m.group(2).replace("&amp;", "&"), text))
    return out


def configure(app, whatsapp=WA, ifood=IFOOD):
    app.config.update(WHATSAPP_NUMBER=whatsapp, IFOOD_STORE_URL=ifood)


def test_home_hero_has_three_distinct_buttons_with_original_destinations(app, client):
    configure(app)
    html = client.get("/").get_data(as_text=True)
    hero = html[html.index('class="hero__actions"'):html.index('class="hero__art"')]
    menu, ifood, wa = ctas(hero)
    assert menu[0].startswith("cta cta--menu") and menu[1] == "/cardapio" and menu[2].startswith("Ver cardápio")
    assert ifood[0].startswith("cta cta--ifood") and ifood[1] == IFOOD and ifood[2].startswith("Pedir no iFood")
    assert wa[0].startswith("cta cta--wa ") and wa[1] == f"https://wa.me/{WA}" and wa[2].startswith("Pedir pelo WhatsApp")
    for classes, *_ in (menu, ifood, wa):
        assert "cta--lg" in classes
    assert "#i-utensils" in hero and "#i-whatsapp" in hero and "#i-bag" in hero and hero.count("#i-arrow-right") == 3


def test_external_buttons_open_safely_and_say_so(app, client):
    configure(app)
    html = client.get("/").get_data(as_text=True)
    for m in re.finditer(r'<a class="cta cta--(?:ifood|wa)[^"]*" href="[^"]+"([^>]*)>(.*?)</a>', html, re.S):
        assert 'target="_blank"' in m.group(1) and 'rel="noopener noreferrer"' in m.group(1)
        assert "(abre em nova aba)" in m.group(2)
    menu = re.search(r'<a class="cta cta--menu[^"]*" href="[^"]+"([^>]*)>', html).group(1)
    assert "target" not in menu  # cardápio é navegação interna


def test_cart_keeps_checkout_destination_numbers_and_calculations(client, post, fill_cart, app):
    configure(app)
    fill_cart(("cookie", 1))
    html = client.get("/carrinho").get_data(as_text=True)
    summary = html[html.index('id="resumo-title"'):]
    items = {t.split(" ")[0]: (c, h, t) for c, h, t in ctas(summary)}
    assert items["Finalizar"][1] == "/finalizar" and "cta--menu" in items["Finalizar"][0] and "cta--block" in items["Finalizar"][0]
    wa = [x for x in ctas(summary) if "WhatsApp" in x[2]][0]
    assert "cta--wa-outline" in wa[0] and "(41) 99620-6276" in wa[2]  # outline com o número, como no mockup
    assert wa[1].startswith(f"https://wa.me/{WA}?text=") and "Cookie" in wa[1]  # mensagem do carrinho preservada
    ifood = [x for x in ctas(summary) if "iFood" in x[2]][0]
    assert ifood[1] == IFOOD and "Abrir loja no iFood" in ifood[2]
    assert "Subtotal (1 item)" in html and "R$ 12,00" in html and "A combinar com a equipe" in html and "Total estimado" in html


def test_cta_band_faq_product_and_confirmation_use_the_same_buttons(app, client, post, fill_cart):
    configure(app)
    for page in ("/cardapio", "/produto/cookie"):
        band = client.get(page).get_data(as_text=True)
        band = band[band.index('class="cta-band"'):]
        kinds = [c.split()[1] for c, *_ in ctas(band)]
        assert kinds == ["cta--ifood", "cta--wa"], page
    faq = client.get("/duvidas").get_data(as_text=True)
    assert any("cta--ifood" in c and "cta--block" in c for c, *_ in ctas(faq))
    assert any("cta--wa-outline" in c and "(41) 99620-6276" in t for c, _, t in ctas(faq))
    assert "Enviar mensagem" in faq  # botão de formulário continua
    loc, page = place_and_open(app, client, post, fill_cart, whatsapp=WA, ifood=IFOOD)
    kinds = {c.split()[1]: (h, t) for c, h, t in ctas(page)}
    assert kinds["cta--wa"][1].startswith("Abrir o WhatsApp") and kinds["cta--wa"][0].startswith(f"https://wa.me/{WA}?text=")
    assert kinds["cta--ifood"][0] == IFOOD


def test_unconfigured_channels_still_hide_buttons_and_keep_menu(app, client):
    configure(app, "", "")
    html = client.get("/").get_data(as_text=True)
    kinds = [c.split()[1] for c, *_ in ctas(html)]
    assert "cta--menu" in kinds and "cta--ifood" not in kinds and not any(k.startswith("cta--wa") for k in kinds)
    assert "wa.me" not in html and "ifood.com" not in html


def test_admin_and_other_pages_do_not_use_the_new_buttons(admin_client, client):
    for url in ("/admin/pedidos", "/admin/categorias", "/admin/"):
        assert 'class="cta ' not in admin_client.get(url).get_data(as_text=True), url
    for url in ("/privacidade", "/termos", "/sobre"):
        assert 'class="cta ' not in client.get(url).get_data(as_text=True), url


def test_cta_css_is_scoped_and_has_states_and_reduced_motion():
    css = (ROOT / "knazh" / "static" / "css" / "components.css").read_text(encoding="utf-8")
    block = css[css.index("/* Botões de conversão"):]
    for needle in (".cta--menu", ".cta--ifood", ".cta--wa ", ".cta--wa-outline", ".cta:hover", ".cta:active",
                   ".cta:focus-visible", "prefers-reduced-motion: reduce"):
        assert needle in block
    # nenhuma regra global: todo seletor do bloco começa com .cta (ou .cta-band .cta)
    selectors = re.findall(r"(?m)(?:^|\})\s*([^{}@/]+?)\s*\{", block)
    assert all(sel.lstrip().startswith(".cta") for sel in selectors), selectors
    assert "min-height: 52px" in block and "min-height: 60px" in block  # área de toque confortável


def test_instagram_link_was_corrected():
    env = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert "INSTAGRAM_URL=https://www.instagram.com/knazh.delivery?mdxt=aDJ6Z3dzbGd3dDU1" in env
    assert "invites/contact" not in env
