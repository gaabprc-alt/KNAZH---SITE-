import re
from urllib.parse import parse_qs, urlparse

import pytest

from knazh.extensions import db
from knazh.models import Order, OrderItem, Product
from knazh.services.channels import normalize_whatsapp, order_message, safe_https_url
from tests.conftest import VALID_ORDER, csrf_token, pid


def cart_html(client):
    return client.get("/carrinho").get_data(as_text=True)


def cart_names(client):
    html = cart_html(client)
    m = re.search(r'<ul class="cart-list">(.*?)</ul>', html, re.S)
    return re.findall(r'<h3><a href="/produto/[^"]+">([^<]+)</a></h3>', m.group(1)) if m else []


def test_empty_cart_state(client):
    html = cart_html(client)
    assert "Seu carrinho está vazio" in html and "Ver cardápio" in html


def test_add_update_remove_and_totals(client, post, fill_cart):
    fill_cart(("brownie-tradicional", 2), ("cookie", 1))
    html = cart_html(client)
    assert "R$ 28,00" in html and "R$ 12,00" in html and "R$ 40,00" in html and "3 itens" in html
    post("/carrinho/atualizar", {"product_id": pid("brownie-tradicional"), "quantity": 3})
    assert "R$ 54,00" in cart_html(client)
    post("/carrinho/remover", {"product_id": pid("cookie")})
    html = cart_html(client)
    assert cart_names(client) == ["Brownie Tradicional"] and "R$ 42,00" in html
    post("/carrinho/atualizar", {"product_id": pid("brownie-tradicional"), "quantity": 0})
    assert "Seu carrinho está vazio" in cart_html(client)


def test_adding_same_product_merges_quantity(client, fill_cart):
    fill_cart(("cookie", 1), ("cookie", 2))
    assert "3 itens" in cart_html(client)


def test_cart_badge_counts_items(client, fill_cart):
    fill_cart(("cookie", 2), ("brownie-com-oreo", 1))
    assert re.search(r'data-cart-count >3<', client.get("/").get_data(as_text=True))


@pytest.mark.parametrize("qty", ["0", "-1", "abc", "", "999", "1.5"])
def test_invalid_quantities_rejected(client, post, qty):
    r = post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": qty}, follow=True)
    assert "Seu carrinho está vazio" in cart_html(client)
    assert r.status_code == 200


def test_unknown_product_and_garbage_ids_rejected(client, post):
    for bad in ["99999", "abc", "-3", ""]:
        post("/carrinho/adicionar", {"product_id": bad, "quantity": 1})
    assert "Seu carrinho está vazio" in cart_html(client)


def test_max_quantity_per_product_enforced(client, post, fill_cart):
    fill_cart(("cookie", 20))
    post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": 1})
    assert "20 itens" in cart_html(client)


def test_json_response_for_fetch(client, post):
    r = post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": 2}, headers={"X-Requested-With": "fetch"})
    assert r.get_json() == {"ok": True, "message": "“Cookie” foi adicionado ao carrinho.", "count": 2}
    r = post("/carrinho/adicionar", {"product_id": "x", "quantity": 1}, headers={"X-Requested-With": "fetch"})
    assert r.status_code == 400 and r.get_json()["ok"] is False


def test_open_redirect_blocked_on_next(client, post):
    r = post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": 1, "next": "https://evil.example/x"})
    assert r.headers["Location"].endswith("/carrinho")
    r = post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": 1, "next": "//evil.example"})
    assert r.headers["Location"].endswith("/carrinho")
    r = post("/carrinho/adicionar", {"product_id": pid("cookie"), "quantity": 1, "next": "/cardapio?x=1"})
    assert r.headers["Location"].endswith("/cardapio?x=1")


def test_csrf_required_for_state_changes(client):
    r = client.post("/carrinho/adicionar", data={"product_id": 1, "quantity": 1})
    assert r.status_code == 400 and "Traceback" not in r.get_data(as_text=True)


def test_product_becoming_unavailable_blocks_checkout(client, fill_cart):
    fill_cart(("cookie", 1))
    db.session.execute(db.update(Product).where(Product.slug == "cookie").values(is_available=False))
    db.session.commit()
    html = cart_html(client)
    assert "ficou indisponível" in html and "/finalizar" not in html
    assert client.get("/finalizar").status_code == 302


def test_product_removed_from_catalog_is_dropped_from_cart(client, fill_cart):
    fill_cart(("cookie", 1), ("brownie-com-oreo", 1))
    p = db.session.scalar(db.select(Product).where(Product.slug == "cookie"))
    db.session.delete(p)
    db.session.commit()
    html = cart_html(client)  # aviso aparece uma vez; depois o carrinho já foi limpo
    assert "não está mais no cardápio" in html
    assert cart_names(client) == ["Brownie com Oreo"]


def test_checkout_redirects_when_cart_empty(client):
    r = client.get("/finalizar")
    assert r.status_code == 302 and r.headers["Location"].endswith("/carrinho")


def checkout_post(client, post, **overrides):
    page = client.get("/finalizar").get_data(as_text=True)
    token = re.search(r'name="submission_token"[^>]*value="([^"]+)"', page).group(1)
    data = {**VALID_ORDER, "submission_token": token, **overrides}
    return post("/finalizar", data, token_from="/finalizar")


def test_order_created_with_server_prices_and_persisted(client, post, fill_cart):
    fill_cart(("brownie-tradicional", 2), ("cookie", 1))
    r = checkout_post(client, post, price="1", total_cents="1", total="0,01", unit_price_cents="1")  # manipulação ignorada
    assert r.status_code == 302 and "/pedido/" in r.headers["Location"]
    order = db.session.scalar(db.select(Order))
    assert order.number == f"KNZ-{order.id:06d}" and order.status == "pendente"
    assert order.total_cents == 4000 and order.subtotal_cents == 4000
    assert {(i.product_name, i.quantity, i.unit_price_cents, i.line_total_cents) for i in order.items} == {
        ("Brownie Tradicional", 2, 1400, 2800), ("Cookie", 1, 1200, 1200)}
    assert order.customer_name == "Maria Silva" and order.notes == "Sem granulado"
    assert "Seu carrinho está vazio" in cart_html(client)  # carrinho limpo após o pedido


def test_order_snapshot_survives_price_change(client, post, fill_cart):
    fill_cart(("cookie", 2))
    checkout_post(client, post)
    db.session.execute(db.update(Product).where(Product.slug == "cookie").values(price_cents=9900, name="Outro"))
    db.session.commit()
    item = db.session.scalar(db.select(OrderItem))
    assert (item.product_name, item.unit_price_cents) == ("Cookie", 1200)


WA_NUMBER = "5541996206276"
IFOOD_URL = ("https://www.ifood.com.br/delivery/almirante-tamandare-pr/knazh-jardim-graziela/"
             "db2ff914-8577-45d4-88cc-f57a05142ae9?utm_medium=share")


def place_and_open(app, client, post, fill_cart, items=(("cookie", 1),), whatsapp="", ifood="", **overrides):
    """Registra um pedido pelo fluxo real (carrinho -> checkout) e abre a confirmação com os canais indicados."""
    app.config.update(WHATSAPP_NUMBER=whatsapp, IFOOD_STORE_URL=ifood)
    fill_cart(*items)
    loc = checkout_post(client, post, **overrides).headers["Location"]
    return loc, client.get(loc).get_data(as_text=True)


def wa_message(html):
    """Extrai o link wa.me da página e devolve (número, texto decodificado, href bruto)."""
    href = re.search(r'href="(https://wa\.me/[^"]+)"', html).group(1)
    parsed = urlparse(href)
    return parsed.path.strip("/"), parse_qs(parsed.query)["text"][0], href


def test_confirmation_without_channels_shows_friendly_fallback(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart)
    assert "Pedido registrado!" in html and "KNZ-000001" in html and "Aguardando confirmação" in html
    assert "Seu pedido foi registrado com sucesso" in html and "nossos canais de conclusão não estão disponíveis" in html
    assert "wa.me" not in html and "ifood.com.br" not in html
    for technical in ("WHATSAPP_NUMBER", "IFOOD_STORE_URL", "KeyError", "None", "Traceback"):
        assert technical not in html
    assert db.session.query(Order).count() == 1


def test_confirmation_with_both_channels(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, whatsapp="41 99620-6276", ifood=IFOOD_URL)
    assert "Concluir pelo WhatsApp" in html and "Enviar o resumo deste pedido para nossa equipe." in html
    assert "Continuar pelo iFood" in html and "Abrir a loja KNAZH no iFood." in html
    assert "será necessário selecionar os produtos novamente na plataforma" in html
    assert "A taxa de entrega, quando aplicável, será informada pelo atendimento." in html
    number, _, href = wa_message(html)
    assert number == WA_NUMBER and href.startswith(f"https://wa.me/{WA_NUMBER}?text=")
    assert f'href="{IFOOD_URL}"' in html
    assert "nossos canais de conclusão não estão disponíveis" not in html


def test_confirmation_only_whatsapp(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, whatsapp=WA_NUMBER)
    assert "Concluir pelo WhatsApp" in html and f"https://wa.me/{WA_NUMBER}?text=" in html
    assert "Continuar pelo iFood" not in html and "ifood.com.br" not in html
    assert "nossos canais de conclusão não estão disponíveis" not in html


def test_confirmation_only_ifood(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, ifood=IFOOD_URL)
    assert "Continuar pelo iFood" in html and f'href="{IFOOD_URL}"' in html
    assert "Concluir pelo WhatsApp" not in html and "wa.me" not in html
    assert "nossos canais de conclusão não estão disponíveis" not in html


def test_whatsapp_message_uses_real_order_data(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, items=(("brownie-tradicional", 2), ("cookie", 1)),
                               whatsapp=WA_NUMBER)
    _, msg, _ = wa_message(html)
    order = db.session.scalar(db.select(Order))
    assert msg.startswith("Olá, KNAZH! Acabei de registrar um pedido pelo site.")
    assert f"Pedido: {order.number}" in msg and order.number == "KNZ-000001"
    assert "• 2x Brownie Tradicional — R$ 28,00" in msg and "• 1x Cookie — R$ 12,00" in msg
    assert "Produtos: R$ 40,00" in msg and "Nome: Maria Silva" in msg
    assert "Observações:\nSem granulado" in msg
    assert "Gostaria de confirmar meu pedido." in msg
    for combinado in ("entrega ou retirada", "endereço, caso seja entrega", "melhor horário", "forma de pagamento",
                      "troco, se necessário"):
        assert combinado in msg
    assert "None" not in msg and "Total" not in msg


def test_whatsapp_message_skips_empty_notes(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, whatsapp=WA_NUMBER, notes="")
    _, msg, _ = wa_message(html)
    assert "Observações" not in msg and "None" not in msg and "Nome: Maria Silva" in msg
    assert "Observações" not in html  # nem no resumo da página


def test_whatsapp_message_encoding_handles_accents_emoji_and_symbols(app, client, post, fill_cart):
    notes = "Sem açúcar & 50% menos 🎉 #1 + “aspas”\nentregar às 18h?"
    loc, html = place_and_open(app, client, post, fill_cart, whatsapp=WA_NUMBER, name="João D'Ávila", notes=notes)
    _, msg, href = wa_message(html)
    assert "Nome: João D'Ávila" in msg
    assert "Sem açúcar & 50% menos 🎉 #1 + “aspas”\nentregar às 18h?" in msg
    query = href.split("?text=", 1)[1]
    assert re.fullmatch(r"[A-Za-z0-9%._~-]+", query)  # nada cru: espaço, &, #, +, ?, quebra de linha viram %XX
    assert "%0A" in query and "%F0%9F%8E%89" in query and "R%24%2028%2C00" not in query  # cookie = R$ 12,00
    assert "R%24%2012%2C00" in query


def test_whatsapp_message_uses_order_snapshot_not_current_catalog(app, client, post, fill_cart):
    app.config.update(WHATSAPP_NUMBER=WA_NUMBER)
    fill_cart(("cookie", 2))
    loc = checkout_post(client, post).headers["Location"]
    db.session.execute(db.update(Product).where(Product.slug == "cookie").values(price_cents=9900, name="Outro"))
    db.session.commit()
    _, msg, _ = wa_message(client.get(loc).get_data(as_text=True))
    assert "• 2x Cookie — R$ 24,00" in msg and "Produtos: R$ 24,00" in msg
    assert "Outro" not in msg and "99,00" not in msg


def test_order_message_stays_within_link_limit_and_keeps_footer():
    from types import SimpleNamespace
    items = [SimpleNamespace(quantity=3, product_name=f"Doce artesanal número {n} com recheio especial", line_total_cents=4500)
             for n in range(40)]
    order = SimpleNamespace(number="KNZ-000123", items=items, subtotal_cents=180000, customer_name="Maria Silva",
                            notes="x" * 500)
    msg = order_message(order)
    assert len(msg) <= 1500 and msg.endswith("demais informações necessárias para o pedido.")
    assert "Pedido: KNZ-000123" in msg and "Produtos: R$ 1.800,00" in msg and "e mais" in msg and "item(ns)" in msg


def test_choosing_a_channel_never_changes_order_or_creates_another(app, client, post, fill_cart):
    loc, html = place_and_open(app, client, post, fill_cart, whatsapp=WA_NUMBER, ifood=IFOOD_URL)
    before = db.session.scalar(db.select(Order))
    snapshot = (before.id, before.number, before.status, before.total_cents)
    assert before.status == "pendente" and before.status_label == "Aguardando confirmação"
    for _ in range(3):  # atualizar a página várias vezes (F5) não cria pedido nem muda status
        assert client.get(loc).status_code == 200
    db.session.expire_all()
    after = db.session.scalar(db.select(Order))
    assert db.session.query(Order).count() == 1
    assert (after.id, after.number, after.status, after.total_cents) == snapshot
    assert "Aguardando confirmação" in client.get(loc).get_data(as_text=True)


def test_channel_urls_come_from_server_config_not_query_string(app, client, post, fill_cart):
    loc, _ = place_and_open(app, client, post, fill_cart, whatsapp=WA_NUMBER, ifood=IFOOD_URL)
    html = client.get(f"{loc}?ifood=https://evil.example&whatsapp=5500000000000&text=hacked&next=https://evil.example")
    html = html.get_data(as_text=True)
    assert "evil.example" not in html and "5500000000000" not in html and "hacked" not in html
    assert f'href="{IFOOD_URL}"' in html and f"https://wa.me/{WA_NUMBER}?text=" in html


def test_env_example_has_real_channel_values():
    from pathlib import Path
    values = dict(line.split("=", 1) for line in
                  (Path(__file__).resolve().parent.parent / ".env.example").read_text(encoding="utf-8").splitlines()
                  if "=" in line and not line.lstrip().startswith("#"))
    assert normalize_whatsapp(values["WHATSAPP_NUMBER"]) == WA_NUMBER == values["WHATSAPP_NUMBER"]
    assert values["IFOOD_STORE_URL"] == IFOOD_URL and safe_https_url(values["IFOOD_STORE_URL"]) == IFOOD_URL


@pytest.mark.parametrize("field,value", [("name", ""), ("name", "A"), ("phone", "123"), ("phone", "abc"), ("email", "sem-arroba"), ("notes", "x" * 501)])
def test_checkout_validation_rejects_bad_data(client, post, fill_cart, field, value):
    fill_cart(("cookie", 1))
    r = checkout_post(client, post, **{field: value})
    assert r.status_code == 200 and "Confira os campos" in r.get_data(as_text=True)
    assert db.session.query(Order).count() == 0
    assert "1 item" in cart_html(client)


def test_double_submit_does_not_duplicate_order(client, post, fill_cart):
    fill_cart(("cookie", 1))
    page = client.get("/finalizar").get_data(as_text=True)
    token = re.search(r'name="submission_token"[^>]*value="([^"]+)"', page).group(1)
    data = {**VALID_ORDER, "submission_token": token}
    r1 = post("/finalizar", data, token_from="/finalizar")
    r2 = post("/finalizar", data, token_from="/contato")
    assert r1.headers["Location"] == r2.headers["Location"]
    assert db.session.query(Order).count() == 1


def test_checkout_blocked_without_csrf(client, fill_cart):
    fill_cart(("cookie", 1))
    assert client.post("/finalizar", data=VALID_ORDER).status_code == 400
    assert db.session.query(Order).count() == 0


def test_confirmation_not_visible_to_other_sessions(app, client, post, fill_cart):
    fill_cart(("cookie", 1))
    loc = checkout_post(client, post).headers["Location"]
    assert client.get(loc).status_code == 200
    assert app.test_client().get(loc).status_code == 404
    assert client.get("/pedido/inexistente").status_code == 404
