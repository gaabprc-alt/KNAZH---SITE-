"""Cancelamento de pedido: motivo obrigatório, confirmação, histórico, transições, aviso ao cliente e resiliência."""
import re
from urllib.parse import parse_qs, urlparse

from knazh.extensions import db
from knazh.models import Order, OrderNotification, OrderStatusEvent
from knazh.services import notifications as notifications_svc
from tests.test_admin import admin_client, user_client  # noqa: F401
from tests.test_orders_admin import admin_post, place_order

REASON = "Produto em falta no momento"


def cancel(admin_client, order, reason=REASON, confirm=True, **extra):
    data = {"status": "cancelado", "reason": reason, **extra}
    if confirm:
        data["confirmar"] = "1"
    return admin_post(admin_client, f"/admin/pedidos/{order.id}/status", data)


def fresh(order_id):
    db.session.expire_all()
    return db.session.get(Order, order_id)


def test_cancel_without_reason_is_rejected_on_the_server(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    for bad in ("", "   ", "\n\t  ", "ab"):
        r = cancel(admin_client, order, reason=bad)
        assert r.status_code == 302
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Informe o motivo do cancelamento" in page
    assert fresh(order.id).status == "pendente" and db.session.query(OrderStatusEvent).count() == 0
    assert db.session.query(OrderNotification).filter_by(recipient="cancel").count() == 0


def test_cancel_reason_too_long_is_rejected(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    cancel(admin_client, order, reason="x" * 301)
    assert "no máximo 300 caracteres" in admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert fresh(order.id).status == "pendente"
    cancel(admin_client, order, reason="x" * 300)
    assert fresh(order.id).status == "cancelado" and fresh(order.id).cancellation.reason == "x" * 300


def test_cancel_shows_reason_and_asks_explicit_confirmation_before_saving(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    r = cancel(admin_client, order, reason="  Falta de   ingrediente <b>hoje</b> ", confirm=False)
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and "Confirmar cancelamento" in html and "Falta de ingrediente" in html
    assert "<b>hoje</b>" not in html and "&lt;b&gt;hoje&lt;/b&gt;" in html  # escapado
    assert fresh(order.id).status == "pendente" and db.session.query(OrderStatusEvent).count() == 0  # nada gravado ainda


def test_confirmed_cancellation_records_history_with_admin_reason_and_states(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    assert cancel(admin_client, order).status_code == 302
    o = fresh(order.id)
    assert o.status == "cancelado" and o.status_label == "Cancelado"
    [event] = o.events
    assert (event.from_status, event.to_status, event.reason) == ("pendente", "cancelado", REASON)
    assert event.admin_id is not None and event.admin_name and event.created_at is not None
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Histórico de estados" in page and "Aguardando confirmação → Cancelado" in page and REASON in page
    assert "Atualizar estado" not in page  # pedido encerrado: sem formulário de mudança


def test_reason_is_not_required_for_other_states_and_is_not_stored(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {"status": "confirmado", "reason": "ignorado"})
    admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {"status": "concluido"})
    o = fresh(order.id)
    assert o.status == "concluido"
    assert [(e.from_status, e.to_status, e.reason) for e in o.events] == [("pendente", "confirmado", None),
                                                                           ("confirmado", "concluido", None)]
    assert db.session.query(OrderNotification).filter_by(recipient="cancel").count() == 0


def test_invalid_transitions_are_blocked_and_leave_no_history(client, post, fill_cart, admin_client):
    done = place_order(client, post, fill_cart)
    admin_post(admin_client, f"/admin/pedidos/{done.id}/status", {"status": "concluido"})
    cancel(admin_client, done)  # concluído não pode ser cancelado
    admin_post(admin_client, f"/admin/pedidos/{done.id}/status", {"status": "pendente"})
    assert fresh(done.id).status == "concluido" and len(fresh(done.id).events) == 1

    gone = place_order(client, post, fill_cart, items=(("cookie", 1),))
    cancel(admin_client, gone)
    for target in ("pendente", "confirmado", "concluido"):  # cancelado é final
        admin_post(admin_client, f"/admin/pedidos/{gone.id}/status", {"status": target})
    assert fresh(gone.id).status == "cancelado" and len(fresh(gone.id).events) == 1


def test_double_click_does_not_duplicate_cancellation_history_or_notice(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, whatsapp_optin="y")
    before = len(whatsapp_api.calls)
    cancel(admin_client, order)
    cancel(admin_client, order)
    cancel(admin_client, order, reason="Outro motivo")
    o = fresh(order.id)
    assert len(o.events) == 1 and o.cancellation.reason == REASON
    assert db.session.query(OrderNotification).filter_by(recipient="cancel").count() == 1
    assert len(whatsapp_api.calls) == before + 1  # um único aviso ao cliente


def test_cancellation_notice_sent_to_consenting_customer_with_order_number_and_reason(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, whatsapp_optin="y")
    before = len(whatsapp_api.calls)
    cancel(admin_client, order)
    assert len(whatsapp_api.calls) == before + 1
    call = whatsapp_api.calls[-1]
    assert call["body"]["to"] == "5541999991234" and call["body"]["template"]["name"] == "knazh_pedido_cancelado"
    params = [p["text"] for p in call["body"]["template"]["components"][0]["parameters"]]
    assert params[0] == "Maria Silva" and params[1] == order.number and params[2] == REASON
    assert re.fullmatch(r"\d{2}/\d{2}/\d{4} \d{2}:\d{2}", params[3])
    note = fresh(order.id).notification_for("cancel")
    assert note.status == "enviado" and note.attempts == 1
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Cliente (aviso de cancelamento)" in page and "token-falso-de-teste" not in page


def test_notification_failure_never_reverts_cancellation_and_retry_does_not_cancel_again(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, whatsapp_optin="y")
    whatsapp_api.mode = "http401"
    cancel(admin_client, order)
    o = fresh(order.id)
    assert o.status == "cancelado" and o.notification_for("cancel").status == "falhou"
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Tentar enviar de novo" in page and "token-falso-de-teste" not in page

    whatsapp_api.mode = "ok"
    r = admin_post(admin_client, f"/admin/pedidos/{order.id}/notificacoes/cancel/reenviar")
    assert r.status_code == 302
    o = fresh(order.id)
    assert o.notification_for("cancel").status == "enviado" and o.notification_for("cancel").attempts == 2
    assert o.status == "cancelado" and len(o.events) == 1  # não cancelou de novo
    calls = len(whatsapp_api.calls)
    admin_post(admin_client, f"/admin/pedidos/{order.id}/notificacoes/cancel/reenviar")  # já enviado: não repete
    assert len(whatsapp_api.calls) == calls


def test_send_pending_command_path_retries_cancellation_notice(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, whatsapp_optin="y")
    whatsapp_api.mode = "timeout"
    cancel(admin_client, order)
    assert fresh(order.id).notification_for("cancel").status == "falhou"
    whatsapp_api.mode = "ok"
    result = notifications_svc.send_pending()
    assert result["enviadas"] >= 1 and fresh(order.id).notification_for("cancel").status == "enviado"


def test_without_consent_or_integration_nothing_is_sent_and_manual_whatsapp_link_is_offered(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)  # cliente não marcou a autorização
    r = cancel(admin_client, order)
    assert r.status_code == 302
    note = fresh(order.id).notification_for("cancel")
    assert note.status == "dispensado" and note.attempts == 0
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Avisar o cliente pelo WhatsApp" in page and "não é um envio automático" in page
    href = re.search(r'href="(https://wa\.me/5541999991234\?text=[^"]+)"', page).group(1)
    text = parse_qs(urlparse(href).query)["text"][0]
    assert order.number in text and REASON in text and "foi cancelado" in text
    assert "99999-1234" not in text and "@" not in text  # sem telefone/e-mail no texto


def test_opted_in_but_integration_not_configured_is_recorded_not_sent(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, whatsapp_optin="y")  # sem credenciais da API (padrão dos testes)
    cancel(admin_client, order)
    note = fresh(order.id).notification_for("cancel")
    assert note.status == "nao_configurado" and fresh(order.id).status == "cancelado"


def test_customer_sees_cancellation_and_reason_but_no_channels(app, client, post, fill_cart, admin_client):
    app.config.update(WHATSAPP_NUMBER="5541996206276")
    order = place_order(client, post, fill_cart)
    cancel(admin_client, order)
    html = client.get(f"/pedido/{order.public_id}").get_data(as_text=True)
    assert "Este pedido foi cancelado" in html and REASON in html and "wa.me" not in html


def test_cancel_endpoint_requires_admin_and_csrf(client, post, fill_cart, admin_client, user_client):
    order = place_order(client, post, fill_cart)
    assert admin_client.post(f"/admin/pedidos/{order.id}/status", data={"status": "cancelado", "reason": REASON,
                                                                      "confirmar": "1"}).status_code == 400
    assert user_client.post(f"/admin/pedidos/{order.id}/status",
                            data={"status": "cancelado", "reason": REASON, "confirmar": "1"}).status_code in (400, 403)
    assert fresh(order.id).status == "pendente" and db.session.query(OrderStatusEvent).count() == 0


def test_migration_creates_history_table_once(app):
    from sqlalchemy import inspect, text
    from knazh import migrations
    engine = db.engine
    with engine.begin() as conn:
        conn.execute(text("DROP TABLE order_status_events"))
    assert migrations.create_order_status_events(engine) == "criada"
    assert "order_status_events" in inspect(engine).get_table_names()
    assert migrations.create_order_status_events(engine) == "ja-existe"
