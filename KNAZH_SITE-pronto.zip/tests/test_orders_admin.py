"""Painel administrativo de pedidos: dados operacionais, estado dos avisos, retentativa controlada e permissões."""
import re

from knazh.extensions import db
from knazh.models import Order, OrderNotification
from tests.test_admin import admin_client, user_client  # noqa: F401
from tests.test_admin import token
from tests.test_cart_checkout import checkout_post


def place_order(client, post, fill_cart, items=(("brownie-tradicional", 2), ("cookie", 1)), **over):
    fill_cart(*items)
    r = checkout_post(client, post, **over)
    assert r.status_code == 302, r.get_data(as_text=True)[:300]
    return db.session.scalars(db.select(Order).order_by(Order.id.desc())).first()


def admin_post(client, path, data=None):
    return client.post(path, data={**(data or {}), "csrf_token": token(client)})


# ---------------------------------------------------------------- lista e detalhe
def test_orders_list_shows_operational_data_and_pending_integration(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    html = admin_client.get("/admin/pedidos").get_data(as_text=True)
    assert order.number in html and "Maria Silva" in html and "R$ 40,00" in html and "Aguardando confirmação" in html
    assert "Equipe: Integração não configurada" in html and "Cliente: Não enviado (cliente não autorizou)" in html
    assert "Envio automático por WhatsApp pendente de configuração" in html and "WHATSAPP_ACCESS_TOKEN" in html
    assert "noindex" in html and f"/admin/pedidos/{order.id}" in html
    assert "99999-1234" not in html  # a lista não expõe telefone: só o detalhe, para quem precisa atender


def test_orders_list_empty_state(admin_client):
    html = admin_client.get("/admin/pedidos").get_data(as_text=True)
    assert "Ainda não há pedidos" in html


def test_order_detail_has_items_totals_customer_and_notifications(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    html = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert f"Pedido {order.number}" in html
    assert "Brownie Tradicional" in html and "Cookie" in html and "R$ 28,00" in html and "R$ 12,00" in html and "R$ 40,00" in html
    assert "A combinar com a equipe" in html and "Sem granulado" in html
    assert "Maria Silva" in html and "(41) 99999-1234" in html and "Visitante" in html
    assert "https://wa.me/5541999991234" in html and "não é um envio automático" in html  # atalho MANUAL da equipe
    assert "Equipe (detalhes do pedido)" in html and "Cliente (confirmação de recebimento)" in html
    assert "Tentar enviar de novo" in html and "0 de 5" in html
    assert "Não enviado (cliente não autorizou)" in html and "Cliente não autorizou" in html


def test_unknown_order_is_404_for_admin(admin_client):
    assert admin_client.get("/admin/pedidos/99999").status_code == 404
    assert admin_post(admin_client, "/admin/pedidos/99999/status", {"status": "confirmado"}).status_code == 404


def test_admin_pages_escape_customer_input(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart, name="<script>alert(1)</script>", notes="<img src=x onerror=alert(2)>")
    for path in ("/admin/pedidos", f"/admin/pedidos/{order.id}"):
        html = admin_client.get(path).get_data(as_text=True)
        assert "<script>alert(1)</script>" not in html and "<img src=x" not in html, path
        assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html


def test_orders_search_and_status_filter(client, post, fill_cart, admin_client):
    first = place_order(client, post, fill_cart, name="Ana Cliente")
    second = place_order(client, post, fill_cart, items=(("cookie", 1),), name="Bruno Cliente")
    admin_post(admin_client, f"/admin/pedidos/{second.id}/status",
               {"status": "cancelado", "reason": "Sem estoque hoje", "confirmar": "1"})
    admin_client.get(f"/admin/pedidos/{second.id}")  # consome o aviso (flash) do cancelamento, que cita o número do pedido
    by_name = admin_client.get("/admin/pedidos?q=ana").get_data(as_text=True)
    assert first.number in by_name and second.number not in by_name
    by_number = admin_client.get(f"/admin/pedidos?q={second.number.lower()}").get_data(as_text=True)
    assert second.number in by_number and first.number not in by_number
    cancelled = admin_client.get("/admin/pedidos?status=cancelado").get_data(as_text=True)
    assert second.number in cancelled and first.number not in cancelled
    assert admin_client.get("/admin/pedidos?status=qualquer-coisa&pagina=abc&q=" + "x" * 500).status_code == 200


# ---------------------------------------------------------------- estado do pedido
def test_status_update_is_validated_and_sends_nothing(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    calls = len(whatsapp_api.calls)
    r = admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {"status": "confirmado"})
    assert r.status_code == 302
    db.session.expire_all()
    assert db.session.get(Order, order.id).status == "confirmado"
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Confirmado" in page
    admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {"status": "hackeado"})
    admin_post(admin_client, f"/admin/pedidos/{order.id}/status", {})
    db.session.expire_all()
    assert db.session.get(Order, order.id).status == "confirmado"  # estado inválido é recusado
    assert len(whatsapp_api.calls) == calls  # mudar o estado NÃO manda mensagem ao cliente


def test_status_update_requires_csrf(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    r = admin_client.post(f"/admin/pedidos/{order.id}/status", data={"status": "concluido"})
    assert r.status_code == 400
    db.session.expire_all()
    assert db.session.get(Order, order.id).status == "pendente"


# ---------------------------------------------------------------- retentativa controlada
def test_retry_button_resends_only_failed_notification_without_new_order(whatsapp_api, client, post, fill_cart, admin_client):
    whatsapp_api.mode = "http401"
    order = place_order(client, post, fill_cart, whatsapp_optin="y")
    page = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Falhou" in page and "Tentar enviar de novo" in page and "HTTP 401" in page
    assert "token-falso-de-teste" not in page

    whatsapp_api.mode = "ok"
    calls_before = len(whatsapp_api.calls)
    r = admin_post(admin_client, f"/admin/pedidos/{order.id}/notificacoes/equipe/reenviar")
    assert r.status_code == 302
    db.session.expire_all()
    notes = {n.recipient: n for n in db.session.get(Order, order.id).notifications}
    assert notes["equipe"].status == "enviado" and notes["equipe"].attempts == 2 and notes["cliente"].status == "falhou"
    assert len(whatsapp_api.calls) == calls_before + 1  # só a equipe foi reenviada
    assert db.session.query(Order).count() == 1 and db.session.query(OrderNotification).count() == 2

    again = admin_post(admin_client, f"/admin/pedidos/{order.id}/notificacoes/equipe/reenviar")  # já enviado: não repete
    assert again.status_code == 302 and len(whatsapp_api.calls) == calls_before + 1
    follow = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert "Não é reenviado" in follow


def test_retry_when_integration_is_still_not_configured_is_honest(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    r = admin_client.post(f"/admin/pedidos/{order.id}/notificacoes/equipe/reenviar", data={"csrf_token": token(admin_client)},
                          follow_redirects=True)
    html = r.get_data(as_text=True)
    assert "ainda não está configurada" in html and "nada foi enviado" in html
    db.session.expire_all()
    notes = {n.recipient: n for n in db.session.get(Order, order.id).notifications}
    assert notes["equipe"].status == "nao_configurado" and notes["equipe"].attempts == 0


def test_retry_for_client_without_consent_is_refused(whatsapp_api, client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    calls = len(whatsapp_api.calls)
    r = admin_client.post(f"/admin/pedidos/{order.id}/notificacoes/cliente/reenviar", data={"csrf_token": token(admin_client)},
                          follow_redirects=True)
    assert "não autorizou" in r.get_data(as_text=True) and len(whatsapp_api.calls) == calls


def test_retry_rejects_unknown_recipient_and_missing_csrf(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    assert admin_post(admin_client, f"/admin/pedidos/{order.id}/notificacoes/outro/reenviar").status_code == 404
    assert admin_client.post(f"/admin/pedidos/{order.id}/notificacoes/equipe/reenviar").status_code == 400


# ---------------------------------------------------------------- permissões
def test_regular_customers_and_visitors_cannot_see_or_change_orders(client, post, fill_cart, user_client):
    order = place_order(client, post, fill_cart)
    anonymous = client  # visitante que fez o pedido: nem ele acessa o painel
    for who, expected in ((anonymous, 302), (user_client, 403)):
        for path in ("/admin/pedidos", f"/admin/pedidos/{order.id}"):
            assert who.get(path).status_code == expected, (path, expected)
        for path in (f"/admin/pedidos/{order.id}/status", f"/admin/pedidos/{order.id}/notificacoes/equipe/reenviar"):
            assert who.post(path, data={"csrf_token": token(who), "status": "confirmado"}).status_code == expected, path
    db.session.expire_all()
    assert db.session.get(Order, order.id).status == "pendente"
    html = user_client.get("/admin/pedidos").get_data(as_text=True)
    assert order.number not in html and "Maria Silva" not in html


def test_orders_nav_item_is_marked_current_on_orders_pages(client, post, fill_cart, admin_client):
    order = place_order(client, post, fill_cart)
    html = admin_client.get(f"/admin/pedidos/{order.id}").get_data(as_text=True)
    assert re.search(r'href="/admin/pedidos"\s+aria-current="page"', html)
