import io
import json
import re
import urllib.error

import pytest

from knazh import create_app
from knazh.config import TestConfig
from knazh.demo_data import seed_demo
from knazh.extensions import db
from knazh.models import Category, Product
from knazh.services import whatsapp


@pytest.fixture()
def app(tmp_path):
    class Cfg(TestConfig):
        UPLOAD_DIR = tmp_path / "uploads" / "products"  # cada teste grava num diretório temporário próprio

    app = create_app(Cfg)
    with app.app_context():
        db.create_all()
        seed_demo()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf_token(client, path="/contato"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)


@pytest.fixture()
def post(client):
    def _post(path, data=None, token_from="/contato", follow=False, **kw):
        data = dict(data or {})
        data.setdefault("csrf_token", csrf_token(client, token_from))
        return client.post(path, data=data, follow_redirects=follow, **kw)
    return _post


def pid(slug):
    return db.session.scalar(db.select(Product.id).where(Product.slug == slug))


@pytest.fixture()
def product_id(app):
    return pid


VALID_ORDER = {"name": "Maria Silva", "phone": "(41) 99999-1234", "email": "", "notes": "Sem granulado"}


@pytest.fixture()
def fill_cart(client, post):
    def _fill(*items):
        for slug, qty in items:
            post("/carrinho/adicionar", {"product_id": pid(slug), "quantity": qty})
    return _fill


# ---------------------------------------------------------------- WhatsApp: nunca fala com a rede de verdade
class NetworkBlocked(BaseException):
    """BaseException de propósito: nenhum `except Exception` do app consegue engolir este erro e esconder o problema."""


@pytest.fixture(autouse=True)
def _no_real_whatsapp(monkeypatch):
    def _blocked(*_a, **_k):
        raise NetworkBlocked("Um teste tentou chamar a API real do WhatsApp. Use a fixture `whatsapp_api`.")

    monkeypatch.setattr(whatsapp, "_urlopen", _blocked)


class _Response:
    status = 200

    def __init__(self, data):
        self._raw = json.dumps(data).encode()

    def read(self, _n=-1):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        return False


class FakeWhatsAppAPI:
    """Substitui a chamada HTTP da API oficial: registra o que SERIA enviado e devolve a resposta combinada em `mode`
    (ok | noid | http401 | timeout)."""

    def __init__(self):
        self.calls, self.mode, self._n = [], "ok", 0

    def __call__(self, request, timeout=None):
        body = json.loads(request.data.decode("utf-8"))
        self.calls.append({"url": request.full_url, "auth": request.get_header("Authorization"), "body": body, "timeout": timeout})
        if self.mode == "timeout":
            raise TimeoutError()
        if self.mode == "http401":
            payload = json.dumps({"error": {"code": 190, "message": "Invalid OAuth access token."}}).encode()
            raise urllib.error.HTTPError(request.full_url, 401, "Unauthorized", {}, io.BytesIO(payload))
        if self.mode == "noid":
            return _Response({"messaging_product": "whatsapp"})
        self._n += 1
        return _Response({"messaging_product": "whatsapp", "contacts": [{"input": body["to"], "wa_id": body["to"]}],
                          "messages": [{"id": f"wamid.TEST{self._n}"}]})

    def to_numbers(self):
        return [c["body"]["to"] for c in self.calls]


@pytest.fixture()
def whatsapp_api(app, monkeypatch):
    """Liga a integração com credenciais FALSAS de teste e uma API falsa. O token abaixo não é real."""
    api = FakeWhatsAppAPI()
    monkeypatch.setattr(whatsapp, "_urlopen", api)
    app.config.update(WHATSAPP_API_ENABLED=True, WHATSAPP_PHONE_NUMBER_ID="123456789012345",
                      WHATSAPP_ACCESS_TOKEN="token-falso-de-teste", WHATSAPP_TEAM_NUMBER="5541900000000")
    return api


@pytest.fixture()
def smtp(app, monkeypatch):
    """SMTP falso: NENHUM e-mail real é enviado nos testes. Registra mensagens, eventos e o contexto TLS usado."""
    import smtplib
    import ssl
    from types import SimpleNamespace

    import knazh.services.mailer as mailer

    state = SimpleNamespace(sent=[], events=[], tls_context=None, login=None, fail_send=None, fail_login=False)

    class FakeSMTP:
        def __init__(self, host, port, timeout=None, context=None):
            state.events.append(("connect", host, port))
            self.ssl = context is not None
            if context is not None:
                state.tls_context = context

        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def ehlo(self):
            state.events.append("ehlo")

        def starttls(self, context=None):
            state.events.append("starttls")
            state.tls_context = context

        def login(self, user, password):
            state.events.append("login")
            state.login = (user, password)
            if state.fail_login:
                raise smtplib.SMTPAuthenticationError(535, b"5.7.8 Username and Password not accepted")

        def send_message(self, msg):
            state.events.append("send")
            if state.fail_send:
                raise state.fail_send
            state.sent.append(msg)

    monkeypatch.setattr(mailer.smtplib, "SMTP", FakeSMTP)
    monkeypatch.setattr(mailer.smtplib, "SMTP_SSL", FakeSMTP)
    app.config.update(SMTP_HOST="smtp.gmail.com", SMTP_PORT=587, SMTP_USE_TLS=True, SMTP_USERNAME="loja@gmail.com",
                      SMTP_PASSWORD="senha-de-app-falsa", SMTP_FROM="loja@gmail.com", CONTACT_EMAIL_TO="",
                      EMAIL_VERIFICATION_REQUIRED=True, EMAIL_VERIFICATION_MAX_AGE=86400, SITE_URL="")
    state.ssl = ssl
    return state
