import re
from datetime import timedelta

from knazh.extensions import db
from knazh.models import Customer, Favorite, Order, utcnow
from tests.conftest import VALID_ORDER, pid

REG = {"name": "Ana Souza", "email": "ana@example.com", "phone": "(41) 98888-7777", "password": "senha1234", "confirm": "senha1234"}


def register(post, **over):
    return post("/conta/cadastrar", {**REG, **over}, token_from="/conta/cadastrar")


def login(post, email="ana@example.com", password="senha1234", **extra):
    return post("/conta/entrar", {"email": email, "password": password, **extra}, token_from="/conta/entrar")


def place_order(client, post, slug="cookie"):
    post("/carrinho/adicionar", {"product_id": pid(slug), "quantity": 1})
    page = client.get("/finalizar").get_data(as_text=True)
    token = re.search(r'name="submission_token"[^>]*value="([^"]+)"', page).group(1)
    return post("/finalizar", {**VALID_ORDER, "submission_token": token}, token_from="/finalizar").headers["Location"]


def test_register_hashes_password_and_logs_in(client, post):
    r = register(post)
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta")
    c = db.session.scalar(db.select(Customer))
    assert c.email == "ana@example.com" and c.password_hash != "senha1234" and "senha1234" not in c.password_hash
    assert c.check_password("senha1234") and not c.check_password("outra")
    assert "Olá, Ana!" in client.get("/conta").get_data(as_text=True)


def test_register_validation(client, post):
    for over in [{"password": "curta1", "confirm": "curta1"}, {"password": "somenteletras", "confirm": "somenteletras"},
                 {"confirm": "diferente123"}, {"email": "ruim"}, {"phone": "1"}, {"name": ""}]:
        r = register(post, **over)
        assert r.status_code == 200
    assert db.session.query(Customer).count() == 0


def test_duplicate_email_rejected_case_insensitive(app, client, post):
    register(post)
    other = app.test_client()
    tok = re.search(r'csrf-token" content="([^"]+)"', other.get("/conta/cadastrar").get_data(as_text=True)).group(1)
    r = other.post("/conta/cadastrar", data={**REG, "email": "ANA@Example.com", "csrf_token": tok})
    assert r.status_code == 200 and db.session.query(Customer).count() == 1


def test_login_wrong_password_and_throttle(client, post):
    register(post)
    client.post("/conta/sair", data={"csrf_token": re.search(r'csrf-token" content="([^"]+)"', client.get("/contato").get_data(as_text=True)).group(1)})
    for _ in range(5):
        assert "incorretos" in login(post, password="errada123").get_data(as_text=True)
    assert "Muitas tentativas" in login(post).get_data(as_text=True)


def test_login_ok_and_safe_next(client, post):
    register(post)
    post("/conta/sair")
    r = login(post, next="/cardapio")
    assert r.headers["Location"].endswith("/cardapio")
    post("/conta/sair")
    r = login(post, next="https://evil.example")
    assert r.headers["Location"].endswith("/conta")


def test_private_pages_require_login(client):
    for url in ["/conta", "/conta/pedidos", "/conta/favoritos", "/conta/perfil"]:
        r = client.get(url)
        assert r.status_code == 302 and "/conta/entrar" in r.headers["Location"]


def test_customer_cannot_see_another_customers_orders(app, post, client):
    register(post)
    loc = place_order(client, post)
    public_id = loc.rsplit("/", 1)[1]
    assert public_id in client.get("/conta/pedidos").get_data(as_text=True) or "KNZ-" in client.get("/conta/pedidos").get_data(as_text=True)
    assert client.get(f"/conta/pedidos/{public_id}").status_code == 200

    other = app.test_client()
    tok = re.search(r'csrf-token" content="([^"]+)"', other.get("/conta/cadastrar").get_data(as_text=True)).group(1)
    other.post("/conta/cadastrar", data={**REG, "email": "bia@example.com", "name": "Bia", "csrf_token": tok})
    assert other.get(f"/conta/pedidos/{public_id}").status_code == 404
    assert other.get(loc).status_code == 404
    assert "KNZ-" not in other.get("/conta/pedidos").get_data(as_text=True)


def test_logged_order_is_linked_to_customer(client, post):
    register(post)
    place_order(client, post)
    assert db.session.scalar(db.select(Order.customer_id)) == db.session.scalar(db.select(Customer.id))


def test_guest_checkout_has_no_customer(client, post):
    place_order(client, post)
    assert db.session.scalar(db.select(Order.customer_id)) is None


def test_favorites_toggle(client, post):
    register(post)
    post("/conta/favoritos/alternar", {"product_id": pid("cookie")})
    assert db.session.query(Favorite).count() == 1
    assert "Cookie" in client.get("/conta/favoritos").get_data(as_text=True)
    post("/conta/favoritos/alternar", {"product_id": pid("cookie")})
    assert db.session.query(Favorite).count() == 0
    assert post("/conta/favoritos/alternar", {"product_id": "abc"}).status_code == 400
    assert post("/conta/favoritos/alternar", {"product_id": "99999"}).status_code == 404


def test_profile_update(client, post):
    register(post)
    post("/conta/perfil", {"name": "Ana Maria", "phone": "(41) 97777-6666"}, token_from="/conta/perfil")
    assert db.session.scalar(db.select(Customer.name)) == "Ana Maria"


def body_of(msg, kind):
    return msg.get_body(preferencelist=(kind,)).get_content()


def link_of(msg):
    return re.search(r"https?://[^/\s]+(/conta/confirmar-email/[A-Za-z0-9_-]+)", body_of(msg, "plain")).group(1)


def customer_by(email="ana@example.com"):
    db.session.expire_all()
    return db.session.scalar(db.select(Customer).where(Customer.email == email))


def test_signup_creates_unverified_account_sends_real_message_and_does_not_log_in(app, client, post, smtp):
    r = register(post)
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta/verificar-email")
    c = customer_by()
    assert c.email_verified is False and c.email_verified_at is None  # B
    assert c.email_verification_token_hash and c.email_verification_expires_at > utcnow()
    assert client.get("/conta").status_code == 302  # C: sem login automático; área protegida segue fechada
    with client.session_transaction() as sess:
        assert "customer_id" not in sess
    [msg] = smtp.sent  # D: destinatário é o e-mail digitado, não CONTACT_EMAIL_TO (vazio aqui: item Z)
    assert msg["To"] == "ana@example.com" and msg["Subject"] == "Confirme seu e-mail — KNAZH"
    assert "loja@gmail.com" in msg["From"] and msg["Date"] and msg["Message-ID"]
    plain, html = body_of(msg, "plain"), body_of(msg, "html")  # E, F
    assert "Confirme seu e-mail" in plain and "Confirmar meu e-mail" in html and "KNAZH" in html
    assert "24 horas" in plain and "ignore esta mensagem" in plain
    url = re.search(r"https?://\S+/conta/confirmar-email/\S+", plain).group(0)  # G
    assert f'href="{url}"' in html and "<script" not in html
    token = url.rsplit("/", 1)[-1]
    assert len(token) >= 40 and c.email_verification_token_hash != token  # só o hash fica no banco
    assert token not in repr([c.password_hash, c.email_verification_token_hash])


def test_gmail_style_smtp_uses_verified_starttls_then_login(app, client, post, smtp):
    register(post)
    ev = smtp.events
    assert ev[0] == ("connect", "smtp.gmail.com", 587)
    assert ev.index("starttls") < ev.index("login") < ev.index("send") and ev.count("ehlo") == 2
    ctx = smtp.tls_context
    assert ctx is not None and ctx.verify_mode == smtp.ssl.CERT_REQUIRED and ctx.check_hostname is True
    assert smtp.login == ("loja@gmail.com", "senha-de-app-falsa")


def test_site_url_builds_clean_https_link_without_double_slash(app, client, post, smtp):
    app.config.update(SITE_URL="https://knazh.com.br")
    register(post)
    assert re.search(r"https://knazh\.com\.br/conta/confirmar-email/[A-Za-z0-9_-]{43}\n", body_of(smtp.sent[0], "plain"))
    assert "br//conta" not in body_of(smtp.sent[0], "plain")


def test_valid_token_confirms_clears_the_token_and_allows_login(app, client, post, smtp):
    register(post)
    path = link_of(smtp.sent[0])
    r = client.get(path)
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta/entrar")
    c = customer_by()
    assert c.email_verified is True and c.email_verified_at is not None  # H, I, J
    assert c.email_verification_token_hash is None and c.email_verification_expires_at is None  # K, L
    assert "E-mail confirmado! Agora você já pode entrar na sua conta." in client.get("/conta/entrar").get_data(as_text=True)
    r = login(post)  # N
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta")
    assert client.get("/conta").status_code == 200


def test_consumed_token_cannot_be_used_again(app, client, post, smtp):
    register(post)
    path = link_of(smtp.sent[0])
    client.get(path)
    before = customer_by()
    verified_at = before.email_verified_at
    again = client.get(path, follow_redirects=True).get_data(as_text=True)  # R
    assert "já foi usado, é inválido ou expirou" in again
    after = customer_by()
    assert after.email_verified_at == verified_at and after.email_verification_token_hash is None


def test_login_before_confirmation_is_refused_without_session(app, client, post, smtp):
    register(post)
    r = login(post)  # M: senha certa, e-mail não confirmado
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta/verificar-email")
    assert "Confirme seu e-mail antes de entrar" in client.get(r.headers["Location"]).get_data(as_text=True)
    assert client.get("/conta").status_code == 302 and client.get("/conta/pedidos").status_code == 302
    assert login(post, password="errada").status_code == 200  # senha errada: comportamento normal
    assert login(post, email="naoexiste@example.com").status_code == 200  # usuário inexistente: idem


def test_old_session_of_unverified_account_is_not_authenticated(app, client, post):
    app.config.update(EMAIL_VERIFICATION_REQUIRED=False)
    register(post)  # criada já logada (modo antigo)
    assert client.get("/conta").status_code == 200
    c = customer_by()
    c.email_verified = False
    db.session.commit()
    app.config.update(EMAIL_VERIFICATION_REQUIRED=True)
    assert client.get("/conta").status_code == 302  # a sessão antiga deixa de valer


def test_random_modified_and_malformed_tokens_are_rejected(app, client, post, smtp):
    register(post)
    path = link_of(smtp.sent[0])
    token = path.rsplit("/", 1)[-1]
    for bad in ("x" * 43, token[:-1] + ("A" if token[-1] != "A" else "B"), token.upper(), "..%2f..", "a" * 129, token + "!"):
        r = client.get(f"/conta/confirmar-email/{bad}")
        assert r.status_code in (302, 404), bad
    assert customer_by().email_verified is False


def test_expired_token_is_rejected_and_cleared(app, client, post, smtp):
    register(post)
    path = link_of(smtp.sent[0])
    c = customer_by()
    c.email_verification_expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()
    page = client.get(path, follow_redirects=True).get_data(as_text=True)  # P
    assert "inválido ou expirou" in page
    c = customer_by()
    assert c.email_verified is False and c.email_verification_token_hash is None


def test_token_lifetime_follows_config(app, client, post, smtp):
    app.config.update(EMAIL_VERIFICATION_MAX_AGE=7200)
    register(post)
    c = customer_by()
    assert timedelta(seconds=7100) < c.email_verification_expires_at - utcnow() <= timedelta(seconds=7200)
    assert "2 horas" in body_of(smtp.sent[0], "plain")


def test_resend_replaces_token_and_old_link_dies(app, client, post, smtp):
    register(post)
    old = link_of(smtp.sent[0])
    old_hash = customer_by().email_verification_token_hash
    r = post("/conta/reenviar-verificacao", {"email": " ANA@Example.COM "}, token_from="/conta/verificar-email", follow=True)
    assert "Se houver uma conta aguardando confirmação" in r.get_data(as_text=True)
    assert len(smtp.sent) == 2  # S
    new = link_of(smtp.sent[1])
    assert new != old and customer_by().email_verification_token_hash != old_hash
    assert "inválido ou expirou" in client.get(old, follow_redirects=True).get_data(as_text=True)  # Q
    assert customer_by().email_verified is False
    assert client.get(new).status_code == 302 and customer_by().email_verified is True


def test_resend_does_not_reveal_whether_the_account_exists(app, client, post, smtp):
    register(post)
    page_a = post("/conta/reenviar-verificacao", {"email": "ana@example.com"}, token_from="/conta/verificar-email", follow=True).get_data(as_text=True)
    page_b = post("/conta/reenviar-verificacao", {"email": "ninguem@example.com"}, token_from="/conta/verificar-email", follow=True).get_data(as_text=True)
    phrase = "Se houver uma conta aguardando confirmação para esse endereço"
    assert phrase in page_a and phrase in page_b
    assert len(smtp.sent) == 1 + 1  # só a conta real recebeu (cadastro + 1 reenvio); o e-mail inexistente não gera envio
    done = customer_by()
    done.email_verified = True
    db.session.commit()
    before = len(smtp.sent)
    post("/conta/reenviar-verificacao", {"email": "ana@example.com"}, token_from="/conta/verificar-email")
    assert len(smtp.sent) == before  # conta já confirmada não recebe novo link


def test_resend_rate_limit_per_email_even_when_ip_changes(app, client, post, smtp):
    register(post)
    for n in range(1, 6):  # limite: 5 pedidos por e-mail por hora, mesmo trocando de IP
        post("/conta/reenviar-verificacao", {"email": "ana@example.com"}, token_from="/conta/verificar-email",
             environ_base={"REMOTE_ADDR": f"203.0.113.{n}"})
    assert len(smtp.sent) == 6
    limited = post("/conta/reenviar-verificacao", {"email": "ana@example.com"}, token_from="/conta/verificar-email",
                   environ_base={"REMOTE_ADDR": "203.0.113.99"}, follow=True)  # T
    assert "Muitas tentativas" in limited.get_data(as_text=True) and len(smtp.sent) == 6


def test_resend_rate_limit_per_ip_across_many_emails(app, client, post, smtp):
    for n in range(15):
        post("/conta/reenviar-verificacao", {"email": f"pessoa{n}@example.com"}, token_from="/conta/verificar-email")
    limited = post("/conta/reenviar-verificacao", {"email": "outra@example.com"}, token_from="/conta/verificar-email", follow=True)
    assert "Muitas tentativas" in limited.get_data(as_text=True)


def test_smtp_failure_does_not_authenticate_or_delete_account_and_resend_recovers(app, client, post, smtp):
    smtp.fail_send = OSError("smtp unavailable")
    r = register(post)  # U
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta/verificar-email")
    c = customer_by()
    assert c is not None and c.email_verified is False and c.email_verification_token_hash
    assert client.get("/conta").status_code == 302
    page = client.get("/conta/verificar-email").get_data(as_text=True)
    assert "não conseguimos enviar o e-mail" in page and "unavailable" not in page  # sem detalhe técnico no navegador
    smtp.fail_send = None
    post("/conta/reenviar-verificacao", {"email": "ana@example.com"}, token_from="/conta/verificar-email")
    assert len(smtp.sent) == 1 and client.get(link_of(smtp.sent[0])).status_code == 302
    assert customer_by().email_verified is True


def test_smtp_auth_error_is_generic_in_browser_and_never_logs_the_password(app, client, post, smtp, caplog):
    smtp.fail_login = True
    with caplog.at_level("DEBUG"):
        register(post)
    page = client.get("/conta/verificar-email").get_data(as_text=True)
    assert "senha-de-app-falsa" not in page and "535" not in page and "Senha de app" not in page
    logs = caplog.text
    assert "senha-de-app-falsa" not in logs and "Senha de app" in logs  # dica útil só no log do servidor
    assert customer_by().email_verified is False


def test_signup_blocked_when_smtp_missing_or_incomplete(app, client, post):
    app.config.update(EMAIL_VERIFICATION_REQUIRED=True, SMTP_HOST="", SMTP_USERNAME="", SMTP_PASSWORD="", SMTP_FROM="")
    r = register(post)  # V
    assert r.status_code == 503 and "temporariamente indisponível" in r.get_data(as_text=True)
    app.config.update(SMTP_HOST="smtp.gmail.com", SMTP_USERNAME="loja@gmail.com", SMTP_PASSWORD="", SMTP_FROM="loja@gmail.com")
    r = register(post)
    assert r.status_code == 503 and db.session.query(Customer).count() == 0


def test_contact_email_to_is_not_needed_for_confirmation(app, client, post, smtp):
    from knazh.services.mailer import smtp_configured, smtp_sender_configured
    app.config.update(CONTACT_EMAIL_TO="")  # Z
    with app.app_context():
        assert smtp_sender_configured() is True and smtp_configured() is False
    register(post)
    assert len(smtp.sent) == 1 and smtp.sent[0]["To"] == "ana@example.com"


def test_duplicate_email_with_different_case_is_refused_for_verified_accounts(app, client, post, smtp):
    c = Customer(name="Ana", email="ANA@Example.com", phone="41988887777")  # linha legada com maiúsculas, verificada
    c.set_password("senha1234")
    db.session.add(c)
    db.session.commit()
    response = register(post, email="ana@example.com")  # W
    assert response.status_code == 200 and db.session.query(Customer).count() == 1 and not smtp.sent
    assert login(post, email="ana@example.com").headers["Location"].endswith("/conta")


def test_new_signup_for_a_never_confirmed_email_takes_over_the_pending_account(app, client, post, smtp):
    register(post, name="Intruso", password="senha-do-intruso1", confirm="senha-do-intruso1")  # alguém reservou o e-mail
    first = link_of(smtp.sent[0])
    register(post, name="Ana Verdadeira")  # a dona refaz o cadastro com a senha dela
    assert db.session.query(Customer).count() == 1
    c = customer_by()
    assert c.name == "Ana Verdadeira" and c.check_password("senha1234") and not c.check_password("senha-do-intruso1")
    assert "inválido ou expirou" in client.get(first, follow_redirects=True).get_data(as_text=True)  # link do intruso morreu
    assert client.get(link_of(smtp.sent[1])).status_code == 302 and customer_by().email_verified is True


def test_legacy_accounts_stay_verified_and_can_log_in(app, client, post, smtp):
    c = Customer(name="Antiga", email="antiga@example.com", phone="41977776666")  # criada antes da funcionalidade
    c.set_password("senha1234")
    db.session.add(c)
    db.session.commit()
    assert customer_by("antiga@example.com").email_verified is True  # X
    assert login(post, email="antiga@example.com").headers["Location"].endswith("/conta")


def test_provisioned_admin_stays_functional_with_verification_on(app, client, post, smtp, monkeypatch):
    monkeypatch.setenv("INITIAL_ADMIN_PASSWORD", "SenhaForte#2026ok")
    runner = app.test_cli_runner()
    result = runner.invoke(args=["provision-initial-admin", "--email", "dono@knazh.test", "--yes"])
    assert result.exit_code == 0, result.output
    admin = customer_by("dono@knazh.test")
    assert admin.email_verified is True and admin.email_verified_at is not None and admin.is_admin  # Y
    r = login(post, email="dono@knazh.test", password="SenhaForte#2026ok")
    assert r.status_code == 302 and r.headers["Location"].endswith("/conta")
    assert client.get("/admin/produtos").status_code == 200


def test_promote_admin_warns_about_unverified_account(app, client, post, smtp):
    register(post)
    result = app.test_cli_runner().invoke(args=["promote-admin", "ana@example.com"])
    assert result.exit_code == 0 and "ainda não confirmou o e-mail" in result.output


def test_html_message_escapes_name_and_url(app, client, post, smtp):
    register(post, name='<img src=x onerror=alert(1)> "Ana"')
    html = body_of(smtp.sent[0], "html")
    assert "<img" not in html and "&lt;img" in html and "&quot;Ana&quot;" in html
    from knazh.services.mailer import send_verification_email
    with app.test_request_context():
        status = send_verification_email("Ana", "ana@example.com", 'https://x.test/a?b=1&c="2"')
    assert status == "enviado"
    last = body_of(smtp.sent[-1], "html")
    assert 'href="https://x.test/a?b=1&amp;c=&quot;2&quot;"' in last


def test_header_injection_in_recipient_is_rejected(app, smtp):
    from knazh.services.mailer import send_verification_email
    with app.test_request_context():
        assert send_verification_email("Ana", "a@b.test\nBcc: x@y.test", "https://x.test/t") == "falhou"
    assert smtp.sent == []


def test_test_email_command_and_config_check_never_print_secrets(app, smtp):
    runner = app.test_cli_runner()
    ok = runner.invoke(args=["test-email", "destino@example.com"])
    assert ok.exit_code == 0 and "E-mail de teste enviado" in ok.output
    assert smtp.sent[-1]["To"] == "destino@example.com" and "Teste de e-mail" in smtp.sent[-1]["Subject"]
    assert db.session.query(Customer).count() == 0  # não cria usuário
    bad = runner.invoke(args=["test-email", "não é email"])
    assert bad.exit_code != 0
    smtp.fail_login = True
    fail = runner.invoke(args=["test-email", "destino@example.com"])
    assert fail.exit_code != 0 and "Senha de app" in fail.output and "senha-de-app-falsa" not in fail.output
    report = runner.invoke(args=["check-email-config"])
    assert report.exit_code == 0
    assert "SMTP_PASSWORD: configurado" in report.output and "senha-de-app-falsa" not in report.output
    assert "loja@gmail.com" not in report.output  # nem o usuário é impresso
    app.config.update(SMTP_PASSWORD="", SMTP_HOST="")
    assert "SMTP_HOST: AUSENTE" in runner.invoke(args=["check-email-config"]).output
    app.config.update(SMTP_HOST="smtp.gmail.com", SMTP_PASSWORD="x", SMTP_FROM="outra@gmail.com")
    assert "SMTP_FROM deve ser o mesmo e-mail" in runner.invoke(args=["check-email-config"]).output


def test_site_url_problem_detection():
    from knazh.services.email_verification import site_url_problem
    assert site_url_problem("https://knazh.com.br", production=True) is None
    assert "https://" in site_url_problem("http://knazh.com.br", production=True)
    assert "local" in site_url_problem("http://localhost:5000", production=True)
    assert site_url_problem("http://127.0.0.1:5000", production=False) is None  # desenvolvimento
    assert site_url_problem("", production=True) and site_url_problem("ftp://x", production=True)


def test_env_example_has_no_real_credentials_and_documents_gmail():
    from pathlib import Path
    text = (Path(__file__).resolve().parent.parent / ".env.example").read_text(encoding="utf-8")
    active = {k: v for k, v in (line.split("=", 1) for line in text.splitlines() if "=" in line and not line.lstrip().startswith("#"))}
    assert active["EMAIL_VERIFICATION_REQUIRED"] == "true" and active["EMAIL_VERIFICATION_MAX_AGE"] == "86400"
    assert active["SMTP_HOST"] == "smtp.gmail.com" and active["SMTP_PORT"] == "587" and active["SMTP_USE_TLS"] == "true"
    for secret_key in ("SMTP_USERNAME", "SMTP_PASSWORD", "SMTP_FROM"):
        assert secret_key not in active  # só comentados: copiar o exemplo não ativa credenciais falsas
    assert "Senha de app" in text and "NUNCA use a senha normal" in text
