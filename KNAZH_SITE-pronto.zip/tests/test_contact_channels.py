"""Página de Contato: cards de WhatsApp e iFood (cartão inteiro clicável, sem links aninhados, links oficiais)."""
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

import pytest

from knazh.services.channels import CONTACT_MESSAGE

WA = "5541996206276"
IFOOD = ("https://www.ifood.com.br/delivery/almirante-tamandare-pr/knazh-jardim-graziela/"
         "db2ff914-8577-45d4-88cc-f57a05142ae9?utm_medium=share")
MESSAGE = "Olá! Vim pelo site da Knazh e gostaria de fazer um pedido."
ROOT = Path(__file__).resolve().parent.parent


def contact(app, client, whatsapp="", ifood=""):
    app.config.update(WHATSAPP_NUMBER=whatsapp, IFOOD_STORE_URL=ifood)
    return client.get("/contato").get_data(as_text=True)


def card(html, kind):
    m = re.search(rf'<a class="channel-card channel-card--{kind}" href="([^"]+)"([^>]*)>(.*?)</a>', html, re.S)
    return m and (m.group(1).replace("&amp;", "&"), m.group(2), m.group(3))


class NestedLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.depth = 0
        self.bad = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            if self.depth:
                self.bad.append("a dentro de a")
            self.depth += 1
        elif tag in ("button", "input", "select", "textarea") and self.depth:
            self.bad.append(f"{tag} dentro de a")

    def handle_endtag(self, tag):
        if tag == "a":
            self.depth -= 1


def test_message_is_the_approved_text_and_centralized():
    assert CONTACT_MESSAGE == MESSAGE


def test_whatsapp_and_ifood_cards_with_official_links(app, client):
    html = contact(app, client, whatsapp="41 99620-6276", ifood=IFOOD)
    wa, wa_attrs, wa_body = card(html, "wa")
    assert wa == f"https://wa.me/{WA}?text={quote(MESSAGE, safe='')}"
    assert parse_qs(urlparse(wa).query)["text"] == [MESSAGE]  # acentos e pontuação corretos após decodificar
    assert re.fullmatch(r"[A-Za-z0-9%._~:/?=-]+", wa)  # nada cru na URL
    assert 'target="_blank"' in wa_attrs and 'rel="noopener noreferrer"' in wa_attrs
    assert "<h3>WhatsApp</h3>" in wa_body and "Fale com a gente pelo WhatsApp." in wa_body and "Abrir no WhatsApp" in wa_body
    iff, if_attrs, if_body = card(html, "if")
    assert iff == IFOOD  # exatamente o link oficial, sem deep link nem esquema proprietário
    assert 'target="_blank"' in if_attrs and 'rel="noopener noreferrer"' in if_attrs
    assert "<h3>iFood</h3>" in if_body and "Veja nossa loja no iFood e peça online." in if_body and "Ver no iFood" in if_body
    assert "ainda não disponível" not in html and "ifood://" not in html


def test_questions_card_still_goes_to_the_form_in_the_same_tab(app, client):
    html = contact(app, client, whatsapp=WA, ifood=IFOOD)
    href, attrs, body = card(html, "form")
    assert href == "#formulario" and "target" not in attrs
    assert "Dúvidas e sugestões" in body and "Fale com a gente pelo formulário." in body and "Enviar mensagem" in body
    assert 'id="formulario"' in html


def test_whole_card_is_one_link_with_no_nested_interactive_elements(app, client):
    html = contact(app, client, whatsapp=WA, ifood=IFOOD)
    parser = NestedLinks()
    parser.feed(html)
    assert parser.bad == []
    for kind in ("wa", "if", "form"):  # o "botão" é visual dentro do mesmo link
        assert '<span class="cta ' in card(html, kind)[2]
    assert "(abre em nova aba)" in card(html, "wa")[2] and "(abre em nova aba)" in card(html, "if")[2]


@pytest.mark.parametrize("whatsapp, ifood, has_wa, has_if", [("", "", False, False), (WA, "", True, False),
                                                              ("", IFOOD, False, True), (WA, IFOOD, True, True)])
def test_cards_appear_only_for_configured_channels_without_breaking(app, client, whatsapp, ifood, has_wa, has_if):
    html = contact(app, client, whatsapp, ifood)
    assert bool(card(html, "wa")) is has_wa and bool(card(html, "if")) is has_if
    assert card(html, "form") and "Nossos canais" in html and "Envie uma mensagem" in html
    assert "Canal ainda não disponível" not in html and "WHATSAPP_NUMBER" not in html and "None" not in html
    assert ("wa.me" in html) is has_wa and ("ifood.com.br" in html) is has_if


def test_how_to_order_card_matches_reference_and_no_floating_whatsapp(app, client):
    html = contact(app, client, whatsapp=WA, ifood=IFOOD)
    section = html[html.index('id="pedir-title"'):]
    assert "Montar pedido pelo site" in section and "ifood.com.br" not in section and "wa.me" not in section
    assert "whatsapp-float" not in html and "wa-fab" not in html and "position: fixed" not in html


def test_contact_page_survives_direct_refresh_and_other_pages_unchanged(app, client):
    app.config.update(WHATSAPP_NUMBER=WA, IFOOD_STORE_URL=IFOOD)
    assert client.get("/contato").status_code == 200 and client.get("/contato").status_code == 200
    for page in ("/", "/cardapio", "/duvidas", "/sobre", "/carrinho"):
        assert client.get(page).status_code == 200, page


def test_card_css_has_hover_focus_active_and_reduced_motion():
    css = (ROOT / "knazh" / "static" / "css" / "pages.css").read_text(encoding="utf-8")
    for needle in (".channel-card:hover", ".channel-card:focus-visible", ".channel-card:active",
                   ".channel-card--wa", ".channel-card--if", ".btn--wa-solid"):
        assert needle in css
    assert re.search(r"prefers-reduced-motion: reduce\) \{[^}]*\.channel-card", css)
