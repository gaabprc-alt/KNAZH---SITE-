/* KNAZH — painel administrativo. Melhorias progressivas: sem JavaScript tudo continua funcionando
   (a exclusão usa a tela de confirmação; o envio da foto funciona sem pré-visualização; a categoria nova
   é criada ao salvar o produto). A foto só vai ao servidor quando o formulário é salvo; o botão "Criar categoria"
   envia apenas o nome da categoria. Compatível com a CSP do site (sem inline, sem blob:). */
(function () {
  'use strict';

  /* Avisos temporários */
  document.querySelectorAll('.toast').forEach(function (t) { setTimeout(function () { t.remove(); }, 7000); });

  /* Barra lateral: no desktop recolhe (lembra a escolha); no celular abre como gaveta com fundo, Esc, foco e
     bloqueio da rolagem. A engrenagem é um link real para a loja; a animação de saída é só um acabamento. */
  (function () {
    var shell = document.querySelector('[data-admin-shell]');
    var side = document.querySelector('[data-admin-side]');
    var btn = document.querySelector('[data-admin-toggle]');
    var overlay = document.querySelector('[data-admin-overlay]');
    if (!shell || !side || !btn) return;
    var wide = window.matchMedia('(min-width: 960px)');
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    var links = Array.prototype.slice.call(side.querySelectorAll('a[href], button'));
    function store(v) { try { localStorage.setItem('knazh-admin-collapsed', v ? '1' : '0'); } catch (e) {} }
    function stored() { try { return localStorage.getItem('knazh-admin-collapsed') === '1'; } catch (e) { return false; } }
    function titles(on) {
      side.querySelectorAll('.admin-nav a').forEach(function (a) {
        var label = a.querySelector('span');
        if (on && label) a.setAttribute('title', label.textContent.trim()); else a.removeAttribute('title');
      });
    }
    function setCollapsed(on) { shell.classList.toggle('is-collapsed', on); btn.setAttribute('aria-expanded', String(!on)); titles(on); }
    function setOpen(on) {
      shell.classList.toggle('is-open', on);
      document.documentElement.classList.toggle('admin-lock', on);
      if (overlay) overlay.hidden = !on;
      btn.setAttribute('aria-expanded', String(on));
      if (on) { var first = side.querySelector('a[href]'); if (first) first.focus(); } else { btn.focus(); }
    }
    function init() {
      shell.classList.remove('is-open'); document.documentElement.classList.remove('admin-lock'); if (overlay) overlay.hidden = true;
      if (wide.matches) setCollapsed(stored()); else { shell.classList.remove('is-collapsed'); titles(false); btn.setAttribute('aria-expanded', 'false'); }
    }
    btn.addEventListener('click', function () {
      if (wide.matches) { var on = !shell.classList.contains('is-collapsed'); setCollapsed(on); store(on); }
      else setOpen(!shell.classList.contains('is-open'));
    });
    if (overlay) overlay.addEventListener('click', function () { setOpen(false); });
    side.addEventListener('click', function (e) { if (!wide.matches && e.target.closest('a[href]')) setOpen(false); });
    document.addEventListener('keydown', function (e) {
      if (wide.matches || !shell.classList.contains('is-open')) return;
      if (e.key === 'Escape') { e.preventDefault(); setOpen(false); return; }
      if (e.key !== 'Tab' || !links.length) return;
      var first = links[0], last = links[links.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    if (wide.addEventListener) wide.addEventListener('change', init);
    init();

    var leave = document.querySelector('[data-admin-leave]');
    if (leave) leave.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      e.preventDefault();
      var href = leave.href;
      shell.classList.add('is-leaving');
      setTimeout(function () { window.location.href = href; }, reduce.matches ? 0 : 230);
    });
    window.addEventListener('pageshow', function () { shell.classList.remove('is-leaving'); });
  })();

  /* Evita envio duplicado */
  document.querySelectorAll('form[data-once]').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('button[type="submit"]');
      if (b) setTimeout(function () { b.disabled = true; b.setAttribute('aria-busy', 'true'); }, 0);
    });
  });

  /* Pedido: o campo "Motivo do cancelamento" só aparece (e vira obrigatório) quando "Cancelado" está selecionado.
     Sem JavaScript o campo fica sempre visível e o servidor é quem exige o motivo. */
  document.querySelectorAll('[data-status-form]').forEach(function (form) {
    var select = form.querySelector('[data-status-select]');
    var field = form.querySelector('[data-reason-field]');
    var input = form.querySelector('[data-reason-input]');
    if (!select || !field || !input) return;
    function sync() {
      var cancel = select.value === 'cancelado';
      field.hidden = !cancel;
      input.required = cancel;
    }
    select.addEventListener('change', sync);
    sync();
  });

  /* Confirmação de exclusão em diálogo acessível (<dialog>: foco preso, Esc fecha) */
  var dialog = document.querySelector('[data-delete-dialog]');
  if (dialog && typeof dialog.showModal === 'function') {
    var form = dialog.querySelector('[data-delete-form]');
    var nameEl = dialog.querySelector('[data-delete-name]');
    var opener = null;
    document.querySelectorAll('[data-delete]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        opener = link;
        form.action = link.getAttribute('href');   /* a mesma URL aceita POST (exclusão) e GET (tela de confirmação) */
        nameEl.textContent = link.getAttribute('data-product-name') || '';
        dialog.showModal();
        var cancel = dialog.querySelector('[data-dialog-cancel]');
        if (cancel) cancel.focus();                 /* foco inicial no botão seguro */
      });
    });
    dialog.querySelector('[data-dialog-cancel]').addEventListener('click', function () { dialog.close(); });
    dialog.addEventListener('click', function (e) { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener('close', function () { if (opener) opener.focus(); });
    form.addEventListener('submit', function () {
      var b = form.querySelector('button[type="submit"]');
      if (b) setTimeout(function () { b.disabled = true; b.setAttribute('aria-busy', 'true'); }, 0);
    });
  }

  /* Confirmação de conceder/remover acesso administrativo (<dialog>). Sem JavaScript, o link abre a tela de
     confirmação do servidor. A permissão é sempre validada no servidor; isto é só a etapa de confirmação. */
  var adm = document.querySelector('[data-admin-dialog]');
  if (adm && typeof adm.showModal === 'function') {
    var aform = adm.querySelector('[data-admin-form]');
    var atitle = adm.querySelector('[data-admin-title]');
    var atext = adm.querySelector('[data-admin-text]');
    var amanage = adm.querySelector('[data-admin-manage]');
    var aconfirm = adm.querySelector('[data-admin-confirm]');
    var aopener = null;
    document.querySelectorAll('[data-admin-action]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        aopener = link;
        var grant = link.getAttribute('data-admin-action') === 'grant';
        var name = link.getAttribute('data-user-name') || '';
        aform.action = link.getAttribute('href');
        amanage.hidden = !grant;
        amanage.querySelector('input').checked = false;
        atitle.textContent = grant ? 'Tornar administrador(a)?' : 'Remover acesso administrativo?';
        atext.textContent = grant
          ? '“' + name + '” passará a acessar o painel e poderá cadastrar, editar e excluir produtos da loja.'
          : '“' + name + '” perderá o acesso ao painel. A conta continua existindo como cliente comum.';
        aconfirm.textContent = grant ? 'Conceder acesso' : 'Remover acesso';
        aconfirm.className = 'btn ' + (grant ? 'btn--primary' : 'btn--danger');
        aconfirm.disabled = false; aconfirm.removeAttribute('aria-busy');
        adm.showModal();
        adm.querySelector('[data-dialog-cancel]').focus();   /* foco inicial no botão seguro */
      });
    });
    adm.querySelector('[data-dialog-cancel]').addEventListener('click', function () { adm.close(); });
    adm.addEventListener('click', function (e) { if (e.target === adm) adm.close(); });
    adm.addEventListener('close', function () { if (aopener) aopener.focus(); });
    aform.addEventListener('submit', function () { setTimeout(function () { aconfirm.disabled = true; aconfirm.setAttribute('aria-busy', 'true'); }, 0); });
  }

  /* Pré-visualização instantânea da foto (FileReader -> data:, permitido pela CSP). Só conveniência:
     o servidor revalida tipo, tamanho e conteúdo de qualquer forma. */
  var box = document.querySelector('[data-photo]');
  if (box && window.FileReader) {
    var input = box.querySelector('[data-image-input]');
    var img = box.querySelector('[data-image-preview]');
    var empty = box.querySelector('[data-image-empty]');
    var status = box.querySelector('[data-photo-status]');
    var errEl = box.querySelector('[data-photo-error]');
    var reset = box.querySelector('[data-photo-reset]');
    var maxBytes = parseInt(box.getAttribute('data-max-bytes'), 10) || 0;
    var original = img.getAttribute('data-original-src') || '';
    var ok = { 'image/jpeg': 1, 'image/png': 1, 'image/webp': 1 };
    var originalStatus = status.textContent;

    function showError(msg) { errEl.textContent = msg; errEl.hidden = !msg; }
    function restore() {
      input.value = '';
      showError('');
      if (original) { img.src = original; img.hidden = false; if (empty) empty.hidden = true; }
      else { img.hidden = true; img.removeAttribute('src'); if (empty) empty.hidden = false; }
      status.textContent = originalStatus;
      if (reset) reset.hidden = true;
    }
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      showError('');
      if (!file) { restore(); return; }
      if (!ok[file.type]) { restore(); showError('Formato não permitido. Escolha uma imagem JPG, PNG ou WebP.'); return; }
      if (maxBytes && file.size > maxBytes) { restore(); showError('A imagem é grande demais. O tamanho máximo é ' + Math.round(maxBytes / 1048576) + ' MiB.'); return; }
      var reader = new FileReader();
      reader.onload = function () {
        img.src = reader.result; img.alt = 'Pré-visualização da nova foto'; img.hidden = false;
        if (empty) empty.hidden = true;
        status.textContent = 'Nova foto (ainda não salva)';
        if (reset) reset.hidden = false;
      };
      reader.onerror = function () { restore(); showError('Não foi possível ler esse arquivo.'); };
      reader.readAsDataURL(file);
    });
    if (reset) reset.addEventListener('click', function () { restore(); input.focus(); });
  }

  /* Criar categoria sem sair do cadastro: envia só o nome (fetch, mesmo domínio, com CSRF), acrescenta a opção na lista
     e já a seleciona. Sem JavaScript, o campo "Nova categoria" é criado ao salvar o produto (o botão fica oculto). */
  var newcat = document.querySelector('[data-newcat]');
  var catSelect = document.getElementById('category_id');
  var catInput = document.getElementById('new_category');
  var catBtn = newcat && newcat.querySelector('[data-newcat-btn]');
  var catMsg = newcat && newcat.querySelector('[data-newcat-msg]');
  if (newcat && catSelect && catInput && catBtn && catMsg && window.fetch) {
    var csrfMeta = document.querySelector('meta[name="csrf-token"]');
    catBtn.hidden = false;
    var say = function (text, isError) {
      catMsg.textContent = text || '';
      catMsg.hidden = !text;
      catMsg.classList.toggle('is-error', !!isError);
    };
    var selectCategory = function (id, name) {
      var option = catSelect.querySelector('option[value="' + id + '"]');
      if (!option) {
        option = document.createElement('option');
        option.value = String(id);
        option.textContent = name;
        catSelect.appendChild(option);
      }
      catSelect.value = String(id);
    };
    var createCategory = function () {
      var name = catInput.value.trim();
      if (!name) { say('Informe o nome da nova categoria.', true); catInput.focus(); return; }
      catBtn.disabled = true;
      catBtn.setAttribute('aria-busy', 'true');
      say('', false);
      var body = new FormData();
      body.append('name', name);
      fetch(catBtn.getAttribute('data-url'), {
        method: 'POST', body: body, credentials: 'same-origin',
        headers: { 'X-CSRFToken': csrfMeta ? csrfMeta.content : '', 'X-Requested-With': 'fetch' }
      }).then(function (response) {
        return response.json().catch(function () { return { ok: false, message: 'Não foi possível criar a categoria agora.' }; });
      }).then(function (data) {
        if (data.ok) {
          selectCategory(data.id, data.name);
          catInput.value = '';
          say(data.message + ' Ela já está selecionada para este produto.', false);
        } else {
          if (data.existing_id) { var dup = catSelect.querySelector('option[value="' + data.existing_id + '"]'); if (dup) catSelect.value = String(data.existing_id); }
          say(data.message || 'Não foi possível criar a categoria agora.', true);
        }
      }).catch(function () {
        say('Sem conexão com o servidor. Confira a internet e tente de novo.', true);
      }).then(function () {
        catBtn.disabled = false;
        catBtn.removeAttribute('aria-busy');
      });
    };
    catBtn.addEventListener('click', createCategory);
    catInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') { event.preventDefault(); createCategory(); }  /* Enter não salva o produto sem querer */
    });
  }

  /* Foco no resumo de erros do formulário */
  var alertBox = document.querySelector('[data-form-alert]');
  if (alertBox) alertBox.focus();
})();
