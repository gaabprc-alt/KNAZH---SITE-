"""Envio de e-mails do site via SMTP."""
from __future__ import annotations

import logging
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid, parseaddr
from html import escape

from flask import current_app

log = logging.getLogger(__name__)


def smtp_sender_configured(config=None) -> bool:
    """SMTP suficiente para ENVIAR e-mails (confirmação de cadastro, teste). NÃO exige CONTACT_EMAIL_TO."""
    c = config if config is not None else current_app.config
    return bool(
        c["SMTP_HOST"]
        and (c["SMTP_FROM"] or c["SMTP_USERNAME"])
        and (not c["SMTP_USERNAME"] or c["SMTP_PASSWORD"])
    )


def smtp_configured() -> bool:
    """Configuração suficiente para o formulário de contato (remetente SMTP + CONTACT_EMAIL_TO)."""
    c = current_app.config
    return bool(smtp_sender_configured() and c["CONTACT_EMAIL_TO"])


def _from_header() -> str:
    """Remetente vem SOMENTE da configuração (nunca de dados do usuário). Ex.: KNAZH <conta@gmail.com>."""
    raw = current_app.config["SMTP_FROM"] or current_app.config["SMTP_USERNAME"]
    name, addr = parseaddr(raw)
    return raw if name else formataddr(("KNAZH", addr or raw))


def _stamp(msg: EmailMessage) -> None:
    """Date e Message-ID (exigidos por vários provedores; ajudam a entrega)."""
    _, addr = parseaddr(msg["From"] or "")
    domain = addr.rsplit("@", 1)[-1] if "@" in addr else None
    msg["Date"] = formatdate(localtime=False)
    msg["Message-ID"] = make_msgid(domain=domain)


def _send_detailed(msg: EmailMessage) -> tuple[str, str]:
    """Retorna (status, dica). status: 'enviado', 'falhou' ou 'nao_configurado'. A dica é para o ADMINISTRADOR (log/CLI),
    nunca para o navegador, e jamais contém senha ou token."""
    if not smtp_sender_configured():
        return "nao_configurado", "Configure SMTP_HOST, SMTP_FROM (ou SMTP_USERNAME) e, havendo usuário, SMTP_PASSWORD."
    c = current_app.config
    host, port = c["SMTP_HOST"], c["SMTP_PORT"]
    context = ssl.create_default_context()  # valida o certificado do servidor (nada de verificação desligada)
    try:
        smtp = smtplib.SMTP_SSL(host, port, timeout=10, context=context) if port == 465 else smtplib.SMTP(host, port, timeout=10)
        with smtp:
            smtp.ehlo()
            if port != 465 and c["SMTP_USE_TLS"]:
                smtp.starttls(context=context)
                smtp.ehlo()
            if c["SMTP_USERNAME"]:
                smtp.login(c["SMTP_USERNAME"], c["SMTP_PASSWORD"])
            smtp.send_message(msg)
        return "enviado", ""
    except smtplib.SMTPAuthenticationError as exc:
        hint = ("O servidor SMTP recusou o login. No Gmail use uma Senha de app (exige verificação em duas etapas), "
                "o mesmo e-mail em SMTP_USERNAME e SMTP_FROM, e nunca a senha normal da conta.")
        log.error("Falha SMTP (autenticação, código %s). %s", getattr(exc, "smtp_code", "?"), hint)
    except ssl.SSLError as exc:
        hint = "Falha de TLS/certificado ao falar com o servidor SMTP (verifique SMTP_HOST, a porta e SMTP_USE_TLS)."
        log.error("Falha SMTP (TLS): %s", exc.__class__.__name__)
    except smtplib.SMTPRecipientsRefused:
        hint = "O servidor SMTP recusou o destinatário."
        log.error("Falha SMTP: destinatário recusado.")
    except (smtplib.SMTPException, OSError) as exc:
        hint = "Não foi possível falar com o servidor SMTP (conexão, porta, firewall ou serviço indisponível)."
        log.error("Falha SMTP (%s): %s", exc.__class__.__name__, exc)
    except Exception as exc:  # noqa: BLE001 - qualquer outro erro vira "falhou"; o detalhe fica só no log
        hint = "Erro inesperado ao enviar o e-mail (veja o log do servidor)."
        log.exception("Falha inesperada ao enviar e-mail SMTP (%s)", exc.__class__.__name__)
    return "falhou", hint


def _send(msg: EmailMessage) -> str:
    return _send_detailed(msg)[0]


def send_contact_email(name: str, email: str, subject: str, body: str) -> str:
    """Retorna 'enviado', 'falhou' ou 'nao_configurado'."""
    if not smtp_configured():
        return "nao_configurado"
    c = current_app.config
    msg = EmailMessage()
    msg["Subject"] = f"[Site KNAZH] {subject}"
    msg["From"] = _from_header()
    msg["To"] = c["CONTACT_EMAIL_TO"]
    msg["Reply-To"] = email
    msg.set_content(f"Nome: {name}\nE-mail: {email}\nAssunto: {subject}\n\n{body}")
    _stamp(msg)
    return _send(msg)


def send_verification_email(name: str, email: str, verification_url: str) -> str:
    """Envia o link de confirmação de cadastro PARA `email` (não depende de CONTACT_EMAIL_TO).
    Retorna 'enviado', 'falhou' ou 'nao_configurado'."""
    if not smtp_sender_configured():
        return "nao_configurado"
    c = current_app.config
    hours = max(1, (c["EMAIL_VERIFICATION_MAX_AGE"] + 3599) // 3600)
    validity = f"{hours} hora" if hours == 1 else f"{hours} horas"
    url_attr = escape(verification_url, quote=True)
    msg = EmailMessage()
    try:
        msg["Subject"] = "Confirme seu e-mail — KNAZH"
        msg["From"] = _from_header()
        msg["To"] = email  # EmailMessage recusa quebras de linha (injeção de cabeçalho) e levanta ValueError
    except ValueError:
        log.error("Endereço de destino inválido para o e-mail de confirmação.")
        return "falhou"
    _stamp(msg)
    msg.set_content(
        f"KNAZH\n\nOlá, {name}!\n\n"
        "Confirme seu e-mail\n\n"
        "Recebemos um pedido para criar uma conta na KNAZH com este endereço.\n"
        "Para confirmar que ele é seu, abra o link abaixo:\n\n"
        f"{verification_url}\n\n"
        f"Este link vale por {validity} e só pode ser usado uma vez.\n"
        "Se você não fez este cadastro, ignore esta mensagem: nada será ativado.\n"
    )
    msg.add_alternative(
        '<!doctype html><html lang="pt-BR"><body style="margin:0;padding:0;background:#f7f4ef;'
        'font-family:Arial,Helvetica,sans-serif;color:#3a1608">'
        '<div style="max-width:560px;margin:24px auto;padding:32px;background:#ffffff;border-radius:16px">'
        '<p style="margin:0 0 16px;font-size:28px;font-weight:bold;letter-spacing:1px;color:#e8650f">KNAZH</p>'
        '<h1 style="margin:0 0 16px;font-size:24px;color:#3a1608">Confirme seu e-mail</h1>'
        f"<p>Olá, {escape(name)}!</p>"
        "<p>Recebemos um pedido para criar uma conta na KNAZH com este endereço. "
        "Para confirmar que ele é seu, clique no botão abaixo.</p>"
        f'<p style="margin:28px 0"><a href="{url_attr}" style="display:inline-block;padding:16px 28px;'
        'background:#c2500a;color:#ffffff;font-size:18px;font-weight:bold;text-decoration:none;'
        'border-radius:10px">Confirmar meu e-mail</a></p>'
        f'<p style="font-size:14px">Se o botão não funcionar, copie e cole este link no navegador:<br>'
        f'<a href="{url_attr}" style="color:#c2500a;word-break:break-all">{escape(verification_url)}</a></p>'
        f'<p style="font-size:14px;color:#6b5a50">Este link vale por {validity} e só pode ser usado uma vez. '
        "Se você não fez este cadastro, ignore esta mensagem: nada será ativado.</p>"
        "</div></body></html>",
        subtype="html",
    )
    return _send(msg)


def send_test_email(to: str) -> tuple[str, str]:
    """E-mail de diagnóstico (comando `test-email`). Não cria usuário nem usa token. Retorna (status, dica para o admin)."""
    msg = EmailMessage()
    try:
        msg["Subject"] = "Teste de e-mail — KNAZH"
        msg["From"] = _from_header() if smtp_sender_configured() else "teste@invalid"
        msg["To"] = to
    except ValueError:
        return "falhou", "Endereço de destino inválido."
    _stamp(msg)
    msg.set_content("Este é um e-mail de teste do site KNAZH.\nSe você o recebeu, o envio por SMTP está funcionando.\n")
    return _send_detailed(msg)


def email_config_report() -> tuple[list[tuple[str, str]], list[str]]:
    """(linhas, avisos) sobre a configuração de e-mail, SEM valores secretos (só 'configurado'/'ausente')."""
    from .email_verification import site_url_problem

    c = current_app.config
    yes = lambda value: "configurado" if value else "AUSENTE"  # noqa: E731
    rows = [
        ("SMTP_HOST", yes(c["SMTP_HOST"])),
        ("SMTP_PORT", str(c["SMTP_PORT"])),
        ("SMTP_USE_TLS", "true" if c["SMTP_USE_TLS"] else "false"),
        ("SMTP_USERNAME", yes(c["SMTP_USERNAME"])),
        ("SMTP_PASSWORD", yes(c["SMTP_PASSWORD"])),
        ("SMTP_FROM", yes(c["SMTP_FROM"]) if c["SMTP_FROM"] else ("usa SMTP_USERNAME" if c["SMTP_USERNAME"] else "AUSENTE")),
        ("CONTACT_EMAIL_TO (só formulário de contato)", yes(c["CONTACT_EMAIL_TO"]) if c["CONTACT_EMAIL_TO"] else "vazio (não afeta a confirmação)"),
        ("EMAIL_VERIFICATION_REQUIRED", "true" if c["EMAIL_VERIFICATION_REQUIRED"] else "false"),
        ("EMAIL_VERIFICATION_MAX_AGE", f"{c['EMAIL_VERIFICATION_MAX_AGE']} s"),
        ("SITE_URL", yes(c["SITE_URL"])),
        ("Envio possível", "sim" if smtp_sender_configured() else "NÃO"),
    ]
    warnings = []
    if c["SMTP_USERNAME"] and c["SMTP_FROM"] and "gmail" in c["SMTP_HOST"].lower():
        if parseaddr(c["SMTP_FROM"])[1].lower() != c["SMTP_USERNAME"].strip().lower():
            warnings.append("No Gmail, SMTP_FROM deve ser o mesmo e-mail de SMTP_USERNAME (senão o Google reescreve o remetente ou recusa).")
    if c["EMAIL_VERIFICATION_REQUIRED"] and not smtp_sender_configured():
        warnings.append("A confirmação de e-mail está ativa e o SMTP está incompleto: o cadastro de clientes ficará indisponível.")
    if c["EMAIL_VERIFICATION_REQUIRED"]:
        problem = site_url_problem(c["SITE_URL"], production=bool(c.get("IS_PRODUCTION")))
        if problem:
            warnings.append(problem)
    return rows, warnings
