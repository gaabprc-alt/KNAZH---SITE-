"""Canais comerciais (WhatsApp / iFood / redes). Tudo vem da configuração; nada é inventado.
Um link para a loja do iFood NÃO é integração de pedidos; abrir o WhatsApp NÃO garante envio/confirmação."""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import quote, urlparse

from flask import current_app

from .money import format_brl


def normalize_whatsapp(number: str | None) -> str | None:
    """Retorna só dígitos com DDI (55 assumido para números BR de 10/11 dígitos) ou None se inválido."""
    digits = re.sub(r"\D", "", number or "")
    if len(digits) in (10, 11):
        digits = "55" + digits
    if 12 <= len(digits) <= 15:
        return digits
    return None


def format_phone_display(digits: str) -> str:
    if digits.startswith("55") and len(digits) in (12, 13):
        ddd, rest = digits[2:4], digits[4:]
        return f"({ddd}) {rest[:-4]}-{rest[-4:]}"
    return "+" + digits


def safe_https_url(url: str | None) -> str | None:
    """Aceita apenas URLs https com host válido (bloqueia javascript:, data:, http:, etc.)."""
    if not url:
        return None
    parsed = urlparse(url.strip())
    if parsed.scheme != "https" or not parsed.netloc or " " in url or not re.fullmatch(r"[A-Za-z0-9.-]+(:\d+)?", parsed.netloc):
        return None
    return url.strip()


# Mensagem pré-preenchida do WhatsApp na página de Contato (um único lugar; é codificada com quote() em whatsapp_link).
CONTACT_MESSAGE = "Olá! Vim pelo site da Knazh e gostaria de fazer um pedido."


@dataclass(frozen=True)
class Channels:
    whatsapp_digits: str | None
    ifood_url: str | None
    instagram: str | None
    tiktok: str | None
    facebook: str | None
    youtube: str | None
    email: str | None

    @property
    def whatsapp_configured(self) -> bool:
        return bool(self.whatsapp_digits)

    @property
    def ifood_configured(self) -> bool:
        return bool(self.ifood_url)

    @property
    def whatsapp_display(self) -> str:
        return format_phone_display(self.whatsapp_digits) if self.whatsapp_digits else ""

    def whatsapp_link(self, message: str | None = None) -> str | None:
        if not self.whatsapp_digits:
            return None
        url = f"https://wa.me/{self.whatsapp_digits}"
        if message:
            url += "?text=" + quote(message[:1500], safe="")
        return url

    def contact_whatsapp_link(self) -> str | None:
        """Link do card "WhatsApp" da página de Contato: wa.me abre o app no celular e o WhatsApp Web no computador."""
        return self.whatsapp_link(CONTACT_MESSAGE)

    @property
    def socials(self) -> list[tuple[str, str, str]]:
        items = [("instagram", "Instagram", self.instagram), ("tiktok", "TikTok", self.tiktok),
                 ("facebook", "Facebook", self.facebook), ("youtube", "YouTube", self.youtube)]
        return [(k, label, url) for k, label, url in items if url]


def get_channels() -> Channels:
    c = current_app.config
    email = (c.get("PUBLIC_CONTACT_EMAIL") or "").strip()
    return Channels(
        whatsapp_digits=normalize_whatsapp(c.get("WHATSAPP_NUMBER")),
        ifood_url=safe_https_url(c.get("IFOOD_STORE_URL")),
        instagram=safe_https_url(c.get("INSTAGRAM_URL")),
        tiktok=safe_https_url(c.get("TIKTOK_URL")),
        facebook=safe_https_url(c.get("FACEBOOK_URL")),
        youtube=safe_https_url(c.get("YOUTUBE_URL")),
        email=email if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) else None,
    )


def cart_message(lines, subtotal_cents: int) -> str:
    rows = ["Olá, KNAZH! Gostaria de pedir:"]
    for l in lines:
        rows.append(f"• {l.quantity}x {l.product.name} — {format_brl(l.total_cents)}")
    rows.append(f"Total estimado: {format_brl(subtotal_cents)}")
    return "\n".join(rows)


# Limite do texto bruto: abaixo do corte de segurança de whatsapp_link (1500), para nunca cortar o fim da mensagem.
ORDER_MESSAGE_MAX_CHARS = 1450

_ORDER_MESSAGE_FOOTER = (
    "Gostaria de confirmar meu pedido.\n\n"
    "Para concluirmos, podemos combinar por aqui:\n"
    "• entrega ou retirada;\n"
    "• endereço, caso seja entrega;\n"
    "• melhor horário;\n"
    "• forma de pagamento;\n"
    "• troco, se necessário;\n"
    "• demais informações necessárias para o pedido."
)


def _clean_lines(text: str | None) -> str:
    """Remove espaços sobrando e linhas vazias; devolve \"\" se não houver conteúdo real."""
    return "\n".join(" ".join(line.split()) for line in (text or "").splitlines() if line.strip())


def order_message(order) -> str:
    """Resumo do pedido para o WhatsApp, montado só com o que foi SALVO no pedido (snapshot dos itens: nome, quantidade
    e valores do momento da compra; o catálogo atual não é consultado). Campos vazios não aparecem. Se o pedido for
    muito grande, os últimos itens viram \"e mais N item(ns)\" para o texto caber no link sem ser cortado."""
    head = (f"Olá, KNAZH! Acabei de registrar um pedido pelo site.\n\nPedido: {order.number}\nItens:\n")
    tail = [f"Produtos: {format_brl(order.subtotal_cents)}"]
    name = " ".join((order.customer_name or "").split())
    if name:
        tail.append(f"Nome: {name}")
    notes = _clean_lines(order.notes)
    if notes:
        tail.append(f"Observações:\n{notes}")
    tail_text = "\n".join(tail) + "\n\n" + _ORDER_MESSAGE_FOOTER

    rows = [f"• {i.quantity}x {i.product_name} — {format_brl(i.line_total_cents)}" for i in order.items]
    budget = ORDER_MESSAGE_MAX_CHARS - len(head) - len(tail_text) - 2
    shown: list[str] = []
    for n, row in enumerate(rows):
        remaining = len(rows) - n - 1
        reserve = 0 if remaining == 0 else len(f"• … e mais {remaining} item(ns)") + 1
        if shown and budget - (len(row) + 1) < reserve:
            break
        budget -= len(row) + 1
        shown.append(row)
    hidden = len(rows) - len(shown)
    if hidden:
        shown.append(f"• … e mais {hidden} item(ns)")
    return head + "\n".join(shown) + "\n\n" + tail_text


def cancellation_message(order) -> str:
    """Texto para o administrador abrir a conversa manualmente (wa.me) quando o aviso automático não foi enviado.
    Só traz número do pedido, motivo e orientação: nada de dados pessoais além do nome já conhecido pelo cliente."""
    event = order.cancellation
    reason = event.reason if event is not None and event.reason else ""
    rows = [f"Olá, {order.customer_name}! Aqui é da KNAZH.", f"Informamos que o pedido {order.number} foi cancelado."]
    if reason:
        rows.append(f"Motivo: {reason}")
    rows.append("Se precisar de ajuda ou quiser fazer um novo pedido, é só responder esta mensagem.")
    return "\n".join(rows)
