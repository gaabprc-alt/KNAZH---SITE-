"""Cliente mínimo da WhatsApp Business Platform (Cloud API oficial da Meta), só com a biblioteca padrão.

- NÃO usa link wa.me, navegador nem automação não oficial: faz uma chamada HTTPS autenticada à API.
- Credenciais vêm só do ambiente (.env / gerenciador de segredos), nunca do HTML, do JavaScript ou do Git.
- Mensagens iniciadas pela empresa exigem MODELO (template) aprovado pela Meta; por isso só enviamos modelos.
- Sucesso = a API respondeu 2xx COM o identificador da mensagem (`wamid...`). Isso significa "aceita pela API":
  entrega e leitura no celular não são acompanhadas aqui (exigiriam webhooks).
- Nenhuma função devolve nem registra o token ou números de telefone completos em mensagens de erro.

Este módulo não depende de Flask nem do banco, para poder ser testado isoladamente.
"""
from __future__ import annotations

import http.client
import json
import re
import socket
import urllib.error
import urllib.request
from dataclasses import dataclass

GRAPH_BASE = "https://graph.facebook.com"
_VERSION_RE = re.compile(r"^v\d{1,3}\.\d{1,2}$")
_PHONE_ID_RE = re.compile(r"^\d{5,30}$")
_TEMPLATE_RE = re.compile(r"^[a-z0-9_]{1,512}$")
_LANG_RE = re.compile(r"^[a-z]{2,3}(_[A-Z]{2})?$")
_TO_RE = re.compile(r"^\d{10,15}$")
_MESSAGE_ID_RE = re.compile(r"^[\w.=:+\-]{1,120}$")
_LONG_DIGITS = re.compile(r"\d{8,}")
_WS = re.compile(r"\s+")
MAX_PARAM_CHARS = 600

# Os testes substituem esta função; nenhum teste automatizado fala com a rede de verdade.
_urlopen = urllib.request.urlopen


@dataclass(frozen=True)
class WhatsAppSettings:
    enabled: bool = False
    phone_number_id: str = ""
    access_token: str = ""
    api_version: str = "v25.0"
    timeout: float = 5.0
    language: str = "pt_BR"

    def missing(self) -> list[str]:
        """Nomes (nunca valores) das variáveis de ambiente que impedem o envio."""
        out: list[str] = []
        if not self.enabled:
            out.append("WHATSAPP_API_ENABLED")
        if not _PHONE_ID_RE.match(self.phone_number_id or ""):
            out.append("WHATSAPP_PHONE_NUMBER_ID")
        if not (self.access_token or "").strip():
            out.append("WHATSAPP_ACCESS_TOKEN")
        if not _VERSION_RE.match(self.api_version or ""):
            out.append("WHATSAPP_API_VERSION")
        return out

    @property
    def configured(self) -> bool:
        return not self.missing()


class WhatsAppError(Exception):
    """Falha ao enviar. `safe_message` pode ser gravada no banco e exibida no painel (sem token e sem telefone)."""

    def __init__(self, safe_message: str):
        super().__init__(safe_message)
        self.safe_message = safe_message


@dataclass(frozen=True)
class SendResult:
    message_id: str


def clean_param(value, max_len: int = MAX_PARAM_CHARS) -> str:
    """Valor de variável de modelo: a Meta recusa vazio, quebra de linha, tabulação e mais de 4 espaços seguidos."""
    text = _WS.sub(" ", str(value if value is not None else "")).strip()
    if len(text) > max_len:
        text = text[: max_len - 1].rstrip() + "…"
    return text or "-"


def build_template_payload(to: str, template: str, language: str, params: list) -> dict:
    payload: dict = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to,
        "type": "template",
        "template": {"name": template, "language": {"code": language}},
    }
    if params:
        payload["template"]["components"] = [
            {"type": "body", "parameters": [{"type": "text", "text": clean_param(p)} for p in params]}
        ]
    return payload


def _redact(text: str, secret: str = "") -> str:
    text = text or ""
    if secret:
        text = text.replace(secret, "[token]")
    return _WS.sub(" ", _LONG_DIGITS.sub("…", text)).strip()[:200]


def _http_error_message(exc: urllib.error.HTTPError, token: str) -> str:
    detail = ""
    try:
        data = json.loads(exc.read(65536).decode("utf-8"))
        err = data.get("error") if isinstance(data, dict) else None
        if isinstance(err, dict):
            code, message = err.get("code"), err.get("message") or ""
            extra = err.get("error_data")
            if not message and isinstance(extra, dict):
                message = extra.get("details") or ""
            detail = (f" · código {code}" if isinstance(code, int) else "") + (f": {message}" if message else "")
    except Exception:  # corpo ausente ou fora do padrão: fica só o código HTTP
        detail = ""
    return _redact(f"A API do WhatsApp recusou o envio (HTTP {exc.code}){detail}", token)


_TIMEOUT_TEXT = ("Tempo esgotado ao falar com a API do WhatsApp. A mensagem pode ter sido enviada: "
                 "confira com o cliente antes de repetir.")


def send_template(settings: WhatsAppSettings, *, to: str, template: str, params: list) -> SendResult:
    """Envia um modelo aprovado. Retorna SendResult só quando a API confirma com o identificador da mensagem."""
    if not settings.configured:
        raise WhatsAppError("Integração do WhatsApp não configurada.")
    if not _TEMPLATE_RE.match(template or ""):
        raise WhatsAppError("Nome do modelo de mensagem inválido (use minúsculas, números e _).")
    if not _LANG_RE.match(settings.language or ""):
        raise WhatsAppError("Idioma do modelo de mensagem inválido (ex.: pt_BR).")
    if not _TO_RE.match(to or ""):
        raise WhatsAppError("Número de destino inválido.")

    url = f"{GRAPH_BASE}/{settings.api_version}/{settings.phone_number_id}/messages"
    body = json.dumps(build_template_payload(to, template, settings.language, params), ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=body, method="POST", headers={
        "Authorization": f"Bearer {settings.access_token}",
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json",
    })
    try:
        with _urlopen(request, timeout=settings.timeout) as response:
            status = getattr(response, "status", 200)
            raw = response.read(65536)
    except urllib.error.HTTPError as exc:
        raise WhatsAppError(_http_error_message(exc, settings.access_token)) from None
    except (socket.timeout, TimeoutError):
        raise WhatsAppError(_TIMEOUT_TEXT) from None
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, (socket.timeout, TimeoutError)):
            raise WhatsAppError(_TIMEOUT_TEXT) from None
        raise WhatsAppError("Não foi possível conectar à API do WhatsApp.") from None
    except (OSError, http.client.HTTPException):
        raise WhatsAppError("Falha de rede ao falar com a API do WhatsApp.") from None

    if not 200 <= int(status) < 300:
        raise WhatsAppError(f"A API do WhatsApp respondeu com HTTP {int(status)}.")
    try:
        data = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        data = None
    message_id = None
    if isinstance(data, dict) and isinstance(data.get("messages"), list) and data["messages"]:
        first = data["messages"][0]
        candidate = first.get("id") if isinstance(first, dict) else None
        if isinstance(candidate, str) and _MESSAGE_ID_RE.match(candidate):
            message_id = candidate
    if not message_id:
        raise WhatsAppError("A API respondeu sem confirmar o envio (sem identificador da mensagem).")
    return SendResult(message_id=message_id)
