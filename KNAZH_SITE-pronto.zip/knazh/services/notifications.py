"""Avisos automáticos por WhatsApp (cliente e equipe) — SEMPRE depois de o pedido estar salvo.

Regras (veja também docs/WHATSAPP_API.md):
- As linhas de `order_notifications` nascem na MESMA transação do pedido, em estado "pendente"/"dispensado".
  O envio acontece depois do commit; qualquer falha aqui NUNCA desfaz nem esconde o pedido.
- Só vira "enviado" quando a API devolve o identificador da mensagem. Sem credenciais: "nao_configurado".
- Idempotência: cada tentativa "reserva" a notificação com um UPDATE condicional (status + tentativas).
  Dois processos/cliques não enviam a mesma mensagem duas vezes; "enviado" nunca é reenviado.
- Retentativas são limitadas (WHATSAPP_MAX_ATTEMPTS) e manuais (painel) ou por comando (`send-pending-notifications`).
- Logs só trazem número do pedido, destinatário e estado: nunca token, telefone ou conteúdo da mensagem.
"""
from __future__ import annotations

from datetime import timedelta

from flask import current_app
from sqlalchemy import and_, or_, select, update
from sqlalchemy.exc import SQLAlchemyError

from ..extensions import db
from ..models import Order, OrderNotification, utcnow
from . import whatsapp
from .channels import normalize_whatsapp
from .money import format_brl

SEND_ORDER = ("equipe", "cliente")                 # a equipe é avisada primeiro: é quem precisa agir
RETRYABLE = ("pendente", "falhou", "nao_configurado")
STALE_AFTER = timedelta(minutes=10)                # tentativa "enviando" travada (processo caiu) pode ser retomada


class _NotReady(Exception):
    def __init__(self, status: str, message: str):
        super().__init__(message)
        self.status, self.message = status, message


# ------------------------------------------------------------------ configuração
def get_settings() -> whatsapp.WhatsAppSettings:
    c = current_app.config
    return whatsapp.WhatsAppSettings(
        enabled=bool(c.get("WHATSAPP_API_ENABLED")),
        phone_number_id=(c.get("WHATSAPP_PHONE_NUMBER_ID") or "").strip(),
        access_token=(c.get("WHATSAPP_ACCESS_TOKEN") or "").strip(),
        api_version=(c.get("WHATSAPP_API_VERSION") or "").strip(),
        timeout=float(c.get("WHATSAPP_API_TIMEOUT") or 5),
        language=(c.get("WHATSAPP_TEMPLATE_LANGUAGE") or "pt_BR").strip(),
    )


def team_number() -> str | None:
    c = current_app.config
    return normalize_whatsapp(c.get("WHATSAPP_TEAM_NUMBER") or c.get("WHATSAPP_NUMBER"))


def max_attempts() -> int:
    return max(1, int(current_app.config.get("WHATSAPP_MAX_ATTEMPTS") or 5))


def integration_status() -> dict:
    """Resumo para o painel: configurada ou pendente (só nomes de variáveis, nunca valores)."""
    settings = get_settings()
    missing = settings.missing()
    if team_number() is None:
        missing.append("WHATSAPP_TEAM_NUMBER (ou WHATSAPP_NUMBER)")
    return {"configured": not missing, "missing": missing}


# ------------------------------------------------------------------ criação (dentro da transação do pedido)
def prepare_for_order(order: Order, *, customer_opt_in: bool) -> None:
    """Adiciona ao pedido (sem commit) as duas notificações. O cliente só recebe se autorizou no checkout."""
    now = utcnow()
    if customer_opt_in and normalize_whatsapp(order.customer_phone) is None:
        client = OrderNotification(recipient="cliente", status="falhou", consent_at=now,
                                   last_error="Telefone do cliente não é um número de WhatsApp válido.")
    elif customer_opt_in:
        client = OrderNotification(recipient="cliente", status="pendente", consent_at=now)
    else:
        client = OrderNotification(recipient="cliente", status="dispensado")
    team = OrderNotification(recipient="equipe", status="pendente")
    order.notifications.extend([team, client])


def prepare_cancellation(order: Order, *, reason: str) -> None:
    """Adiciona ao pedido (sem commit, na MESMA transação do cancelamento) o aviso de cancelamento ao cliente.
    Respeita o consentimento dado no checkout: sem autorização do cliente nada é enviado (o painel oferece abrir a
    conversa manualmente). Uma única linha por pedido (restrição única) = base da idempotência."""
    if order.notification_for("cancel") is not None:
        return
    consent = order.notification_for("cliente")
    consent_at = consent.consent_at if consent is not None else None
    if consent_at is None:
        n = OrderNotification(recipient="cancel", status="dispensado")
    elif normalize_whatsapp(order.customer_phone) is None:
        n = OrderNotification(recipient="cancel", status="falhou", consent_at=consent_at,
                              last_error="Telefone do cliente não é um número de WhatsApp válido.")
    else:
        n = OrderNotification(recipient="cancel", status="pendente", consent_at=consent_at)
    order.notifications.append(n)


def send_cancellation(order: Order) -> None:
    """Depois do commit do cancelamento. Nunca levanta erro: o pedido continua cancelado se o aviso falhar."""
    n = order.notification_for("cancel")
    if n is None:
        return
    try:
        attempt(n.id)
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Falha ao processar o aviso de cancelamento do pedido %s.", order.number)


# ------------------------------------------------------------------ conteúdo das mensagens (modelos aprovados)
def items_summary(order: Order, limit: int = 450) -> str:
    text = "; ".join(f"{i.quantity}x {i.product_name}" for i in order.items)
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def client_params(order: Order) -> list[str]:
    """{{1}} nome do cliente, {{2}} número do pedido."""
    return [order.customer_name, order.number]


def cancel_params(order: Order) -> list[str]:
    """{{1}} nome do cliente, {{2}} número do pedido, {{3}} motivo informado pela equipe, {{4}} data e hora (Brasília)."""
    event = order.cancellation
    when = (event.created_at + timedelta(hours=-3)).strftime("%d/%m/%Y %H:%M") if event else "-"
    return [order.customer_name, order.number, (event.reason if event else "") or "-", when]


def team_params(order: Order) -> list[str]:
    """{{1}} pedido, {{2}} cliente, {{3}} telefone, {{4}} itens, {{5}} total, {{6}} observações."""
    return [order.number, order.customer_name, order.customer_phone, items_summary(order),
            format_brl(order.total_cents), order.notes or "-"]


# ------------------------------------------------------------------ envio
def can_retry(n: OrderNotification) -> bool:
    if n.attempts >= max_attempts():
        return False
    if n.status in RETRYABLE:
        return True
    return n.status == "enviando" and n.last_attempt_at is not None and n.last_attempt_at < utcnow() - STALE_AFTER


def _prepare(n: OrderNotification, order: Order, settings: whatsapp.WhatsAppSettings) -> tuple[str, str, list[str]]:
    if not settings.configured:
        raise _NotReady("nao_configurado", "Integração do WhatsApp ainda não configurada (faltam: "
                        + ", ".join(settings.missing()) + ").")
    cfg = current_app.config
    if n.recipient == "equipe":
        to = team_number()
        if to is None:
            raise _NotReady("nao_configurado", "Número da equipe não configurado (WHATSAPP_TEAM_NUMBER ou WHATSAPP_NUMBER).")
        return to, cfg["WHATSAPP_TEMPLATE_TEAM"], team_params(order)
    to = normalize_whatsapp(order.customer_phone)
    if to is None:
        raise _NotReady("falhou", "Telefone do cliente não é um número de WhatsApp válido.")
    if n.recipient == "cancel":
        return to, cfg["WHATSAPP_TEMPLATE_CANCEL"], cancel_params(order)
    return to, cfg["WHATSAPP_TEMPLATE_CLIENT"], client_params(order)


def _commit(where: str) -> bool:
    try:
        db.session.commit()
        return True
    except SQLAlchemyError:
        db.session.rollback()
        current_app.logger.exception("Não foi possível gravar o estado da notificação (%s).", where)
        return False


def _claim(n: OrderNotification) -> bool:
    """Reserva a notificação para ESTA tentativa. Falso se outra tentativa já a pegou ou se já foi enviada."""
    now = utcnow()
    result = db.session.execute(
        update(OrderNotification)
        .where(OrderNotification.id == n.id,
               OrderNotification.attempts < max_attempts(),
               or_(OrderNotification.status.in_(RETRYABLE),
                   and_(OrderNotification.status == "enviando", OrderNotification.last_attempt_at < now - STALE_AFTER)))
        .values(status="enviando", attempts=OrderNotification.attempts + 1, last_attempt_at=now)
        .execution_options(synchronize_session=False)
    )
    claimed = result.rowcount == 1  # lido antes do commit
    saved = _commit("reserva")
    db.session.expire(n)
    return saved and claimed


def attempt(notification_id: int) -> OrderNotification:
    """Tenta enviar UMA notificação. Seguro para chamar várias vezes: "enviado" e "dispensado" nunca são reenviados."""
    n = db.session.get(OrderNotification, notification_id)
    if n is None:
        raise LookupError("notificação inexistente")
    if n.status in ("enviado", "dispensado"):
        return n
    order = n.order
    number, recipient = order.number, n.recipient
    try:
        to, template, params = _prepare(n, order, get_settings())
    except _NotReady as exc:
        n.status, n.last_error = exc.status, exc.message[:300]
        _commit("preparo")
        current_app.logger.info("WhatsApp %s do pedido %s: %s", recipient, number, n.status)
        return n
    if not _claim(n):
        return db.session.get(OrderNotification, notification_id)

    try:
        result = whatsapp.send_template(get_settings(), to=to, template=template, params=params)
    except whatsapp.WhatsAppError as exc:
        status, error, message_id = "falhou", exc.safe_message, None
    except Exception:  # nunca derruba o pedido nem vaza detalhe técnico
        current_app.logger.exception("Erro inesperado ao enviar o WhatsApp %s do pedido %s.", recipient, number)
        status, error, message_id = "falhou", "Erro inesperado ao enviar. Veja os registros do servidor.", None
    else:
        status, error, message_id = "enviado", None, result.message_id

    n = db.session.get(OrderNotification, notification_id)
    n.status, n.last_error, n.provider_message_id = status, error, message_id
    if status == "enviado":
        n.sent_at = utcnow()
    _commit("resultado")
    current_app.logger.info("WhatsApp %s do pedido %s: %s", recipient, number, status)
    return db.session.get(OrderNotification, notification_id)


def send_for_order(order: Order) -> None:
    """Chamado logo depois do commit do pedido. Nunca levanta erro: o pedido já está salvo."""
    ids = [n.id for n in sorted((x for x in order.notifications if x.recipient in SEND_ORDER),
                                key=lambda x: SEND_ORDER.index(x.recipient))]
    for notification_id in ids:
        try:
            attempt(notification_id)
        except Exception:
            db.session.rollback()
            current_app.logger.exception("Falha ao processar notificação %s.", notification_id)


def send_pending(limit: int = 20) -> dict:
    """Retenta avisos pendentes/falhos (comando `send-pending-notifications`). Respeita o limite de tentativas."""
    stmt = (select(OrderNotification.id)
            .where(OrderNotification.status.in_(RETRYABLE + ("enviando",)),
                   OrderNotification.attempts < max_attempts())
            .order_by(OrderNotification.id).limit(max(1, int(limit))))
    if not get_settings().configured:
        return {"processadas": 0, "enviadas": 0, "motivo": "integração não configurada"}
    done = sent = 0
    for notification_id in list(db.session.scalars(stmt)):
        n = db.session.get(OrderNotification, notification_id)
        if not can_retry(n):
            continue
        done += 1
        if attempt(notification_id).status == "enviado":
            sent += 1
    return {"processadas": done, "enviadas": sent, "motivo": ""}
