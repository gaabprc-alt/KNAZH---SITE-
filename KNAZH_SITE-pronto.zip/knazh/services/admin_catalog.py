"""Consultas e operações do painel administrativo de produtos (sempre validadas no servidor)."""
from __future__ import annotations

from dataclasses import dataclass

from flask import current_app
from sqlalchemy import delete, func, select, update
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from ..extensions import db
from ..models import Category, Favorite, OrderItem, Product
from .text import clean_label, normalize, slugify

STATUS_OPTIONS = [("todos", "Todos"), ("disponiveis", "Disponíveis"), ("indisponiveis", "Indisponíveis")]
_STATUS_KEYS = {k for k, _ in STATUS_OPTIONS}
MAX_QUERY_LENGTH = 80


@dataclass
class AdminFilters:
    q: str = ""
    category: int | None = None
    status: str = "todos"
    page: int = 1

    def as_params(self, **overrides) -> dict:
        data = {"q": self.q, "categoria": self.category, "status": self.status, "pagina": self.page}
        data.update(overrides)
        out = {}
        for key, value in data.items():
            if value in ("", None):
                continue
            if key == "status" and value == "todos":
                continue
            if key == "pagina" and value == 1:
                continue
            out[key] = value
        return out

    @property
    def active(self) -> bool:
        return bool(self.q or self.category or self.status != "todos")


def all_categories() -> list[Category]:
    return list(db.session.scalars(select(Category).order_by(Category.sort_order, Category.name)))


def parse_filters(args) -> AdminFilters:
    valid_ids = {c.id for c in all_categories()}
    q = (args.get("q") or "").strip()[:MAX_QUERY_LENGTH]
    try:
        category = int(args.get("categoria", ""))
    except (TypeError, ValueError):
        category = None
    if category not in valid_ids:
        category = None
    status = args.get("status", "todos")
    status = status if status in _STATUS_KEYS else "todos"
    try:
        page = max(1, min(int(args.get("pagina", 1)), 10_000))
    except (TypeError, ValueError):
        page = 1
    return AdminFilters(q=q, category=category, status=status, page=page)


def stats() -> dict[str, int]:
    total = db.session.scalar(select(func.count(Product.id))) or 0
    available = db.session.scalar(select(func.count(Product.id)).where(Product.is_available.is_(True))) or 0
    categories = db.session.scalar(select(func.count(Category.id)).where(Category.is_active.is_(True))) or 0
    return {"total": total, "available": available, "unavailable": total - available, "categories": categories}


def search_products(filters: AdminFilters):
    stmt = select(Product).join(Category)
    for term in normalize(filters.q).split():
        stmt = stmt.where(Product.search_text.contains(term, autoescape=True))
    if filters.category:
        stmt = stmt.where(Product.category_id == filters.category)
    if filters.status == "disponiveis":
        stmt = stmt.where(Product.is_available.is_(True))
    elif filters.status == "indisponiveis":
        stmt = stmt.where(Product.is_available.is_(False))
    stmt = stmt.order_by(func.lower(Product.name).asc(), Product.id.asc())
    return db.paginate(stmt, page=filters.page, per_page=current_app.config["ADMIN_PER_PAGE"], error_out=False)


def unique_slug(name: str) -> str:
    """Slug seguro e único a partir do nome (só para produtos novos; a edição preserva o slug atual)."""
    base = slugify(name)[:100].strip("-") or "produto"
    candidate, n = base, 2
    while db.session.scalar(select(Product.id).where(Product.slug == candidate)) is not None:
        candidate = f"{base}-{n}"
        n += 1
    return candidate


def form_categories(product: Product | None = None) -> list[Category]:
    """Categorias ativas; na edição, inclui também a categoria atual do produto mesmo se estiver inativa."""
    cats = [c for c in all_categories() if c.is_active or (product is not None and c.id == product.category_id)]
    return cats


CATEGORY_NAME_MIN = 2
CATEGORY_NAME_MAX = 60


class CategoryError(Exception):
    """Mensagem segura para exibir à pessoa administradora. `existing` traz a categoria já cadastrada, se for duplicata."""

    def __init__(self, message: str, existing: Category | None = None):
        super().__init__(message)
        self.existing = existing


def validate_category_name(raw: str | None) -> str:
    """Limpa e valida o nome de uma categoria nova (obrigatório, tamanho, ao menos uma letra ou número)."""
    name = clean_label(raw)
    if not name:
        raise CategoryError("Informe o nome da nova categoria.")
    if len(name) < CATEGORY_NAME_MIN:
        raise CategoryError(f"O nome da categoria deve ter pelo menos {CATEGORY_NAME_MIN} caracteres.")
    if len(name) > CATEGORY_NAME_MAX:
        raise CategoryError(f"O nome da categoria deve ter no máximo {CATEGORY_NAME_MAX} caracteres.")
    if not any(ch.isalnum() for ch in name):
        raise CategoryError("Use letras ou números no nome da categoria.")
    return name


def find_duplicate_category(name: str) -> Category | None:
    """Categoria já existente com o mesmo nome, ignorando maiúsculas, acentos e espaços extras (inclui inativas)."""
    wanted, wanted_slug = normalize(name), slugify(name)
    for category in all_categories():
        if normalize(category.name) == wanted or category.slug == wanted_slug:
            return category
    return None


def _unique_category_slug(name: str) -> str:
    base = slugify(name)[:70].strip("-") or "categoria"
    candidate, n = base, 2
    while db.session.scalar(select(Category.id).where(Category.slug == candidate)) is not None:
        candidate = f"{base}-{n}"
        n += 1
    return candidate


def build_category(raw_name: str | None) -> Category:
    """Valida e adiciona a categoria à sessão (flush, SEM commit): quem chama decide quando confirmar a transação.

    Lança CategoryError para nome inválido ou duplicado. Nunca altera categorias existentes."""
    name = validate_category_name(raw_name)
    duplicate = find_duplicate_category(name)
    if duplicate is not None:
        raise CategoryError(f"Já existe a categoria “{duplicate.name}”. Escolha-a na lista.", existing=duplicate)
    last = db.session.scalar(select(func.max(Category.sort_order)))
    category = Category(slug=_unique_category_slug(name), name=name, description="", icon="package",
                        sort_order=(last or 0) + 1, is_active=True)
    db.session.add(category)
    db.session.flush()
    return category


def create_category(raw_name: str | None) -> Category:
    """Cria e confirma a categoria. Em corrida (duas pessoas criando a mesma ao mesmo tempo) devolve CategoryError."""
    category = build_category(raw_name)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        duplicate = find_duplicate_category(clean_label(raw_name))
        raise CategoryError("Essa categoria acabou de ser criada. Atualize a lista e escolha-a.", existing=duplicate) from None
    except SQLAlchemyError:
        db.session.rollback()
        raise
    return category


def delete_product(product: Product) -> None:
    """Exclui o produto preservando o histórico.

    - Itens de pedido guardam snapshot (nome, preço, totais): só o vínculo product_id é anulado; nada é recalculado.
    - Favoritos do produto são removidos (não têm valor sem o produto).
    O SQLite não aplica ON DELETE por padrão, então os dois passos são feitos explicitamente, na mesma transação.
    Em caso de erro faz rollback e relança SQLAlchemyError para a rota mostrar uma mensagem segura.
    """
    pid = product.id
    try:
        db.session.execute(update(OrderItem).where(OrderItem.product_id == pid).values(product_id=None))
        db.session.execute(delete(Favorite).where(Favorite.product_id == pid))
        db.session.delete(product)
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        raise


# ------------------------------------------------------------------ gestão completa de categorias (painel)
CATEGORY_ICONS = [("package", "Caixa"), ("brownie", "Brownie"), ("brigadeiro", "Brigadeiro"), ("bolo", "Bolo"),
                  ("sobremesa", "Sobremesa"), ("outros", "Reticências"), ("list", "Lista"), ("star", "Estrela"),
                  ("heart", "Coração"), ("leaf", "Folha"), ("tag", "Etiqueta"), ("bag", "Sacola")]
_ICON_KEYS = {k for k, _ in CATEGORY_ICONS}
CATEGORY_DESCRIPTION_MAX = 300
CATEGORY_ORDER_MAX = 9999


def product_counts() -> dict[int, int]:
    rows = db.session.execute(select(Product.category_id, func.count(Product.id)).group_by(Product.category_id))
    return {cid: n for cid, n in rows}


def parse_category_form(form, current: Category | None = None) -> dict:
    """Valida os campos no servidor (nome, descrição, ícone, ordem, ativa). Lança CategoryError com mensagem segura."""
    name = validate_category_name(form.get("name"))
    duplicate = find_duplicate_category(name)
    if duplicate is not None and (current is None or duplicate.id != current.id):
        raise CategoryError(f"Já existe a categoria “{duplicate.name}”.", existing=duplicate)
    description = " ".join((form.get("description") or "").split())
    if len(description) > CATEGORY_DESCRIPTION_MAX:
        raise CategoryError(f"A descrição pode ter no máximo {CATEGORY_DESCRIPTION_MAX} caracteres.")
    icon = (form.get("icon") or "").strip()
    if icon not in _ICON_KEYS:
        raise CategoryError("Escolha um ícone da lista.")
    raw_order = (form.get("sort_order") or "").strip()
    try:
        order = int(raw_order) if raw_order else (current.sort_order if current else 0)
    except ValueError:
        raise CategoryError("A ordem de exibição deve ser um número inteiro.") from None
    if not 0 <= order <= CATEGORY_ORDER_MAX:
        raise CategoryError(f"A ordem de exibição deve estar entre 0 e {CATEGORY_ORDER_MAX}.")
    return {"name": name, "description": description, "icon": icon, "sort_order": order,
            "is_active": form.get("is_active") == "on"}


def save_category(fields: dict, current: Category | None = None) -> Category:
    """Cria ou atualiza. O endereço (slug) NÃO muda ao renomear, para não quebrar links já divulgados."""
    category = current or Category(slug=_unique_category_slug(fields["name"]))
    for key, value in fields.items():
        setattr(category, key, value)
    try:
        if current is None:
            db.session.add(category)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise CategoryError("Essa categoria acabou de ser criada ou alterada por outra pessoa. Atualize a lista.") from None
    except SQLAlchemyError:
        db.session.rollback()
        raise
    return category


def delete_category(category: Category) -> None:
    """Só exclui categoria SEM produtos. Nunca apaga produtos em cascata: o administrador reatribui antes."""
    n = db.session.scalar(select(func.count(Product.id)).where(Product.category_id == category.id)) or 0
    if n:
        raise CategoryError(f"A categoria “{category.name}” tem {n} produto(s). Mude esses produtos para outra "
                            "categoria antes de excluí-la (ou desative a categoria).")
    try:
        db.session.delete(category)
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        raise
