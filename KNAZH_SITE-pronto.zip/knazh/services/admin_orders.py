"""Consultas e operações do painel administrativo de PEDIDOS (sempre validadas no servidor)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from flask import current_app
from sqlalchemy import func, select, update
from sqlalchemy.orm import selectinload

from ..extensions import db
from ..models import ORDER_STATUS_LABELS, Order, OrderNotification, OrderStatusEvent

STATUS_FILTERS = [("todos", "Todos")] + list(ORDER_STATUS_LABELS.items())
_STATUS_KEYS = {k for k, _ in STATUS_FILTERS}
MAX_QUERY_LENGTH = 80
BRASILIA = timedelta(hours=-3)  # horário de Brasília (sem horário de verão desde 2019); o banco guarda UTC


class OrderStatusError(Exception):
    """Mensagem segura para exibir à equipe."""


def to_brasilia(value: datetime | None) -> datetime | None:
    return value + BRASILIA if value is not None else None


@dataclass
class OrderFilters:
    q: str = ""
    status: str = "todos"
    page: int = 1

    def as_params(self, **overrides) -> dict:
        data = {"q": self.q, "status": self.status, "pagina": self.page}
        data.update(overrides)
        out = {}
        for key, value in data.items():
            if value in ("", None):
                continue
            if key == "status" and value == "todos":
                continue
            if key == "pagina" and value == 1:
                continue
            out[key] = value
        return out

    @property
    def active(self) -> bool:
        return bool(self.q or self.status != "todos")


def parse_filters(args) -> OrderFilters:
    q = (args.get("q") or "").strip()[:MAX_QUERY_LENGTH]
    status = args.get("status", "todos")
    status = status if status in _STATUS_KEYS else "todos"
    try:
        page = max(1, min(int(args.get("pagina", 1)), 10_000))
    except (TypeError, ValueError):
        page = 1
    return OrderFilters(q=q, status=status, page=page)


def search_orders(filters: OrderFilters):
    stmt = select(Order).options(selectinload(Order.notifications), selectinload(Order.items))
    term = filters.q.lower()
    if term:
        stmt = stmt.where(func.lower(Order.number).contains(term, autoescape=True)
                          | func.lower(Order.customer_name).contains(term, autoescape=True))
    if filters.status != "todos":
        stmt = stmt.where(Order.status == filters.status)
    stmt = stmt.order_by(Order.id.desc())
    return db.paginate(stmt, page=filters.page, per_page=current_app.config["ADMIN_PER_PAGE"], error_out=False)


def stats() -> dict[str, int]:
    total = db.session.scalar(select(func.count(Order.id))) or 0
    pending = db.session.scalar(select(func.count(Order.id)).where(Order.status == "pendente")) or 0
    attention = db.session.scalar(
        select(func.count(func.distinct(OrderNotification.order_id)))
        .where(OrderNotification.status.in_(("falhou", "nao_configurado")))) or 0
    return {"total": total, "pending": pending, "attention": attention}


# Transições permitidas (validadas no servidor). "Concluído" e "Cancelado" são finais: um pedido encerrado não é reaberto
# pelo painel (evita cancelar algo já entregue e mantém o histórico coerente).
ALLOWED_TRANSITIONS = {
    "pendente": ("confirmado", "concluido", "cancelado"),
    "confirmado": ("concluido", "cancelado"),
    "concluido": (),
    "cancelado": (),
}
REASON_MIN, REASON_MAX = 3, 300  # caracteres do motivo do cancelamento (o aviso ao cliente leva este texto)


def allowed_next(status: str) -> tuple[str, ...]:
    return ALLOWED_TRANSITIONS.get(status, ())


def clean_reason(raw: str | None) -> str:
    """Motivo em uma linha só, sem espaços sobrando e sem caracteres de controle. Levanta OrderStatusError se inválido."""
    text = " ".join("".join(ch if ch.isprintable() or ch.isspace() else " " for ch in (raw or "")).split())
    if len(text) < REASON_MIN:
        raise OrderStatusError("Informe o motivo do cancelamento (pelo menos 3 caracteres): o cliente receberá este texto.")
    if len(text) > REASON_MAX:
        raise OrderStatusError(f"O motivo do cancelamento pode ter no máximo {REASON_MAX} caracteres (agora tem {len(text)}).")
    return text


def validate_cancellation(order: Order, reason: str | None) -> str:
    """Confere (sem gravar nada) se o pedido pode ser cancelado agora e devolve o motivo já limpo."""
    if "cancelado" not in allowed_next(order.status):
        raise OrderStatusError(f"Um pedido “{order.status_label}” não pode ser cancelado.")
    return clean_reason(reason)


def set_status(order: Order, status: str | None, *, reason: str | None = None, admin=None) -> bool:
    """Atualiza o estado do pedido e grava o histórico NA MESMA transação. Devolve False se já estava nesse estado
    (ou se outra requisição acabou de mudá-lo: o UPDATE é condicional ao estado anterior, então um clique repetido
    não registra duas vezes). Cancelar exige motivo; as demais mudanças ignoram o campo."""
    if status not in ORDER_STATUS_LABELS:
        raise OrderStatusError("Escolha um estado de pedido válido.")
    if order.status == status:
        return False
    previous = order.status
    if status not in allowed_next(previous):
        raise OrderStatusError(f"Não é possível mudar de “{ORDER_STATUS_LABELS.get(previous, previous)}” para "
                               f"“{ORDER_STATUS_LABELS[status]}”.")
    cancel_reason = clean_reason(reason) if status == "cancelado" else None
    order_id = order.id
    try:
        moved = db.session.execute(
            update(Order).where(Order.id == order_id, Order.status == previous).values(status=status)
            .execution_options(synchronize_session=False)).rowcount == 1
        if not moved:
            db.session.rollback()
            return False
        db.session.add(OrderStatusEvent(order_id=order_id, from_status=previous, to_status=status, reason=cancel_reason,
                                        admin_id=getattr(admin, "id", None),
                                        admin_name=(getattr(admin, "name", "") or "")[:120]))
        if status == "cancelado":
            from . import notifications as notifications_service  # evita import circular
            notifications_service.prepare_cancellation(order, reason=cancel_reason)
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise
    db.session.refresh(order)
    return True


def counts_by_status() -> dict[str, int]:
    """Quantidade de pedidos em cada estado (todos os estados aparecem, mesmo com zero)."""
    rows = dict(db.session.execute(select(Order.status, func.count(Order.id)).group_by(Order.status)).all())
    return {key: int(rows.get(key, 0)) for key in ORDER_STATUS_LABELS}


def recent(limit: int = 5) -> list[Order]:
    return list(db.session.scalars(select(Order).order_by(Order.id.desc()).limit(limit)))
