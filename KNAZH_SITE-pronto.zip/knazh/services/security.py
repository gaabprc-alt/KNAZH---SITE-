from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from flask import current_app, has_app_context
from sqlalchemy.exc import SQLAlchemyError


def safe_next_url(target: str | None, default: str = "/") -> str:
    """Só aceita caminhos relativos do próprio site (evita open redirect)."""
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return default
    parsed = urlparse(target)
    if parsed.scheme or parsed.netloc:
        return default
    return target


class Throttle:
    """Limitador por escopo, guardado no BANCO (vale para todos os workers/processos). N tentativas numa janela de tempo.

    A chave é gravada como hash. Se o banco falhar, o limitador "abre" (não derruba login/contato) e registra o erro."""

    def __init__(self, scope: str, limit: int = 5, window_seconds: int = 600):
        self.scope, self.limit, self.window = scope, limit, window_seconds

    def _hash(self, key: str) -> str:
        return hashlib.sha256(f"{self.scope}|{key}".encode("utf-8")).hexdigest()

    def _since(self) -> datetime:
        return datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(seconds=self.window)

    def blocked(self, key: str) -> bool:
        from ..extensions import db
        from ..models import RateLimitHit
        try:
            count = db.session.scalar(db.select(db.func.count(RateLimitHit.id))
                                      .where(RateLimitHit.key == self._hash(key), RateLimitHit.created_at >= self._since()))
        except SQLAlchemyError:
            db.session.rollback()
            current_app.logger.exception("Limitador indisponível (escopo %s).", self.scope)
            return False
        return (count or 0) >= self.limit

    def hit(self, key: str) -> None:
        from ..extensions import db
        from ..models import RateLimitHit
        try:
            db.session.execute(db.delete(RateLimitHit).where(RateLimitHit.created_at < self._since() - timedelta(hours=1)))
            db.session.add(RateLimitHit(key=self._hash(key)))
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            current_app.logger.exception("Não foi possível registrar a tentativa (escopo %s).", self.scope)

    def reset(self, key: str | None = None) -> None:
        from ..extensions import db
        from ..models import RateLimitHit
        if not has_app_context():
            return
        try:
            stmt = db.delete(RateLimitHit)
            if key is not None:
                stmt = stmt.where(RateLimitHit.key == self._hash(key))
            db.session.execute(stmt)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()


login_throttle = Throttle("login", limit=5, window_seconds=600)
register_throttle = Throttle("register", limit=10, window_seconds=3600)   # por IP
verification_throttle = Throttle("email-verification", limit=5, window_seconds=3600)         # por e-mail (evita spam a uma caixa)
verification_ip_throttle = Throttle("email-verification-ip", limit=15, window_seconds=3600)  # por IP (evita varrer vários e-mails)
contact_throttle = Throttle("contact", limit=5, window_seconds=600)       # por IP
