"""Tokens aleatórios e opacos para confirmar endereços de e-mail, e checagem do endereço público (SITE_URL)."""
from __future__ import annotations

import hashlib
import secrets
from urllib.parse import urlparse

_TOKEN_CHARS = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")


def make_token() -> str:
    """43 caracteres, 256 bits de entropia. Vai só no link do e-mail; no banco fica apenas o hash."""
    return secrets.token_urlsafe(32)


def token_hash(token: str) -> str | None:
    """SHA-256 do token, ou None se o texto não parece um token (tamanho/caracteres inválidos)."""
    if not token or len(token) > 128 or any(char not in _TOKEN_CHARS for char in token):
        return None
    return hashlib.sha256(token.encode("ascii")).hexdigest()


def site_url_problem(site_url: str, *, production: bool) -> str | None:
    """Descreve por que SITE_URL não serve para montar links de e-mail (ou None se está adequado)."""
    if not site_url:
        return "SITE_URL está vazio: os links dos e-mails usarão o endereço da requisição, que pode ser interno."
    parsed = urlparse(site_url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in ("http", "https") or not host:
        return "SITE_URL não é um endereço válido (use algo como https://seu-dominio.com.br)."
    if host in ("localhost", "0.0.0.0", "::1") or host.startswith("127.") or host.endswith(".local"):
        return "SITE_URL aponta para um endereço local: quem receber o e-mail não conseguirá abrir o link." if production else None
    if production and parsed.scheme != "https":
        return "SITE_URL deveria começar com https:// em produção."
    return None
