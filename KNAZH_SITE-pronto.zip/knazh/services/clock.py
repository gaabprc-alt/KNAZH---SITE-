"""Data/hora local da loja (America/Sao_Paulo), calculada no servidor a cada renderização."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
    try:
        STORE_TZ = ZoneInfo("America/Sao_Paulo")
    except ZoneInfoNotFoundError:  # sistema sem base de fusos (ex.: Windows sem o pacote tzdata)
        STORE_TZ = timezone(timedelta(hours=-3))  # o Brasil não tem horário de verão desde 2019
except ImportError:  # pragma: no cover
    STORE_TZ = timezone(timedelta(hours=-3))


def _utc_now() -> datetime:
    """Ponto único de relógio: os testes o substituem para simular a virada do ano."""
    return datetime.now(timezone.utc)


def store_now() -> datetime:
    return _utc_now().astimezone(STORE_TZ)


def current_year() -> int:
    return store_now().year
