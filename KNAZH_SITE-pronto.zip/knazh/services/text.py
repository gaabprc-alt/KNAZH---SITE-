"""Normalização de texto para busca (sem acentos, minúsculas, espaços colapsados)."""
from __future__ import annotations

import re
import unicodedata

_WS = re.compile(r"\s+")


def normalize(value: str | None) -> str:
    if not value:
        return ""
    decomposed = unicodedata.normalize("NFKD", value)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return _WS.sub(" ", stripped.lower()).strip()


def slugify(value: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", normalize(value)).strip("-")
    return base or "item"


_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_label(value: str | None) -> str:
    """Nome curto digitado por uma pessoa: sem caracteres de controle, espaços colapsados e sem sobras nas pontas."""
    if not value:
        return ""
    return _WS.sub(" ", _CONTROL.sub("", value)).strip()
