"""Migrações explícitas e idempotentes do banco (sem Alembic).

`db.create_all()` só cria tabelas ausentes: ele NÃO adiciona colunas novas a tabelas que já existem.
Por isso cada alteração de esquema em bancos já em uso entra aqui, usando introspecção para checar o estado
atual antes de alterar. Rodar mais de uma vez é seguro: o que já existe é ignorado e nenhum dado é apagado.

Uso: flask --app wsgi migrate-db   (faça backup do banco antes — veja o README).
"""
from __future__ import annotations

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine


def _columns(engine: Engine, table: str) -> set[str] | None:
    insp = inspect(engine)
    if table not in insp.get_table_names():
        return None
    return {c["name"] for c in insp.get_columns(table)}


def add_customer_is_admin(engine: Engine) -> str:
    """Adiciona customers.is_admin (BOOLEAN NOT NULL DEFAULT false). Contas existentes ficam como clientes comuns.

    Retorna 'adicionada', 'ja-existe' ou 'sem-tabela' (tabela ainda inexistente: create_all a criará já com a coluna).
    """
    cols = _columns(engine, "customers")
    if cols is None:
        return "sem-tabela"
    if "is_admin" in cols:
        return "ja-existe"
    default = "0" if engine.dialect.name == "sqlite" else "FALSE"
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE customers ADD COLUMN is_admin BOOLEAN NOT NULL DEFAULT {default}"))
    return "adicionada"


def add_customer_can_manage_admins(engine: Engine) -> str:
    """Adiciona customers.can_manage_admins (BOOLEAN NOT NULL DEFAULT false).

    Contas existentes ficam sem a permissão. Para não deixar um banco antigo sem NINGUÉM capaz de gerenciar
    administradores, se já houver administradores e nenhum gestor, TODOS os administradores atuais passam a gestores
    (comportamento anterior: qualquer administrador era de confiança total). Depois disso o painel permite ajustar.
    """
    cols = _columns(engine, "customers")
    if cols is None:
        return "sem-tabela"
    if "can_manage_admins" in cols:
        return "ja-existe"
    default = "0" if engine.dialect.name == "sqlite" else "FALSE"
    true = "1" if engine.dialect.name == "sqlite" else "TRUE"
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE customers ADD COLUMN can_manage_admins BOOLEAN NOT NULL DEFAULT {default}"))
        if "is_admin" in cols:
            conn.execute(text(f"UPDATE customers SET can_manage_admins = {true} WHERE is_admin = {true}"))
    return "adicionada"


def create_order_status_events(engine: Engine) -> str:
    """Cria a tabela order_status_events (histórico de estados/cancelamentos). Só cria se ainda não existir."""
    from .models import OrderStatusEvent

    if _columns(engine, "orders") is None:
        return "sem-tabela"  # create_all criará as duas tabelas juntas
    if _columns(engine, "order_status_events") is not None:
        return "ja-existe"
    OrderStatusEvent.__table__.create(engine, checkfirst=True)
    return "criada"


def create_rate_limit_hits(engine: Engine) -> str:
    """Cria a tabela rate_limit_hits (limitador compartilhado entre processos) se ainda não existir."""
    from .models import RateLimitHit

    if _columns(engine, "rate_limit_hits") is not None:
        return "ja-existe"
    RateLimitHit.__table__.create(engine, checkfirst=True)
    return "criada"



def add_customer_email_verification(engine: Engine) -> str:
    """Adiciona campos de verificação. Contas existentes ficam verificadas para manter o acesso."""
    cols = _columns(engine, "customers")
    if cols is None:
        return "sem-tabela"
    required = {
        "email_verified",
        "email_verified_at",
        "email_verification_token_hash",
        "email_verification_expires_at",
    }
    already_applied = required <= cols
    true = "1" if engine.dialect.name == "sqlite" else "TRUE"
    if not already_applied:
        with engine.begin() as conn:
            if "email_verified" not in cols:
                conn.execute(text(f"ALTER TABLE customers ADD COLUMN email_verified BOOLEAN NOT NULL DEFAULT {true}"))
            if "email_verified_at" not in cols:
                conn.execute(text("ALTER TABLE customers ADD COLUMN email_verified_at DATETIME NULL"))
            if "email_verification_token_hash" not in cols:
                conn.execute(text("ALTER TABLE customers ADD COLUMN email_verification_token_hash VARCHAR(64) NULL"))
            if "email_verification_expires_at" not in cols:
                conn.execute(text("ALTER TABLE customers ADD COLUMN email_verification_expires_at DATETIME NULL"))
    from .models import Customer

    token_index = next(
        index for index in Customer.__table__.indexes
        if index.name == "ix_customers_email_verification_token_hash"
    )
    token_index.create(engine, checkfirst=True)
    return "ja-existe" if already_applied else "adicionada"

# Ordem importa: novas migrações entram no fim da lista.
MIGRATIONS = [
    ("customers.is_admin", add_customer_is_admin),
    ("customers.can_manage_admins", add_customer_can_manage_admins),
    ("order_status_events", create_order_status_events),
    ("rate_limit_hits", create_rate_limit_hits),
    ("customers.email_verification", add_customer_email_verification),
]


def run_migrations(engine: Engine) -> list[tuple[str, str]]:
    """Executa todas as migrações pendentes. Retorna [(nome, resultado)]."""
    return [(name, fn(engine)) for name, fn in MIGRATIONS]
