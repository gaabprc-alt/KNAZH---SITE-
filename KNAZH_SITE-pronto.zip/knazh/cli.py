"""Comandos de linha: flask --app wsgi <comando>."""
from __future__ import annotations

import os
import sys
from types import SimpleNamespace

import click
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from wtforms.validators import ValidationError

from .demo_data import remove_demo, seed_demo
from .extensions import db
from .forms import EMAIL_RE, password_check
from .migrations import run_migrations
from .models import ContactMessage, Customer, Order, utcnow
from .services import admin_users
from .services import notifications as notifications_service


def register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """Cria as tabelas que ainda não existem (não apaga dados)."""
        db.create_all()
        click.echo("Banco inicializado.")

    @app.cli.command("migrate-db")
    def migrate_db():
        """Atualiza o esquema de um banco existente (idempotente, não apaga dados). Faça backup antes."""
        for name, result in run_migrations(db.engine):
            label = {"adicionada": "coluna adicionada", "ja-existe": "já estava aplicada",
                     "sem-tabela": "tabela ainda não existe (será criada pelo init-db)"}.get(result, result)
            click.echo(f"  {name}: {label}")
        db.create_all()  # tabelas novas, se houver; nunca altera nem apaga as existentes
        click.echo("Migração concluída.")

    def _find_customer(email: str) -> Customer:
        normalized = (email or "").strip().lower()
        customer = db.session.scalar(select(Customer).where(Customer.email == normalized)) if normalized else None
        if customer is None:
            raise click.ClickException(f"Nenhuma conta encontrada com o e-mail «{normalized}». "
                                       "A pessoa precisa criar a conta no site antes de ser promovida.")
        return customer

    @app.cli.command("promote-admin")
    @click.argument("email")
    @click.option("--manager", is_flag=True, help="Também concede a permissão de gerenciar administradores (use para recuperar o acesso).")
    def promote_admin(email, manager):
        """Concede acesso de administrador a uma conta JÁ EXISTENTE (somente por linha de comando)."""
        customer = _find_customer(email)
        if customer.is_admin and (customer.can_manage_admins or not manager):
            click.echo(f"{customer.email} já é administradora{' e gerencia administradores' if customer.can_manage_admins else ''}. Nada a fazer.")
            return
        customer.is_admin = True
        customer.can_manage_admins = bool(manager) or customer.can_manage_admins
        db.session.commit()
        extra = " e pode gerenciar administradores" if customer.can_manage_admins else ""
        click.echo(f"Pronto: {customer.email} agora é administradora{extra}.")
        if app.config["EMAIL_VERIFICATION_REQUIRED"] and not customer.email_verified:
            click.echo("Aviso: essa conta ainda não confirmou o e-mail e não conseguirá entrar até clicar no link de confirmação "
                       "(a pessoa pode pedir um novo na tela de login).")

    @app.cli.command("revoke-admin")
    @click.argument("email")
    def revoke_admin(email):
        """Remove o acesso de administrador de uma conta (ela continua como cliente comum).

        Recusa remover a ÚLTIMA conta que gerencia administradores (use `promote-admin EMAIL --manager` em outra conta antes)."""
        customer = _find_customer(email)
        if not customer.is_admin:
            click.echo(f"{customer.email} não é administradora. Nada a fazer.")
            return
        if customer.can_manage_admins and admin_users.manager_count() <= 1:
            raise click.ClickException(f"{customer.email} é a única conta que gerencia administradores e não pode ser removida. "
                                       "Conceda antes a permissão a outra conta: promote-admin EMAIL --manager")
        customer.is_admin = False
        customer.can_manage_admins = False
        db.session.commit()
        click.echo(f"Pronto: {customer.email} não é mais administradora.")

    @app.cli.command("provision-initial-admin")
    @click.option("--email", default=None, help="E-mail do administrador inicial (padrão: INITIAL_ADMIN_EMAIL).")
    @click.option("--name", envvar="INITIAL_ADMIN_NAME", default="Administração KNAZH", show_default=True)
    @click.option("--yes", is_flag=True, help="Não pedir confirmação ao promover uma conta que já existe.")
    def provision_initial_admin(email, name, yes):
        """Cria/promove o administrador inicial (com permissão de gerenciar administradores). Idempotente e seguro.

        A senha NUNCA vai em argumento nem no código: use a variável de ambiente INITIAL_ADMIN_PASSWORD (ou digite no
        prompt, oculto, se estiver num terminal). Se a conta já existe, a senha e os dados dela NÃO são alterados."""
        email = (email or app.config["INITIAL_ADMIN_EMAIL"] or "").strip().lower()
        if not email or not EMAIL_RE.match(email):
            raise click.ClickException("Informe um e-mail válido (--email ou INITIAL_ADMIN_EMAIL).")
        customer = db.session.scalar(select(Customer).where(Customer.email == email))
        if customer is not None:
            if customer.is_admin and customer.can_manage_admins:
                click.echo(f"{email}: a conta já existe e já gerencia administradores. Nada a fazer (a senha não foi tocada).")
                return
            click.echo(f"{email}: a conta já existe (criada em {customer.created_at:%d/%m/%Y}, nome «{customer.name}»). "
                       "A senha atual será mantida.")
            if not yes and not click.confirm("Esta conta é mesmo da pessoa responsável pela loja? Promover a administradora com gestão de administradores?"):
                raise click.Abort()
            customer.is_admin = True
            customer.can_manage_admins = True
            db.session.commit()
            click.echo(f"Pronto: {email} agora é administradora e gerencia administradores.")
            return
        password = os.environ.get("INITIAL_ADMIN_PASSWORD", "")
        if not password:
            if not sys.stdin.isatty():
                raise click.ClickException("Defina INITIAL_ADMIN_PASSWORD no ambiente (não vai para o código) ou rode num terminal para digitá-la.")
            password = click.prompt("Senha do administrador inicial", hide_input=True, confirmation_prompt=True)
        try:
            password_check(None, SimpleNamespace(data=password))
        except ValidationError as exc:
            raise click.ClickException(f"Senha recusada: {exc}")
        customer = Customer(name=name.strip() or "Administração KNAZH", email=email, phone="", is_admin=True, can_manage_admins=True,
                            email_verified=True, email_verified_at=utcnow())  # criada de propósito por quem controla o servidor
        customer.set_password(password)
        db.session.add(customer)
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            raise click.ClickException("A conta foi criada por outro processo agora há pouco. Rode o comando de novo para conferir a situação.")
        click.echo(f"Pronto: conta criada para {email} como administradora (gerencia administradores). "
                   "Remova INITIAL_ADMIN_PASSWORD do ambiente e troque a senha se ela foi compartilhada.")

    @app.cli.command("backup-db")
    @click.option("--dir", "directory", type=click.Path(file_okay=False), default=None,
                  help="Pasta de destino (padrão: instance/backups). Use um local FORA de pastas servidas pelo site.")
    @click.option("--keep", default=14, show_default=True, help="Quantas cópias recentes manter nessa pasta.")
    def backup_db(directory, keep):
        """Cópia CONSISTENTE do banco SQLite (API de backup do SQLite, segura com o site em uso) + verificação de integridade.

        Não criptografa: proteja a pasta de destino e, ao enviar para fora do servidor, cifre o arquivo
        (ex.: `age`/`gpg`) com chave guardada separadamente. Para restaurar, veja o README."""
        import sqlite3
        from datetime import datetime, timezone
        from pathlib import Path

        uri = app.config["SQLALCHEMY_DATABASE_URI"]
        if not uri.startswith("sqlite:///") or uri.endswith(":memory:"):
            raise click.ClickException("Este comando faz backup apenas de SQLite em arquivo. Para outros bancos use a ferramenta do próprio banco (pg_dump etc.).")
        source = Path(uri.removeprefix("sqlite:///"))
        if not source.exists():
            raise click.ClickException(f"Banco não encontrado em {source}.")
        target_dir = Path(directory) if directory else source.parent / "backups"
        target_dir.mkdir(parents=True, exist_ok=True)
        try:
            target_dir.chmod(0o700)
        except OSError:
            pass
        target = target_dir / f"knazh-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}.db"
        src, dst = sqlite3.connect(f"file:{source}?mode=ro", uri=True), sqlite3.connect(target)
        try:
            src.backup(dst)
            check = dst.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            dst.close(); src.close()
        if check != "ok":
            target.unlink(missing_ok=True)
            raise click.ClickException(f"A cópia falhou na verificação de integridade ({check}) e foi descartada.")
        try:
            target.chmod(0o600)
        except OSError:
            pass
        old = sorted(target_dir.glob("knazh-*.db"))[:-max(1, keep)]
        for f in old:
            f.unlink(missing_ok=True)
        click.echo(f"Backup verificado (integrity_check ok): {target} ({target.stat().st_size} bytes). Removidas {len(old)} cópia(s) antigas.")

    @app.cli.command("check-email-config")
    def check_email_config():
        """Mostra se o e-mail está configurado (SMTP, confirmação de cadastro, SITE_URL) SEM exibir senhas."""
        from .services.mailer import email_config_report

        rows, warnings = email_config_report()
        for label, value in rows:
            click.echo(f"{label}: {value}")
        for warning in warnings:
            click.echo(f"AVISO: {warning}")
        click.echo("Para testar o envio de verdade: flask --app wsgi test-email SEU_EMAIL@exemplo.com")

    @app.cli.command("test-email")
    @click.argument("recipient")
    def test_email(recipient):
        """Envia UM e-mail de teste ao destinatário usando o SMTP atual (não cria usuário nem usa token)."""
        from .services.mailer import send_test_email

        recipient = recipient.strip()
        if not EMAIL_RE.match(recipient):
            raise click.ClickException("Informe um endereço de e-mail válido como destinatário.")
        status, hint = send_test_email(recipient)
        if status == "enviado":
            click.echo("E-mail de teste enviado. Confira a caixa de entrada (e o Spam) de " + recipient + ".")
            return
        if status == "nao_configurado":
            raise click.ClickException("SMTP não configurado. " + hint + " Rode `flask --app wsgi check-email-config`.")
        raise click.ClickException("Não foi possível enviar. " + hint + " (Detalhes técnicos no log do servidor; nenhuma senha é exibida.)")

    @app.cli.command("seed-demo")
    def seed_demo_cmd():
        """Carrega/atualiza o catálogo de DEMONSTRAÇÃO (preços fictícios)."""
        db.create_all()
        r = seed_demo()
        click.echo(f"Dados de demonstração: {r['criados']} criados, {r['atualizados']} atualizados.")

    @app.cli.command("remove-demo")
    def remove_demo_cmd():
        """Remove somente os produtos marcados como demonstração."""
        click.echo(f"{remove_demo()} produtos de demonstração removidos.")

    @app.cli.command("list-orders")
    @click.option("--limit", default=20)
    def list_orders(limit):
        """Lista os pedidos mais recentes."""
        for o in db.session.scalars(select(Order).order_by(Order.id.desc()).limit(limit)):
            click.echo(f"{o.number}  {o.created_at:%d/%m/%Y %H:%M}  {o.status_label:<22} {o.customer_name}  {o.total_cents/100:.2f}")

    @app.cli.command("send-pending-notifications")
    @click.option("--limit", default=20, show_default=True, help="Máximo de avisos a processar nesta execução.")
    def send_pending_notifications(limit):
        """Tenta de novo os avisos de WhatsApp pendentes ou que falharam (respeita o limite de tentativas).

        Nunca reenvia o que já foi enviado nem cria pedidos. Sem credenciais da API, não faz nada e avisa."""
        result = notifications_service.send_pending(limit)
        if result["motivo"]:
            click.echo(f"Nada enviado: {result['motivo']}. Veja docs/WHATSAPP_API.md.")
            return
        click.echo(f"{result['processadas']} aviso(s) processado(s); {result['enviadas']} aceito(s) pela API.")

    @app.cli.command("list-messages")
    @click.option("--limit", default=20)
    def list_messages(limit):
        """Lista as mensagens do formulário de contato."""
        for m in db.session.scalars(select(ContactMessage).order_by(ContactMessage.id.desc()).limit(limit)):
            click.echo(f"#{m.id} {m.created_at:%d/%m/%Y %H:%M} [{m.email_status}] {m.name} <{m.email}> — {m.subject}\n    {m.message[:200]}")
