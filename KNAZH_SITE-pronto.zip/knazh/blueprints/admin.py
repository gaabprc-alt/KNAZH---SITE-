"""Painel administrativo do catálogo (somente contas com is_admin=True).

Segurança em camadas, todas no servidor:
1. `bp.before_request` aplica `require_admin()` a QUALQUER rota deste blueprint (inclusive as futuras);
2. cada view também usa `@admin_required` (defesa em profundidade);
3. todo POST passa pelo CSRFProtect global do app; a exclusão nunca acontece por GET.
"""
from __future__ import annotations

from urllib.parse import quote

from flask import Blueprint, abort, current_app, flash, g, jsonify, redirect, render_template, request, url_for
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from werkzeug.datastructures import FileStorage

from ..auth import admin_manager_required, admin_required, require_admin, require_admin_manager
from ..extensions import db
from ..forms import ProductForm
from ..models import ORDER_STATUS_LABELS, Category, Customer, Order, Product
from ..services import admin_catalog as svc
from ..services import admin_orders as orders_svc
from ..services import admin_users as users_svc
from ..services import notifications as notifications_svc
from ..services.channels import cancellation_message, normalize_whatsapp
from ..services.money import cents_to_input
from ..services.security import safe_next_url
from ..services.uploads import ACCEPT_ATTR, UploadError, delete_managed_image, save_product_image

bp = Blueprint("admin", __name__, url_prefix="/admin")

GENERIC_SAVE_ERROR = "Não foi possível salvar agora. Nada foi alterado; tente novamente em instantes."


@bp.before_request
def _guard():
    denied = require_admin()
    if denied is None and (request.endpoint or "").startswith("admin.user_"):
        denied = require_admin_manager()  # gestão de administradores: exige a permissão específica, em QUALQUER rota user_*
    return denied


def _upload_dir():
    return current_app.config["UPLOAD_DIR"]


def _remove_file(rel_path: str | None) -> None:
    delete_managed_image(rel_path, upload_dir=_upload_dir())


def _uploaded_file(form: ProductForm) -> FileStorage | None:
    f = form.image.data
    return f if isinstance(f, FileStorage) and f.filename else None


def _store_upload(upload: FileStorage) -> str:
    cfg = current_app.config
    return save_product_image(upload.stream, upload.filename, upload.mimetype, upload_dir=_upload_dir(),
                              max_bytes=cfg["UPLOAD_MAX_FILE_BYTES"], max_pixels=cfg["UPLOAD_MAX_PIXELS"],
                              max_side=cfg["UPLOAD_MAX_SIDE"])


def _back(default: str) -> str:
    target = safe_next_url(request.form.get("next"), default)
    return target if target.startswith("/admin/") else default


def _get_product(product_id: int) -> Product:
    product = db.session.get(Product, product_id)
    if product is None:
        abort(404)
    return product


def _category_for(form: ProductForm) -> Category:
    """Categoria do produto: a existente escolhida ou a NOVA digitada, criada na mesma transação do produto
    (se o produto não for salvo, a categoria também não é). Nunca duplica nem altera categorias existentes."""
    if form.new_category_name:
        try:
            return svc.build_category(form.new_category_name)
        except IntegrityError:
            db.session.rollback()
            raise svc.CategoryError("Essa categoria acabou de ser criada. Atualize a página e escolha-a na lista.") from None
    return db.session.get(Category, form.category_value)


def _fill_form(form: ProductForm, product: Product) -> None:
    form.name.data, form.description.data, form.details.data = product.name, product.description, product.details
    form.category_id.data = str(product.category_id)
    form.price.data = cents_to_input(product.price_cents)
    form.image_alt.data = product.image_alt
    form.is_available.data, form.is_featured.data = product.is_available, product.is_featured


def _render_form(form: ProductForm, product: Product | None):
    return render_template("admin/product_form.html", form=form, product=product, accept=ACCEPT_ATTR,
                           max_bytes=current_app.config["UPLOAD_MAX_FILE_BYTES"], section="produtos")


@bp.get("/")
@admin_required
def index():
    """Visão geral: somente números reais do banco (nada inventado). Sem pedidos, mostra um estado vazio."""
    product_stats = svc.stats()
    categories = svc.all_categories()
    by_status = orders_svc.counts_by_status()
    return render_template("admin/dashboard.html", product_stats=product_stats, categories_total=len(categories),
                           categories_active=sum(1 for c in categories if c.is_active), by_status=by_status,
                           orders_total=sum(by_status.values()), order_stats=orders_svc.stats(),
                           recent=orders_svc.recent(), status_labels=ORDER_STATUS_LABELS, section="inicio")


@bp.get("/produtos")
@admin_required
def products():
    filters = svc.parse_filters(request.args)
    page = svc.search_products(filters)
    return render_template("admin/products.html", filters=filters, page=page, stats=svc.stats(),
                           categories=svc.all_categories(), status_options=svc.STATUS_OPTIONS, section="produtos")


@bp.route("/produtos/novo", methods=["GET", "POST"])
@admin_required
def product_new():
    form = ProductForm()
    form.set_categories(svc.form_categories())
    if request.method == "GET":
        form.is_available.data = True
    if form.validate_on_submit():
        upload = _uploaded_file(form)
        new_image = None
        if upload is None:
            form.image.errors = [*form.image.errors, "Escolha uma foto do produto."]
        else:
            try:
                new_image = _store_upload(upload)
            except UploadError as exc:
                form.image.errors = [*form.image.errors, str(exc)]
        category = None
        if new_image:
            try:
                category = _category_for(form)
            except svc.CategoryError as exc:  # outra pessoa criou a mesma categoria agora mesmo
                db.session.rollback()
                _remove_file(new_image)
                form.new_category.errors = [*form.new_category.errors, str(exc)]
        if new_image and category is not None:
            product = Product(
                slug=svc.unique_slug(form.name.data), name=form.name.data, description=form.description.data,
                details=form.details.data or "", price_cents=form.price_cents, image=new_image,
                image_alt=form.image_alt.data or "", is_available=form.is_available.data,
                is_featured=form.is_featured.data, is_demo=False,
            )
            product.category = category
            try:
                db.session.add(product)
                db.session.commit()
            except SQLAlchemyError:
                db.session.rollback()
                _remove_file(new_image)  # não deixa arquivo órfão
                flash(GENERIC_SAVE_ERROR, "error")
            else:
                flash(f"“{product.name}” foi cadastrado.", "success")
                return redirect(url_for("admin.products"))
    return _render_form(form, None)


@bp.route("/produtos/<int:product_id>/editar", methods=["GET", "POST"])
@admin_required
def product_edit(product_id: int):
    product = _get_product(product_id)
    form = ProductForm()
    form.set_categories(svc.form_categories(product))
    if request.method == "GET":
        _fill_form(form, product)
    if form.validate_on_submit():
        upload = _uploaded_file(form)
        new_image = None
        if upload is not None:
            try:
                new_image = _store_upload(upload)
            except UploadError as exc:
                form.image.errors = [*form.image.errors, str(exc)]
        if upload is None or new_image:
            try:
                category = _category_for(form)  # antes de alterar o produto: se falhar, nada foi mexido
            except svc.CategoryError as exc:
                db.session.rollback()
                _remove_file(new_image)
                form.new_category.errors = [*form.new_category.errors, str(exc)]
                return _render_form(form, product)
            old_image = product.image
            product.name, product.description = form.name.data, form.description.data
            product.details, product.image_alt = form.details.data or "", form.image_alt.data or ""
            product.price_cents = form.price_cents
            product.is_available, product.is_featured = form.is_available.data, form.is_featured.data
            product.category = category
            product.is_demo = False  # produto editado pelo painel deixa de ser "demo" (seed/remove-demo não o tocam)
            if new_image:
                product.image = new_image  # sem arquivo novo, a imagem atual é mantida
            try:
                db.session.commit()
            except SQLAlchemyError:
                db.session.rollback()
                _remove_file(new_image)
                flash(GENERIC_SAVE_ERROR, "error")
            else:
                if new_image:
                    _remove_file(old_image)  # só depois do commit; só apaga arquivos do próprio painel
                flash(f"“{product.name}” foi atualizado.", "success")
                return redirect(url_for("admin.products"))
    return _render_form(form, product)


@bp.post("/produtos/<int:product_id>/disponibilidade")
@admin_required
def product_toggle(product_id: int):
    product = _get_product(product_id)
    product.is_available = not product.is_available
    product.is_demo = False
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        flash(GENERIC_SAVE_ERROR, "error")
    else:
        state = "disponível" if product.is_available else "indisponível"
        flash(f"“{product.name}” agora está {state} na loja.", "success")
    return redirect(_back(url_for("admin.products")))


@bp.get("/produtos/<int:product_id>/excluir")
@admin_required
def product_delete_confirm(product_id: int):
    """Tela de confirmação (também serve de alternativa sem JavaScript). Este GET nunca exclui nada."""
    return render_template("admin/product_delete.html", product=_get_product(product_id), section="produtos")


@bp.post("/produtos/<int:product_id>/excluir")
@admin_required
def product_delete(product_id: int):
    product = _get_product(product_id)
    name, image = product.name, product.image
    try:
        svc.delete_product(product)
    except SQLAlchemyError:
        flash("Não foi possível excluir este produto agora. Se ele não deve mais aparecer na loja, "
              "marque-o como indisponível em vez de excluir.", "error")
        return redirect(_back(url_for("admin.products")))
    _remove_file(image)  # só depois do commit; ignora SVGs originais e qualquer coisa fora de uploads/products
    flash(f"“{name}” foi excluído.", "success")
    return redirect(_back(url_for("admin.products")))


@bp.post("/categorias/nova")
@admin_required
def category_create():
    """Cria uma categoria sem sair do cadastro do produto (chamada pelo JavaScript do formulário; devolve JSON).
    CSRF é exigido pelo CSRFProtect global (cabeçalho X-CSRFToken). Sem JavaScript, o campo "Nova categoria" do
    próprio formulário cria a categoria ao salvar o produto."""
    try:
        category = svc.create_category(request.form.get("name"))
    except svc.CategoryError as exc:
        existing = exc.existing
        return jsonify(ok=False, message=str(exc), existing_id=existing.id if existing else None), 400
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(ok=False, message=GENERIC_SAVE_ERROR), 500
    return jsonify(ok=True, id=category.id, name=category.name, message=f"Categoria “{category.name}” criada."), 201


# ------------------------------------------------------------------ categorias (gestão completa)
def _get_category(category_id: int) -> Category:
    category = db.session.get(Category, category_id)
    if category is None:
        abort(404)
    return category


@bp.get("/categorias")
@admin_required
def categories():
    return render_template("admin/categories.html", categories=svc.all_categories(), counts=svc.product_counts(),
                           section="categorias")


def _category_form(category: Category | None):
    fields = {"name": "", "description": "", "icon": "package", "sort_order": "", "is_active": True}
    if category is not None:
        fields = {"name": category.name, "description": category.description, "icon": category.icon,
                  "sort_order": category.sort_order, "is_active": category.is_active}
    error = None
    if request.method == "POST":
        fields = {"name": request.form.get("name", ""), "description": request.form.get("description", ""),
                  "icon": request.form.get("icon", ""), "sort_order": request.form.get("sort_order", ""),
                  "is_active": request.form.get("is_active") == "on"}
        try:
            saved = svc.save_category(svc.parse_category_form(request.form, category), category)
        except svc.CategoryError as exc:
            error = str(exc)
        except SQLAlchemyError:
            db.session.rollback()
            error = GENERIC_SAVE_ERROR
        else:
            flash(f"Categoria “{saved.name}” {'atualizada' if category else 'criada'}.", "success")
            return redirect(url_for("admin.categories"))
    return render_template("admin/category_form.html", category=category, fields=fields, error=error,
                           icons=svc.CATEGORY_ICONS, name_max=svc.CATEGORY_NAME_MAX,
                           desc_max=svc.CATEGORY_DESCRIPTION_MAX, section="categorias"), (400 if error else 200)


@bp.route("/categorias/novo", methods=["GET", "POST"])
@admin_required
def category_new():
    return _category_form(None)


@bp.route("/categorias/<int:category_id>/editar", methods=["GET", "POST"])
@admin_required
def category_edit(category_id: int):
    return _category_form(_get_category(category_id))


@bp.get("/categorias/<int:category_id>/excluir")
@admin_required
def category_delete_confirm(category_id: int):
    category = _get_category(category_id)
    return render_template("admin/category_delete.html", category=category,
                           count=svc.product_counts().get(category.id, 0), section="categorias")


@bp.post("/categorias/<int:category_id>/excluir")
@admin_required
def category_delete(category_id: int):
    category = _get_category(category_id)
    name = category.name
    try:
        svc.delete_category(category)
    except svc.CategoryError as exc:
        flash(str(exc), "error")
    except SQLAlchemyError:
        db.session.rollback()
        flash(GENERIC_SAVE_ERROR, "error")
    else:
        flash(f"Categoria “{name}” excluída.", "success")
    return redirect(url_for("admin.categories"))


# ------------------------------------------------------------------ pedidos
def _get_order(order_id: int) -> Order:
    order = db.session.get(Order, order_id)
    if order is None:
        abort(404)
    return order


@bp.get("/pedidos")
@admin_required
def orders():
    filters = orders_svc.parse_filters(request.args)
    page = orders_svc.search_orders(filters)
    return render_template("admin/orders.html", filters=filters, page=page, stats=orders_svc.stats(),
                           status_filters=orders_svc.STATUS_FILTERS, integration=notifications_svc.integration_status(),
                           section="pedidos")


@bp.get("/pedidos/<int:order_id>")
@admin_required
def order_detail(order_id: int):
    order = _get_order(order_id)
    phone = normalize_whatsapp(order.customer_phone)
    cancel_wa = None
    if order.status == "cancelado" and phone:
        note = order.notification_for("cancel")
        if note is None or note.status != "enviado":  # aviso automático não foi enviado: conversa manual com texto pronto
            cancel_wa = f"https://wa.me/{phone}?text=" + quote(cancellation_message(order), safe="")
    next_states = [(k, ORDER_STATUS_LABELS[k]) for k in orders_svc.allowed_next(order.status)]
    return render_template("admin/order_detail.html", order=order, integration=notifications_svc.integration_status(),
                           can_retry=notifications_svc.can_retry, max_attempts=notifications_svc.max_attempts(),
                           status_options=[(order.status, order.status_label)] + next_states, customer_wa_digits=phone,
                           cancel_wa_url=cancel_wa, reason_max=orders_svc.REASON_MAX, section="pedidos")


@bp.post("/pedidos/<int:order_id>/status")
@admin_required
def order_status(order_id: int):
    """Muda o estado. Cancelar exige MOTIVO (validado aqui, no servidor) e uma tela de confirmação com o texto que o
    cliente receberá; o aviso ao cliente é tentado só depois do commit e nunca desfaz o cancelamento."""
    order = _get_order(order_id)
    status, reason = request.form.get("status"), request.form.get("reason")
    back = redirect(url_for("admin.order_detail", order_id=order_id))
    try:
        if status == "cancelado" and order.status != "cancelado":
            reason = orders_svc.validate_cancellation(order, reason)
            if request.form.get("confirmar") != "1":  # 1ª etapa: mostrar o motivo e pedir confirmação explícita
                return render_template("admin/order_cancel_confirm.html", order=order, reason=reason,
                                       section="pedidos")
        changed = orders_svc.set_status(order, status, reason=reason, admin=g.customer)
    except orders_svc.OrderStatusError as exc:
        flash(str(exc), "error")
        return back
    except SQLAlchemyError:
        db.session.rollback()
        flash(GENERIC_SAVE_ERROR, "error")
        return back
    if not changed:
        flash("O pedido já estava nesse estado.", "info")
    elif order.status == "cancelado":
        notifications_svc.send_cancellation(order)
        note = order.notification_for("cancel")
        outcome = {
            "enviado": "O aviso de cancelamento foi aceito pela API do WhatsApp.",
            "dispensado": "O cliente não autorizou avisos por WhatsApp: abra a conversa manualmente (botão ao lado).",
            "nao_configurado": "O aviso automático ainda não está configurado: abra a conversa manualmente (botão ao lado).",
        }.get(note.status if note else "", "O aviso ao cliente não pôde ser enviado agora; você pode tentar de novo na seção de avisos.")
        flash(f"Pedido {order.number} cancelado. {outcome}", "success")
    else:
        flash(f"Pedido {order.number} agora está “{order.status_label}”. O cliente não é avisado automaticamente.",
              "success")
    return back


@bp.post("/pedidos/<int:order_id>/notificacoes/<recipient>/reenviar")
@admin_required
def order_notification_retry(order_id: int, recipient: str):
    """Nova tentativa CONTROLADA de um aviso: nunca cria outro pedido e nunca reenvia o que já foi enviado."""
    order = _get_order(order_id)
    notification = order.notification_for(recipient)
    if notification is None:
        abort(404)
    if notification.status == "enviado":
        flash("Esse aviso já foi enviado e não será reenviado.", "info")
    elif notification.status == "dispensado":
        flash("O cliente não autorizou receber WhatsApp automático: nada será enviado a ele.", "info")
    elif not notifications_svc.can_retry(notification):
        flash("Não é possível tentar agora: o limite de tentativas foi atingido ou há uma tentativa em andamento.",
              "error")
    else:
        result = notifications_svc.attempt(notification.id)
        if result.status == "enviado":
            flash("Aviso aceito pela API do WhatsApp.", "success")
        elif result.status == "nao_configurado":
            flash("A integração do WhatsApp ainda não está configurada: nada foi enviado.", "error")
        else:
            flash("Não foi possível enviar agora. " + (result.last_error or "Tente novamente em instantes."), "error")
    return redirect(url_for("admin.order_detail", order_id=order_id))


# ------------------------------------------------------------------ gerenciar administradores
# Somente quem tem is_admin E can_manage_admins (before_request + @admin_manager_required). O serviço revalida no banco.
@bp.get("/administradores")
@admin_manager_required
def users():
    filters = users_svc.parse_filters(request.args)
    page = users_svc.search_users(filters, current_app.config["ADMIN_PER_PAGE"])
    return render_template("admin/users.html", filters=filters, page=page, stats=users_svc.stats(),
                           status_options=users_svc.STATUS_OPTIONS, section="administradores")


def _get_user(user_id: int) -> Customer:
    user = db.session.get(Customer, user_id)
    if user is None:
        abort(404)
    return user


@bp.route("/administradores/<int:user_id>/conceder", methods=["GET", "POST"])
@admin_manager_required
def user_grant(user_id: int):
    """GET: tela de confirmação (também serve sem JavaScript; nunca altera nada). POST: concede o acesso."""
    target = _get_user(user_id)
    if request.method == "POST":
        result = users_svc.grant_admin(g.customer, target.id, can_manage=request.form.get("can_manage") == "y")
        flash(result.message, "success" if result.ok else "error")
        return redirect(_back(url_for("admin.users")))
    return render_template("admin/user_confirm.html", target=target, action="grant", section="administradores")


@bp.route("/administradores/<int:user_id>/remover", methods=["GET", "POST"])
@admin_manager_required
def user_revoke(user_id: int):
    """GET: tela de confirmação (nunca altera nada). POST: remove o acesso administrativo."""
    target = _get_user(user_id)
    if request.method == "POST":
        result = users_svc.revoke_admin(g.customer, target.id)
        flash(result.message, "success" if result.ok else "error")
        return redirect(_back(url_for("admin.users")))
    return render_template("admin/user_confirm.html", target=target, action="revoke", section="administradores")
