"""Conta do cliente: cadastro, login, perfil, pedidos próprios e favoritos."""
from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, session, url_for
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from ..auth import login_customer, login_required, logout_customer
from ..extensions import db
from ..forms import LoginForm, ProfileForm, RegisterForm, ResendVerificationForm
from ..models import Customer, Favorite, Order, Product, utcnow
from ..services.email_verification import make_token, token_hash
from ..services.mailer import send_verification_email, smtp_sender_configured
from ..services.security import (login_throttle, register_throttle, safe_next_url, verification_ip_throttle,
                                 verification_throttle)

bp = Blueprint("account", __name__, url_prefix="/conta")


def _throttle_key(email: str) -> str:
    return f"{request.remote_addr}|{email.lower()}"


def _verification_url(token: str) -> str:
    """https://DOMINIO/conta/confirmar-email/TOKEN. Com SITE_URL usa o domínio configurado (sem barra duplicada);
    sem ele, usa o endereço da própria requisição (aceitável em desenvolvimento)."""
    path = url_for("account.verify_email", token=token)
    site_url = current_app.config["SITE_URL"].rstrip("/")
    return f"{site_url}{path}" if site_url else url_for("account.verify_email", token=token, _external=True)


def _send_verification(customer: Customer) -> str:
    """Grava o hash de um NOVO token (o anterior deixa de valer: há no máximo um ativo por conta) e envia o link.
    O token é gravado ANTES do envio: se o SMTP falhar a conta fica pendente e o reenvio simplesmente o substitui.
    Nunca levanta exceção: devolve 'enviado', 'falhou' ou 'nao_configurado'."""
    token = make_token()
    digest = token_hash(token)
    if digest is None:  # nunca deveria ocorrer; não envia um link que depois seria rejeitado
        current_app.logger.error("O gerador produziu um token de confirmação inválido.")
        return "falhou"
    try:
        customer.email_verification_token_hash = digest
        customer.email_verification_expires_at = utcnow() + timedelta(seconds=current_app.config["EMAIL_VERIFICATION_MAX_AGE"])
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        current_app.logger.exception("Não foi possível gravar o token de confirmação.")
        return "falhou"
    return send_verification_email(customer.name, customer.email, _verification_url(token))


def _remember_pending(email: str) -> None:
    session["pending_verification_email"] = email.strip().lower()


@bp.route("/entrar", methods=["GET", "POST"])
def login():
    if g.customer:
        return redirect(url_for("account.dashboard"))
    form = LoginForm()
    if request.method == "GET":
        form.next.data = request.args.get("next", "")
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        key = _throttle_key(email)
        if login_throttle.blocked(key):
            flash("Muitas tentativas. Aguarde alguns minutos e tente de novo.", "error")
        else:
            customer = db.session.scalar(select(Customer).where(func.lower(Customer.email) == email))
            if customer and customer.check_password(form.password.data):
                if current_app.config["EMAIL_VERIFICATION_REQUIRED"] and not customer.email_verified:
                    login_throttle.reset(key)
                    _remember_pending(customer.email)
                    flash("Confirme seu e-mail antes de entrar.", "info")
                    return redirect(url_for("account.verification_pending"))
                login_throttle.reset(key)
                login_customer(customer)
                return redirect(safe_next_url(form.next.data, url_for("account.dashboard")))
            login_throttle.hit(key)
            flash("E-mail ou senha incorretos.", "error")
    return render_template("account/login.html", form=form)


@bp.route("/cadastrar", methods=["GET", "POST"])
def register():
    if g.customer:
        return redirect(url_for("account.dashboard"))
    form = RegisterForm()
    valid = form.validate_on_submit()
    if valid and register_throttle.blocked(request.remote_addr or "?"):
        flash("Muitas tentativas. Aguarde um pouco e tente de novo.", "error")
        return render_template("account/register.html", form=form), 429
    if valid:
        register_throttle.hit(request.remote_addr or "?")
    email = form.email.data.strip().lower() if valid else ""
    if valid and email == current_app.config["INITIAL_ADMIN_EMAIL"]:
        flash("Não foi possível criar a conta com esses dados. Se você já tem cadastro, entre na sua conta.", "error")
    elif valid:
        require_verification = current_app.config["EMAIL_VERIFICATION_REQUIRED"]
        existing = db.session.scalar(select(Customer).where(func.lower(Customer.email) == email))
        # Um cadastro NUNCA confirmado pode ser refeito: quem confirma o e-mail agora é o dono da caixa. Isso impede que
        # alguém "reserve" o e-mail de outra pessoa com uma senha que só ele conhece. Contas confirmadas/admin nunca.
        reopen = existing is not None and require_verification and existing.email_verified is False and not existing.is_admin
        if existing is not None and not reopen:
            flash("Não foi possível criar a conta com esses dados. Se você já tem cadastro, entre na sua conta.", "error")
            return render_template("account/register.html", form=form)
        if require_verification and not smtp_sender_configured():
            current_app.logger.error("Cadastro bloqueado: confirmação por e-mail ativa, mas SMTP não está configurado.")
            flash("O cadastro por e-mail está temporariamente indisponível. Tente novamente mais tarde.", "error")
            return render_template("account/register.html", form=form), 503

        customer = existing or Customer(email=email, email_verified=not require_verification,
                                        email_verified_at=utcnow() if not require_verification else None)
        customer.name, customer.phone = form.name.data, form.phone.data
        customer.set_password(form.password.data)
        if reopen:
            customer.email_verification_token_hash = None  # o link antigo morre aqui; _send_verification grava o novo
            customer.email_verification_expires_at = None
        try:
            db.session.add(customer)
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("Não foi possível criar a conta com esses dados. Se você já tem cadastro, entre na sua conta.", "error")
        except SQLAlchemyError:
            db.session.rollback()
            current_app.logger.exception("Falha ao gravar o cadastro.")
            flash("Não foi possível concluir o cadastro agora. Tente novamente em instantes.", "error")
        else:
            if require_verification:
                _remember_pending(customer.email)
                status = _send_verification(customer)
                if status == "enviado":
                    flash("Conta criada. Enviamos um link de confirmação para o seu e-mail.", "success")
                else:
                    flash("Conta criada, mas não conseguimos enviar o e-mail agora. Use o botão para reenviar.", "error")
                return redirect(url_for("account.verification_pending"))
            login_customer(customer)
            flash("Conta criada! Bem-vindo(a) à KNAZH.", "success")
            return redirect(url_for("account.dashboard"))
    return render_template("account/register.html", form=form)


@bp.get("/verificar-email")
def verification_pending():
    if g.customer:
        return redirect(url_for("account.dashboard"))
    email = session.get("pending_verification_email", "")
    form = ResendVerificationForm()
    form.email.data = email
    expiration_hours = max(1, (current_app.config["EMAIL_VERIFICATION_MAX_AGE"] + 3599) // 3600)
    return render_template(
        "account/verification_pending.html",
        email=email,
        form=form,
        expiration_hours=expiration_hours,
    )


@bp.post("/reenviar-verificacao")
def resend_verification():
    if g.customer:
        return redirect(url_for("account.dashboard"))
    form = ResendVerificationForm()
    if not form.validate_on_submit():
        flash("Informe um endereço de e-mail válido.", "error")
        return redirect(url_for("account.verification_pending"))
    email = form.email.data.strip().lower()
    _remember_pending(email)
    ip = request.remote_addr or "?"
    if verification_throttle.blocked(email) or verification_ip_throttle.blocked(ip):
        flash("Muitas tentativas. Aguarde um pouco antes de solicitar outro link.", "error")
        return redirect(url_for("account.verification_pending"))
    verification_throttle.hit(email)
    verification_ip_throttle.hit(ip)

    customer = db.session.scalar(select(Customer).where(func.lower(Customer.email) == email))
    if customer and not customer.email_verified:
        status = _send_verification(customer)
        if status != "enviado":
            current_app.logger.warning("Reenvio de confirmação não concluído (status: %s).", status)
    flash(
        "Se houver uma conta aguardando confirmação para esse endereço, enviaremos um novo link. "
        "Se não o receber, tente novamente mais tarde.",
        "info",
    )
    return redirect(url_for("account.verification_pending"))


_LINK_INVALID = ("Esse link de confirmação já foi usado, é inválido ou expirou. Se você já confirmou o e-mail, é só entrar; "
                 "se não, peça um novo link.")


@bp.get("/confirmar-email/<token>")
def verify_email(token: str):
    """Confirma o e-mail. O link é de USO ÚNICO: ao confirmar, hash e validade são apagados na mesma operação atômica."""
    digest = token_hash(token)
    customer = db.session.scalar(select(Customer).where(Customer.email_verification_token_hash == digest)) if digest else None
    if customer is None:
        flash(_LINK_INVALID, "error")
        return redirect(url_for("account.verification_pending"))
    now = utcnow()
    try:
        if customer.email_verification_expires_at is None or customer.email_verification_expires_at <= now:
            customer.email_verification_token_hash = None
            customer.email_verification_expires_at = None
            db.session.commit()
            _remember_pending(customer.email)
            flash(_LINK_INVALID, "error")
            return redirect(url_for("account.verification_pending"))
        # UPDATE condicional: duas aberturas simultâneas do mesmo link não "consomem" duas vezes.
        consumed = db.session.execute(
            update(Customer)
            .where(Customer.id == customer.id, Customer.email_verification_token_hash == digest,
                   Customer.email_verification_expires_at > now)
            .values(email_verified=True, email_verified_at=now, email_verification_token_hash=None,
                    email_verification_expires_at=None)
            .execution_options(synchronize_session=False)
        ).rowcount == 1
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        current_app.logger.exception("Falha ao confirmar o e-mail.")
        flash("Não foi possível confirmar agora. Tente abrir o link de novo em instantes.", "error")
        return redirect(url_for("account.verification_pending"))
    if not consumed:
        flash(_LINK_INVALID, "error")
        return redirect(url_for("account.verification_pending"))
    session.pop("pending_verification_email", None)
    flash("E-mail confirmado! Agora você já pode entrar na sua conta.", "success")
    return redirect(url_for("account.login"))


@bp.post("/sair")
def logout():
    logout_customer()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("main.home"))


@bp.get("")
@login_required
def dashboard():
    cid = g.customer.id
    orders = list(db.session.scalars(select(Order).where(Order.customer_id == cid).order_by(Order.id.desc()).limit(3)))
    n_orders = db.session.scalar(select(func.count(Order.id)).where(Order.customer_id == cid))
    n_favs = db.session.scalar(select(func.count(Favorite.id)).where(Favorite.customer_id == cid))
    return render_template("account/dashboard.html", orders=orders, n_orders=n_orders, n_favs=n_favs, section="perfil")


@bp.route("/perfil", methods=["GET", "POST"])
@login_required
def profile():
    form = ProfileForm(obj=g.customer)
    if form.validate_on_submit():
        g.customer.name, g.customer.phone = form.name.data, form.phone.data
        db.session.commit()
        flash("Perfil atualizado.", "success")
        return redirect(url_for("account.dashboard"))
    return render_template("account/profile.html", form=form, section="perfil")


@bp.get("/pedidos")
@login_required
def orders():
    rows = list(db.session.scalars(select(Order).where(Order.customer_id == g.customer.id).order_by(Order.id.desc())))
    return render_template("account/orders.html", orders=rows, section="pedidos")


@bp.get("/pedidos/<public_id>")
@login_required
def order_detail(public_id: str):
    order = db.session.scalar(select(Order).where(Order.public_id == public_id, Order.customer_id == g.customer.id))
    if order is None:
        abort(404)
    return render_template("account/order_detail.html", order=order, section="pedidos")


@bp.get("/favoritos")
@login_required
def favorites():
    products = list(db.session.scalars(select(Product).join(Favorite, Favorite.product_id == Product.id)
                                       .where(Favorite.customer_id == g.customer.id).order_by(Favorite.id.desc())))
    return render_template("account/favorites.html", products=products, favorite_ids={p.id for p in products}, section="favoritos")


@bp.post("/favoritos/alternar")
@login_required
def toggle_favorite():
    try:
        pid = int(request.form.get("product_id", ""))
    except ValueError:
        abort(400)
    product = db.session.get(Product, pid)
    if product is None:
        abort(404)
    fav = db.session.scalar(select(Favorite).where(Favorite.customer_id == g.customer.id, Favorite.product_id == pid))
    if fav:
        db.session.delete(fav)
        flash(f"“{product.name}” saiu dos favoritos.", "info")
    else:
        db.session.add(Favorite(customer_id=g.customer.id, product_id=pid))
        flash(f"“{product.name}” foi para os favoritos.", "success")
    db.session.commit()
    return redirect(safe_next_url(request.form.get("next"), url_for("account.favorites")))
